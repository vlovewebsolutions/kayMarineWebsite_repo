@echo off
echo Starting Kay Marine CRM Frontend...
echo.
cd frontend
npm run dev
pause

