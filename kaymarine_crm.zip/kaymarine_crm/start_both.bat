@echo off
echo Starting Kay Marine CRM - Both Backend and Frontend...
echo.
echo Starting Backend in new window...
start "Django Backend" cmd /k "python manage.py runserver 127.0.0.1:8004"
echo.
echo Starting Frontend in new window...
start "Frontend Dev Server" cmd /k "cd frontend && npm run dev"
echo.
echo Both servers are starting...
echo Backend: http://localhost:8004
echo Frontend: http://localhost:5173/crm/
echo.
echo Access the app at: http://localhost:5173/crm/
pause

