from rest_framework import serializers
from .models import DischargeForm, LandfillReceipt

class DischargeFormSerializer(serializers.ModelSerializer):
    stage_color = serializers.ReadOnlyField()
    receipts = serializers.SerializerMethodField()

    class Meta:
        model = DischargeForm
        fields = '__all__'

    def get_receipts(self, obj: DischargeForm):
        return LandfillReceiptSerializer(obj.receipts.all(), many=True, context=self.context).data


class LandfillReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = LandfillReceipt
        fields = ['id', 'discharge_form', 'file', 'uploaded_at']
