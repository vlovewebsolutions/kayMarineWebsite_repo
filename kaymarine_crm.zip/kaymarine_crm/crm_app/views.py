from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from .models import DischargeForm, LandfillReceipt
from .serializers import DischargeFormSerializer, LandfillReceiptSerializer


class IsAdminOrReadOnly(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.method in ('GET', 'HEAD', 'OPTIONS'):
            return request.user and request.user.is_authenticated
        return request.user and request.user.is_staff


class DischargeFormViewSet(viewsets.ModelViewSet):
    queryset = DischargeForm.objects.all()
    serializer_class = DischargeFormSerializer
    permission_classes = [IsAdminOrReadOnly]

    def get_queryset(self):
        qs = super().get_queryset().order_by('-created_at')
        return qs

    @action(detail=True, methods=['post'], url_path='upload-receipt')
    def upload_receipt(self, request, pk=None):
        form = self.get_object()
        file = request.FILES.get('file')
        if not file:
            return Response({'detail': 'No file uploaded'}, status=status.HTTP_400_BAD_REQUEST)
        receipt = LandfillReceipt.objects.create(discharge_form=form, file=file)
        return Response(LandfillReceiptSerializer(receipt, context={'request': request}).data, status=status.HTTP_201_CREATED)

# Create your views here.
