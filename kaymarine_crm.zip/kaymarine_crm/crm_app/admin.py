from django.contrib import admin

# Register your models here.
from .models import DischargeForm

@admin.register(DischargeForm)
class DischargeFormAdmin(admin.ModelAdmin):
    list_display = (
        "ship_name",
        "date",
        "berth",
        "port",
        "flag",
        "vessel_type",
        "imo_no",
        "eta",
        "etb",
        "total_volume",
        "form44_submitted",
        "biosecurity_status",
        "govt_status",
        "created_at",
    )
    search_fields = ("ship_name", "imo_no", "berth", "port", "flag")
    list_filter = (
        "date",
        "port",
        "flag",
        "vessel_type",
        "biosecurity_status",
        "govt_status",
        "form44_submitted",
        "documentation_complete",
        "incident_occurred",
    )
