@echo off
echo Starting Kay Marine CRM Backend...
echo Using Python interpreter: python
echo.
python manage.py runserver 127.0.0.1:8004
pause

