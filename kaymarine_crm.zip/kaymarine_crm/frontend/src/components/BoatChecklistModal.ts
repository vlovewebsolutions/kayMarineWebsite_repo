import { UIComponents } from '../utils/ui';
import { formatDateInput, formatTimeInput } from '../utils/dates';
import { apiBase } from '../config';

export function openBoatChecklistModal(order: any) {
	const content = `
		<div class="space-y-6 text-sm">
			<h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Vessel Checklist</h2>
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
				<label>Ship Name: <input type="text" id="v_ship_name" value="${order.ship_name || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Flag: <input type="text" id="v_flag" value="${order.flag || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>IMO No: <input type="text" id="v_imo" value="${order.imo_no || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Berth: <input type="text" id="v_berth" value="${order.berth || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Port: <input type="text" id="v_port" value="${order.port || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Order Created At: <input type="date" id="v_date" value="${formatDateInput(order.date)}" class="border rounded px-2 py-1 w-full"></label>
				<label>Time: <input type="time" id="v_time" value="${formatTimeInput(order.time)}" class="border rounded px-2 py-1 w-full"></label>
			</div>
			<label>Total Volume: <input type="number" step="0.01" id="v_total" value="${order.total_volume || ''}" class="border rounded px-2 py-1 w-32"></label>
			<label>Master's Name & Signature: <input type="text" id="v_master" class="border rounded px-2 py-1 w-full"></label>

			<h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Collecting Boat Checklist</h2>
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
				<label>AA Accredited Person Name & Sign: <input type="text" id="c_aa_person" class="border rounded px-2 py-1 w-full" placeholder="Name & signature"></label>
				<label>Collecting Boat Name: <input type="text" id="c_boat" class="border rounded px-2 py-1 w-full"></label>
				<label>AA Accredited Person Name & Sign (2): <input type="text" id="c_aa_person2" class="border rounded px-2 py-1 w-full" placeholder="If second required"></label>
				<label>Truck Reg No: <input type="text" id="c_truck" class="border rounded px-2 py-1 w-full"></label>
				<label class="sm:col-span-2">Disposal Date & Time at Landfill: <input type="datetime-local" id="c_disposal" class="border rounded px-2 py-1 w-full"></label>
			</div>
			<div class="overflow-x-auto">
				<table class="min-w-full border border-gray-200">
					<thead class="bg-gray-50">
						<tr>
							<th class="px-2 py-1 text-left">No.</th>
							<th class="px-2 py-1 text-left">Checklist Item</th>
							<th class="px-2 py-1 text-left">Yes</th>
							<th class="px-2 py-1 text-left">No</th>
						</tr>
					</thead>
					<tbody>
						${[ 
							'Clearance taken from Bio Security (Form 44)',
							'Clearance taken from Customs (Form 44)',
							'Verbal clearance taken on phone for Form 44',
							'Checklist for Accredited Person Completed',
							'Checklist for Driver Completed'
						].map((item, i) => `
							<tr>
								<td class="px-2 py-1">${i + 1}</td>
								<td class="px-2 py-1">${item}</td>
								<td class="px-2 py-1"><input type="radio" name="chk_${i}" value="yes"></td>
								<td class="px-2 py-1"><input type="radio" name="chk_${i}" value="no"></td>
							</tr>`).join('')}
					</tbody>
				</table>
			</div>
			<div class="space-y-3">
				<h3 class="font-semibold">Send to Landfill within 48hrs</h3>
				<table class="min-w-full border border-gray-200">
					<thead class="bg-gray-50">
						<tr>
							<th class="px-2 py-1 text-left">No.</th>
							<th class="px-2 py-1 text-left">Item</th>
							<th class="px-2 py-1 text-left">Yes</th>
							<th class="px-2 py-1 text-left">No</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="px-2 py-1">1</td>
							<td class="px-2 py-1">Garbage staying in AA storage</td>
							<td class="px-2 py-1"><input type="radio" name="aa_storage" value="yes"></td>
							<td class="px-2 py-1"><input type="radio" name="aa_storage" value="no" checked></td>
						</tr>
						<tr id="aa_storage_times" class="hidden">
							<td></td>
							<td class="px-2 py-1 text-right">In/Out Date & Time</td>
							<td colspan="2" class="px-2 py-1">
								<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
									<input id="aa_in" type="datetime-local" class="border rounded px-2 py-1 w-full" placeholder="In at" />
									<input id="aa_out" type="datetime-local" class="border rounded px-2 py-1 w-full" placeholder="Out at" />
								</div>
							</td>
						</tr>
						<tr>
							<td class="px-2 py-1">2</td>
							<td class="px-2 py-1">If garbage staying at storage for more than 48hrs, Permission taken from Bio security.</td>
							<td class="px-2 py-1"><input type="radio" name="perm_48" value="yes" disabled></td>
							<td class="px-2 py-1"><input type="radio" name="perm_48" value="no" checked disabled></td>
						</tr>
						<tr>
							<td class="px-2 py-1">3</td>
							<td class="px-2 py-1">Garbage staying onboard truck for 48hr</td>
							<td class="px-2 py-1"><input type="radio" name="truck_48" value="yes" disabled></td>
							<td class="px-2 py-1"><input type="radio" name="truck_48" value="no" checked disabled></td>
						</tr>
						<tr>
							<td class="px-2 py-1">4</td>
							<td class="px-2 py-1">Bio security inspector booked to witness disposal</td>
							<td class="px-2 py-1"><input type="radio" name="bio_witness" value="yes" disabled></td>
							<td class="px-2 py-1"><input type="radio" name="bio_witness" value="no" checked disabled></td>
						</tr>
						<tr>
							<td class="px-2 py-1">5</td>
							<td class="px-2 py-1">Landfill booked for disposal</td>
							<td class="px-2 py-1"><input type="radio" name="landfill_booked" value="yes" disabled></td>
							<td class="px-2 py-1"><input type="radio" name="landfill_booked" value="no" checked disabled></td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="p-3 rounded border bg-gray-50">
				<p class="font-medium mb-2">Contingency Plan</p>
				<ol class="list-decimal pl-5 space-y-1 text-gray-700">
					<li>Any spillages subject to biosecurity control from the vehicle must be reported immediately to 1800 020 504 and Supervisor.</li>
					<li>Any spillage inside the vehicle must be reported and cleaned under direction of an Accredited Person at the receiving AA site.</li>
					<li>Clean with recommended disinfectants and enter the name of the AA accredited person.</li>
				</ol>
			</div>
		</div>
	`;

	UIComponents.openModal(`Checklist - ${order.ship_name || ''}`, content, async () => {
		const checklist: Record<string, string> = {};
		for (let i = 0; i < 5; i++) {
			const sel = document.querySelector(`input[name="chk_${i}"]:checked`) as HTMLInputElement | null;
			checklist[`item_${i + 1}`] = sel?.value || '';
		}
		// Additional section values - only items 4 and 5 editable for boat user
			const aaYes = (document.querySelector('input[name="aa_storage"][value="yes"]') as HTMLInputElement | null)?.checked || false;
			const aaIn = (document.getElementById('aa_in') as HTMLInputElement | null)?.value || '';
			const aaOut = (document.getElementById('aa_out') as HTMLInputElement | null)?.value || '';
		checklist['bio_witness'] = (document.querySelector('input[name="bio_witness"]:checked') as HTMLInputElement | null)?.value || 'no';
		checklist['landfill_booked'] = (document.querySelector('input[name="landfill_booked"]:checked') as HTMLInputElement | null)?.value || 'no';
		const payload = {
			vessel_checklist_meta: {
				ship_name: (document.getElementById('v_ship_name') as HTMLInputElement | null)?.value || '',
				flag: (document.getElementById('v_flag') as HTMLInputElement | null)?.value || '',
				imo_no: (document.getElementById('v_imo') as HTMLInputElement | null)?.value || '',
				berth: (document.getElementById('v_berth') as HTMLInputElement | null)?.value || '',
				port: (document.getElementById('v_port') as HTMLInputElement | null)?.value || '',
				date: (document.getElementById('v_date') as HTMLInputElement | null)?.value || '',
				time: (document.getElementById('v_time') as HTMLInputElement | null)?.value || '',
				total_volume: parseFloat((document.getElementById('v_total') as HTMLInputElement | null)?.value || '0') || 0,
				master_signature: (document.getElementById('v_master') as HTMLInputElement | null)?.value || ''
			},
			collecting_boat: {
				accredited_person_1: (document.getElementById('c_aa_person') as HTMLInputElement | null)?.value || '',
				boat_name: (document.getElementById('c_boat') as HTMLInputElement | null)?.value || '',
				accredited_person_2: (document.getElementById('c_aa_person2') as HTMLInputElement | null)?.value || '',
				truck_reg: (document.getElementById('c_truck') as HTMLInputElement | null)?.value || '',
				disposal_time: (document.getElementById('c_disposal') as HTMLInputElement | null)?.value || ''
			},
			collecting_checklist: checklist,
			aa_storage: aaYes,
			aa_storage_in_at: aaIn || null,
			aa_storage_out_at: aaOut || null,
			contingency_plan: (document.getElementById('c_contingency') as HTMLTextAreaElement | null)?.value || ''
		};
		await fetch(`${apiBase}/discharge-forms/${order.id}/`, {
			method: 'PATCH',
			headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('access')}` },
			body: JSON.stringify(payload)
		}).then(res => { if (!res.ok) throw new Error('HTTP ' + res.status); });
	});

	// After modal render: wire AA storage toggle to show/hide times row
	const aaYesEl = document.querySelector('input[name="aa_storage"][value="yes"]') as HTMLInputElement | null;
	const aaNoEl = document.querySelector('input[name="aa_storage"][value="no"]') as HTMLInputElement | null;
	const timesRow = document.getElementById('aa_storage_times');
	const updateTimesVisibility = () => {
		if (!timesRow) return;
		const yes = !!aaYesEl?.checked;
		timesRow.classList.toggle('hidden', !yes);
	};
	aaYesEl?.addEventListener('change', updateTimesVisibility);
	aaNoEl?.addEventListener('change', updateTimesVisibility);
	updateTimesVisibility();
}



