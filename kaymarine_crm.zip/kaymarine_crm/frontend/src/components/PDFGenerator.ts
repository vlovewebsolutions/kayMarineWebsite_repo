import jsPDF from 'jspdf';

/**
 * PDF Generator for Discharge Forms
 * Handles generation of PDF documents for discharge forms
 */
export class PDFGenerator {
  static sanitizeFilePart(value: string): string {
    return (value || '')
      .replace(/[\\/:*?"<>|]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 60);
  }

  
  /**
   * Capture an HTML element and download as paginated A4 PDF.
   * This preserves the exact Tailwind/modal styling (same-to-same design).
   */
  static async downloadElementAsPDF(element: HTMLElement, fileName: string) {
    const { default: html2canvas } = await import('html2canvas');
  
    const wrapper = document.createElement('div');
  
    wrapper.style.position = 'fixed';
    wrapper.style.left = '-10000px';
    wrapper.style.top = '0';
    wrapper.style.width = '794px';
    wrapper.style.background = 'white';
    wrapper.style.zIndex = '99999';
  
    const clone = element.cloneNode(true) as HTMLElement;
  
    clone.style.background = 'white';
    clone.style.width = '794px';
  
    /**
     * IMPORTANT FIX:
     * Copy values from ORIGINAL inputs → CLONED inputs
     * Then replace cloned inputs with layout-safe div blocks
     */
  
    const originalInputs = element.querySelectorAll('input, textarea');
    const clonedInputs = clone.querySelectorAll('input, textarea');
  
    originalInputs.forEach((origInput, index) => {
      const original = origInput as HTMLInputElement;
      const cloned = clonedInputs[index] as HTMLElement;

      if (!cloned) return;

      const replacement = document.createElement('div');

      // Force layout-safe block rendering
      replacement.style.display = 'block';
      replacement.style.width = '100%';
      replacement.style.height = '38px';
      replacement.style.padding = '6px 10px';
      replacement.style.marginTop = '6px';
      replacement.style.boxSizing = 'border-box';

      replacement.style.border = '1px solid #d1d5db';
      replacement.style.borderRadius = '6px';
      replacement.style.background = '#ffffff';

      replacement.style.fontSize = '14px';
      replacement.style.lineHeight = '24px';

      // Prevent overlap with label text
      const parentLabel = cloned.closest('label');
      if (parentLabel) {
        parentLabel.style.display = 'block';
      }

      if (original.type === 'radio') {

        replacement.style.textAlign = 'center';
        replacement.textContent = original.checked ? '●' : '';

      } else if (original.type === 'checkbox') {

        replacement.style.textAlign = 'center';
        replacement.textContent = original.checked ? '☑' : '';

      } else {

        replacement.textContent =
          original.value?.replace('T', ' ') || '';

      }

      cloned.replaceWith(replacement);
    });
  
    wrapper.appendChild(clone);
    document.body.appendChild(wrapper);
  
    try {
      const canvas = await html2canvas(clone, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        windowWidth: 794,
  
        /**
         * Tailwind v4 OKLCH → RGB fallback
         */
        onclone: (doc) => {
          doc.querySelectorAll('*').forEach((el) => {
            const style = doc.defaultView?.getComputedStyle(el);
  
            if (!style) return;
  
            if (style.color.includes('oklch')) {
              (el as HTMLElement).style.color = '#000000';
            }
  
            if (style.backgroundColor.includes('oklch')) {
              (el as HTMLElement).style.backgroundColor = '#ffffff';
            }
  
            if (style.borderColor.includes('oklch')) {
              (el as HTMLElement).style.borderColor = '#cccccc';
            }
          });
        },
      });
  
      const imgData = canvas.toDataURL('image/png');
  
      const pdf = new jsPDF('p', 'mm', 'a4');
  
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
  
      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
  
      let heightLeft = imgHeight;
      let position = 0;
  
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
  
      heightLeft -= pageHeight;
  
      while (heightLeft > 0) {
        position -= pageHeight;
  
        pdf.addPage();
  
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
  
        heightLeft -= pageHeight;
      }
  
      pdf.save(fileName);
    }
    finally {
      wrapper.remove();
    }
  }
  /**
   * Helper function to load logo image
   */
  static async loadLogoImage(): Promise<string | null> {
    try {
      // Use dynamic base URL that works in both dev and production
      const logoPath = `${import.meta.env.BASE_URL}logo.png`;
      const response = await fetch(logoPath);
      if (!response.ok) {
        console.warn(`Logo not found at ${logoPath}, trying /logo.png`);
        // Fallback to root path
        const fallbackResponse = await fetch('/logo.png');
        if (!fallbackResponse.ok) {
          return null;
        }
        const blob = await fallbackResponse.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(blob);
        });
      }
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error('Failed to load logo:', error);
      return null;
    }
  }

  /**
   * Generate discharge form PDF
   */
  static async generateDischargeFormPDF(formData?: any) {
    const doc = new jsPDF('p', 'mm', 'a4'); // A4 format
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15; // 15mm margins
    const contentWidth = pageWidth - (margin * 2);
    
    // Colors
    const primaryColor = [37, 99, 235]; // Blue
    const textColor = [0, 0, 0]; // Black text

    // Header Section with Logo and Company Info
    // Load and add logo image
    const logoDataUrl = await PDFGenerator.loadLogoImage();
    if (logoDataUrl) {
      doc.addImage(logoDataUrl, 'PNG', margin, 15, 20, 15);
    } else {
      // Fallback to text logo if image fails
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(margin, 15, 20, 15, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('KM', margin + 7, 22);
    }
    
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Kay marine', margin + 22, 20);
    doc.text('Supply and services', margin + 22, 23);

    // Company Information (right side)
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('KAY MARINE PTY LTD', pageWidth - margin, 20, { align: 'right' });
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('A.B.N 44 643 899 414', pageWidth - margin, 24, { align: 'right' });

    let yPosition = 45;

    // Form Title
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('MARPOL Annex V. Garbage Discharge Form', pageWidth / 2, yPosition, { align: 'center' });

    yPosition += 15;

    // Vessel Information Section
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    
    // Two column layout for vessel info
    const leftColX = margin;
    const rightColX = margin + 90;
    
    // Left column
    doc.text('Ship Name:', leftColX, yPosition);
    doc.text(formData?.ship_name || '_________________', leftColX + 25, yPosition);
    
    doc.text('Voyage no.', leftColX, yPosition + 6);
    doc.text(formData?.voyage_no || '_________________', leftColX + 25, yPosition + 6);
    
    doc.text('Flag:', leftColX, yPosition + 12);
    doc.text(formData?.flag || '_________________', leftColX + 25, yPosition + 12);
    
    doc.text('IMO no.:', leftColX, yPosition + 18);
    doc.text(formData?.imo_no || '_________________', leftColX + 25, yPosition + 18);

    // Right column
    doc.text('Berth:', rightColX, yPosition);
    doc.text(formData?.berth || '_________________', rightColX + 15, yPosition);
    
    doc.text('Port:', rightColX, yPosition + 6);
    doc.text(formData?.port || 'Port Hedland', rightColX + 15, yPosition + 6);
    
    doc.text('Type:', rightColX, yPosition + 12);
    doc.text(formData?.vessel_type || '_________________', rightColX + 15, yPosition + 12);
    
    doc.text('Vessel Email:', rightColX, yPosition + 18);
    doc.text(formData?.vessel_email || '_________________', rightColX + 30, yPosition + 18);

    // Date and Time (to the right of Berth and Port)
    doc.text('Date:', rightColX + 60, yPosition);
    doc.text(formData?.date || '____', rightColX + 75, yPosition);
    
    doc.text('Time:', rightColX + 60, yPosition + 6);
    doc.text(formData?.time || '____', rightColX + 75, yPosition + 6);

    yPosition += 25;

    // Allowance Statement
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Vessel allocated one cubic allowance.', margin, yPosition);

    yPosition += 10;

    // MARPOL Annex V. Garbage Table
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    
    // Table headers
    const colWidths = [12, 85, 45, 35];
    let xPos = margin;
    
    doc.text('No.', xPos, yPosition);
    xPos += colWidths[0];
    doc.text('MARPOL Annex V. Garbage', xPos, yPosition);
    xPos += colWidths[1];
    doc.text('Quantity in Meter cubes', xPos, yPosition);
    xPos += colWidths[2];
    doc.text('Origin', xPos, yPosition);
    
    yPosition += 6;

    // Table rows
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    
    // Helper to format origin array as comma-separated string
    const formatOrigin = (originArray: string[] | undefined): string => {
      if (!originArray || !Array.isArray(originArray) || originArray.length === 0) return '';
      return originArray.join(', ');
    };
    
    const garbageCategories = [
      { no: '1', category: 'Cat A. Plastic', quantity: formData?.cat_a_plastic || '0', origin: formatOrigin(formData?.cat_a_plastic_origin) || 'Galley' },
      { no: '2', category: 'Cat. B Food Waste', quantity: 'N/A', origin: 'N/A' },
      { no: '3', category: 'Cat. C Domestic Waste', quantity: formData?.cat_c_domestic || '0', origin: formatOrigin(formData?.cat_c_domestic_waste_origin) },
      { no: '4', category: 'Cat. D Cooking Oil (N/A)', quantity: 'N/A', origin: 'N/A' },
      { no: '5', category: 'Cat. E Incinerator Ashes', quantity: formData?.cat_e_incinerator || '0', origin: formatOrigin(formData?.cat_e_incinerator_ashes_origin) },
      { no: '6', category: 'Cat. F Operational Waste', quantity: formData?.cat_f_operational || '0', origin: formatOrigin(formData?.cat_f_operational_waste_origin) },
      { no: '7', category: 'Cat. G Animal carcass(es)', quantity: formData?.cat_g_cargo || '0', origin: formatOrigin(formData?.cat_g_cargo_residue_origin) },
      { no: '8', category: 'Cat. H Fishing gear', quantity: 'N/A', origin: 'N/A' },
      { no: '9', category: 'Cat. I E-waste (No Batteries)', quantity: formData?.cat_i_fishing || '0', origin: formatOrigin(formData?.cat_i_fishing_gear_origin) },
      { no: '10', category: 'Cat. J Cargo residues (non-Harmful to the Marine Environment)', quantity: formData?.cat_j_other || '0', origin: formatOrigin(formData?.cat_j_other_e_waste_origin) }
    ];

    garbageCategories.forEach(row => {
      xPos = margin;
      doc.text(row.no, xPos, yPosition);
      xPos += colWidths[0];
      doc.text(row.category, xPos, yPosition);
      xPos += colWidths[1];
      doc.text(row.quantity, xPos, yPosition);
      xPos += colWidths[2];
      doc.text(row.origin, xPos, yPosition);
      yPosition += 5;
    });

    // Total row
    yPosition += 3;
    doc.setFont('helvetica', 'bold');
    doc.text('Total Vol:', margin, yPosition);
    doc.text(formData?.total_volume || '1', margin + colWidths[0] + colWidths[1], yPosition);
    
    yPosition += 15;
    
    // Garbage Discharge Section
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('VESSEL PLANNED TO DISCHARGE', margin, yPosition);
    
    yPosition += 8;
    
    // Table headers
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('No.', margin, yPosition);
    doc.text('MARPOL Annex V. Garbage', margin + 10, yPosition);
    doc.text('Quantity (m³)', margin + 100, yPosition);
    doc.text('Origin', margin + 130, yPosition);
    
    yPosition += 3;

    // Draw table header line
    doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setLineWidth(0.3);
    doc.line(margin, yPosition, pageWidth - margin, yPosition);

    yPosition += 6;
    
    // Signature section - check if we need new page
    if (yPosition > pageHeight - 60) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('SIGNATURES', margin, yPosition);

    yPosition += 8;

    // Signature fields - aligned 3-column layout
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');

    const colWidth = Math.floor(contentWidth / 3);
    const colXs = [margin, margin + colWidth, margin + 2 * colWidth];
    const labels = ['Vessel Master', 'Port Authority', 'Waste Collection Service'];

    const lineLeftPadding = 28; // space reserved for label text
    const lineRightPadding = 8;
    const dateLabelWidth = 18; // 'Date:' width allocation before the line

    // First row of signature blocks
    for (let i = 0; i < labels.length; i++) {
      const x = colXs[i];
      // Label
      doc.text(`${labels[i]}:`, x, yPosition);
      // Signature line (same row)
      doc.setDrawColor(200, 200, 200);
      doc.setLineWidth(0.2);
      const sigLineStart = x + lineLeftPadding;
      const sigLineEnd = x + colWidth - lineRightPadding;
      doc.line(sigLineStart, yPosition - 0.5, sigLineEnd, yPosition - 0.5);

      // Date label and line beneath with consistent spacing
      const dateY = yPosition + 7;
      doc.text('Date:', x, dateY);
      const dateLineStart = x + dateLabelWidth;
      const dateLineEnd = x + colWidth - lineRightPadding;
      doc.line(dateLineStart, dateY - 0.5, dateLineEnd, dateY - 0.5);
    }

    // Advance below signature blocks
    yPosition += 16;
    
    // Signature line
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Master\'s Name & Signature', pageWidth - margin - 60, yPosition);
    doc.line(pageWidth - margin - 60, yPosition + 2, pageWidth - margin, yPosition + 2);
    
    yPosition += 20;

    // Instructions section
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    
    const instructions = [
      '* Only nonperishables garbage',
      '* Please declare exact volume to be discharged and origin Galley/Accommodation/ER/Bridge etc.',
      '* Please double, all the bags of garbage before dumping them into the supplied bulk bag inside bin..',
      '* How much garbage remaining on board . __________Cubic',
      '* Would you like to discharge more if Port allowance is available? Yes/No',
      '** if yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.'
    ];

    instructions.forEach(instruction => {
      doc.text(instruction, margin, yPosition);
      yPosition += 4;
    });

    // Generate filename
    const timestamp = new Date().toISOString().split('T')[0];
    const fileName = formData ? `Discharge_Form_${formData.ship_name || 'Vessel'}_${timestamp}.pdf` : `Blank_Discharge_Form_${timestamp}.pdf`;

    doc.save(fileName);
  }
  
  /**
   * Download blank discharge form PDF
   */
  static async downloadBlankForm() {
    await PDFGenerator.generateDischargeFormPDF();
  }
  
  /**
   * Download filled discharge form PDF
   */
  static async downloadFilledForm(formData: any) {
    await PDFGenerator.generateDischargeFormPDF(formData);
  }

  /**
   * Download Vessel Checklist PDF for Boat User
   */
  static async downloadBoatChecklistPDF(formData: any) {
    await PDFGenerator.generateBoatChecklistPDF(formData);
  }

  /**
   * Download Vessel Checklist PDF using the live modal HTML (same-to-same design).
   */
  static async downloadBoatChecklistFromModal(modalBodyEl: HTMLElement, shipName?: string) {
    const timestamp = new Date().toISOString().split('T')[0];
    const safeShip = PDFGenerator.sanitizeFilePart(shipName || 'Vessel');
    const fileName = `Boat_Checklist_${safeShip}_${timestamp}.pdf`;
    await PDFGenerator.downloadElementAsPDF(modalBodyEl, fileName);
  }

  /**
   * Generate Boat User Vessel Checklist PDF
   */
  static async generateBoatChecklistPDF(formData?: any) {
    const doc = new jsPDF('p', 'mm', 'a4'); // A4 format
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15;
    const contentWidth = pageWidth - margin * 2;

    // Colors
    const textColor = [0, 0, 0];
    const primaryColor = [37, 99, 235]; // Blue

    const wrapText = (text: string, x: number, y: number, maxWidth: number, lineHeight = 4) => {
      const lines = doc.splitTextToSize(text || '', maxWidth);
      lines.forEach((line: string, idx: number) => {
        doc.text(line, x, y + idx * lineHeight);
      });
      return lines.length;
    };

    const formatDateTime = (value: any) => {
      if (!value) return '';
      const str = String(value);
      return str.includes('T') ? str.replace('T', ' ') : str;
    };

    const ensureSpace = (neededY: number) => {
      if (yPosition + neededY > pageHeight - 15) {
        doc.addPage();
        yPosition = 20;
      }
    };

    // Header with logo + company info (same style as discharge form)
    const logoDataUrl = await PDFGenerator.loadLogoImage();
    if (logoDataUrl) {
      doc.addImage(logoDataUrl, 'PNG', margin, 12, 20, 15);
    } else {
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(margin, 12, 20, 15, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('KM', margin + 7, 21);
    }

    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Kay marine', margin + 22, 12);
    doc.text('Supply and services', margin + 22, 15);

    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('KAY MARINE PTY LTD', pageWidth - margin, 12, { align: 'right' });
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('A.B.N 44 643 899 414', pageWidth - margin, 16, { align: 'right' });

    const vesselMeta = formData?.vessel_checklist_meta || {};
    const collectingBoat = formData?.collecting_boat || {};
    const collectingChecklist = formData?.collecting_checklist || {};

    const vesselShipName = vesselMeta?.ship_name || '';

    let yPosition = 35;
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Vessel Checklist', pageWidth / 2, yPosition, { align: 'center' });
    yPosition += 12;

    // Two column layout for vessel info
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    const leftColX = margin;
    const rightColX = margin + 95;
    const leftValueX = leftColX + 35;
    const rightValueX = rightColX + 35;
    const leftValueMaxW = Math.max(30, rightColX - margin - (35 + 2));
    const rightValueMaxW = Math.max(30, pageWidth - margin - rightValueX);

    let yLeft = yPosition;
    let yRight = yPosition;
    const keyH = 5;
    const valLineH = 4;

    const printLeftKV = (label: string, value: string) => {
      doc.text(`${label}:`, leftColX, yLeft);
      const linesCount = wrapText(value, leftValueX, yLeft - 1, leftValueMaxW, valLineH);
      yLeft += Math.max(keyH, linesCount * valLineH) + 2;
    };

    const printRightKV = (label: string, value: string) => {
      doc.text(`${label}:`, rightColX, yRight);
      const linesCount = wrapText(value, rightValueX, yRight - 1, rightValueMaxW, valLineH);
      yRight += Math.max(keyH, linesCount * valLineH) + 2;
    };

    printLeftKV('Ship Name', vesselMeta?.ship_name || '_________________');
    printLeftKV('Flag', vesselMeta?.flag || '_________________');
    printLeftKV('IMO No', vesselMeta?.imo_no || '_________________');
    printLeftKV('Berth', vesselMeta?.berth || '_________________');
    printLeftKV('Port', vesselMeta?.port || '_________________');

    printRightKV('Collection Date & Time', formatDateTime(collectingBoat?.collection_time));
    printRightKV('Total Volume', vesselMeta?.total_volume != null ? String(vesselMeta.total_volume) : '_________________');
    printRightKV("Master's Name & Signature", vesselMeta?.master_signature || '_________________');

    yPosition = Math.max(yLeft, yRight) + 6;

    // Collecting boat checklist section
    ensureSpace(18);
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('Collecting Boat Checklist', margin, yPosition);
    yPosition += 6;
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');

    const labelX = margin;
    const valueX = margin + 58;
    const valMaxW = pageWidth - margin - valueX;

    const printRowKV = (label: string, value: string) => {
      doc.text(`${label}:`, labelX, yPosition);
      const linesCount = wrapText(value, valueX, yPosition - 1, valMaxW, valLineH);
      yPosition += Math.max(keyH, linesCount * valLineH) + 2;
    };

    printRowKV('AA Accredited Person Name & Sign', collectingBoat?.accredited_person_1 || '');
    printRowKV('Collecting Boat Name', collectingBoat?.boat_name || '');
    printRowKV('AA Accredited Person Name & Sign (2)', collectingBoat?.accredited_person_2 || '');
    printRowKV('Truck Reg No', collectingBoat?.truck_reg || '');
    printRowKV('Disposal Date & Time at Landfill', formatDateTime(collectingBoat?.disposal_time));

    // Checklist table
    ensureSpace(30);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Checklist', margin, yPosition);
    yPosition += 4;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');

    const tableX = margin;
    const colNoW = 8;
    const colItemW = 105;
    const colYesW = 22;
    const colNoColW = 22;
    const xNo = tableX;
    const xItem = xNo + colNoW;
    const xYes = xItem + colItemW;
    const xNoCol = xYes + colYesW;

    const checklistRows = [
      { no: '1', label: 'Form 44 submitted', yes: !!formData?.form44_submitted },
      { no: '2', label: 'Clearance taken from Bio Security (Form 44)', yes: collectingChecklist?.bio_security_clearance === 'yes' },
      { no: '3', label: 'Clearance taken from Customs (Form 44)', yes: collectingChecklist?.customs_clearance === 'yes' },
      { no: '4', label: 'Verbal clearance taken on phone for Form 44', yes: collectingChecklist?.verbal_clearance === 'yes' },
      { no: '5', label: 'Checklist for Accredited Person Completed', yes: collectingChecklist?.accredited_person_checklist === 'yes' },
      { no: '6', label: 'Checklist for Driver Completed', yes: collectingChecklist?.driver_checklist === 'yes' },
      { no: '7', label: 'Bio security inspector booked to witness disposal', yes: !!formData?.bio_witness },
      { no: '8', label: 'Landfill booked for disposal', yes: !!formData?.landfill_booked },
    ];

    // Header
    doc.setFont('helvetica', 'bold');
    doc.text('No.', xNo + 1, yPosition);
    doc.text('Checklist Item', xItem, yPosition);
    doc.text('Yes', xYes + 7, yPosition);
    doc.text('No', xNoCol + 8, yPosition);
    yPosition += 3;
    doc.line(tableX, yPosition, tableX + colNoW + colItemW + colYesW + colNoColW, yPosition);

    const lineH = 4;
    const itemMaxW = colItemW - 2;

    for (const row of checklistRows) {
      const itemLines = doc.splitTextToSize(row.label, itemMaxW);
      const rowH = Math.max(6, itemLines.length * lineH) + 2;
      ensureSpace(rowH);

      doc.setFont('helvetica', 'normal');
      doc.text(row.no, xNo + 1, yPosition + 1);
      itemLines.forEach((ln: string, idx: number) => {
        doc.text(ln, xItem, yPosition + 1 + idx * lineH);
      });

      const xMarkY = yPosition + 3;
      if (row.yes) doc.text('X', xYes + 7, xMarkY);
      else doc.text('X', xNoCol + 8, xMarkY);

      yPosition += rowH;
    }

    // Send to Landfill within 48hrs section
    ensureSpace(18);
    yPosition += 2;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Send to Landfill within 48hrs', margin, yPosition);
    yPosition += 6;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);

    const aaRows = [
      { no: '1', label: 'Garbage staying in AA storage', yes: !!formData?.aa_storage },
      { no: '2', label: 'If garbage staying at storage for more than 48hrs, Permission taken from Bio security.', yes: false },
      { no: '3', label: 'Garbage staying onboard truck for 48hr', yes: false },
    ];

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text('No.', xNo + 1, yPosition);
    doc.text('Item', xItem, yPosition);
    doc.text('Yes', xYes + 7, yPosition);
    doc.text('No', xNoCol + 8, yPosition);
    yPosition += 3;
    doc.line(tableX, yPosition, tableX + colNoW + colItemW + colYesW + colNoColW, yPosition);

    for (const row of aaRows) {
      const itemLines = doc.splitTextToSize(row.label, itemMaxW);
      const rowH = Math.max(6, itemLines.length * lineH) + 2;
      ensureSpace(rowH);

      doc.setFont('helvetica', 'normal');
      doc.text(row.no, xNo + 1, yPosition + 1);
      itemLines.forEach((ln: string, idx: number) => {
        doc.text(ln, xItem, yPosition + 1 + idx * lineH);
      });

      const xMarkY = yPosition + 3;
      if (row.yes) doc.text('X', xYes + 7, xMarkY);
      else doc.text('X', xNoCol + 8, xMarkY);

      yPosition += rowH;
    }

    // In/Out Date & Time if AA storage is Yes
    if (formData?.aa_storage) {
      const aaIn = formatDateTime(formData?.aa_storage_in_at);
      const aaOut = formatDateTime(formData?.aa_storage_out_at);
      const needed = 16;
      ensureSpace(needed);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.text('In/Out Date & Time:', margin, yPosition + 2);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      wrapText(`In: ${aaIn}`, margin + 35, yPosition + 6, contentWidth - 35, 5);
      wrapText(`Out: ${aaOut}`, margin + 35, yPosition + 12, contentWidth - 35, 5);
      yPosition += 22;
    }

    // Contingency Plan
    ensureSpace(18);
    yPosition += 4;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Contingency Plan', margin, yPosition);
    yPosition += 6;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);

    const contingencyPlanText = formData?.contingency_plan || '';
    const contingencyItems = String(contingencyPlanText)
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const contingency = contingencyItems.length
      ? contingencyItems
      : [
          'Any spillages subject to biosecurity control from the vehicle must be reported immediately to 1800 020 504 and Supervisor.',
          'Any spillage inside the vehicle must be reported and cleaned under direction of an Accredited Person at the receiving AA site.',
          'Clean with recommended disinfectants and enter the name of the AA accredited person.'
        ];

    contingency.forEach((item: string, idx: number) => {
      ensureSpace(6);
      wrapText(`${idx + 1}. ${item}`, margin, yPosition, contentWidth, 5);
      yPosition += 8;
    });

    // Generate filename
    const timestamp = new Date().toISOString().split('T')[0];
    const fileName = `Boat_Checklist_${vesselShipName || 'Vessel'}_${timestamp}.pdf`;
    doc.save(fileName);
  }
}

