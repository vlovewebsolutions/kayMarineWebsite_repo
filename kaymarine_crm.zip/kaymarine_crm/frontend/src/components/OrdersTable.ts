import { formatDateInput, formatTimeInput } from '../utils/dates';

export function renderAdminOrdersTable(orders: any[]): string {
	return `
		<div class="overflow-x-auto">
			<table class="min-w-full divide-y divide-gray-200">
				<thead class="bg-gray-50">
					<tr>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ship Name</th>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Berth</th>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Port</th>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Flag</th>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Volume</th>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
						<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
					</tr>
				</thead>
				<tbody class="bg-white divide-y divide-gray-200">
					${orders.map((order: any) => `
						<tr class="hover:bg-gray-50">
							<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${order.ship_name}</td>
							<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${new Date(order.date).toLocaleDateString()}</td>
							<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.berth || '-'}</td>
							<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.port}</td>
							<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.flag || '-'}</td>
							<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.total_volume ? order.total_volume + ' m³' : '-'}</td>
							<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${new Date(order.created_at).toLocaleString()}</td>
							<td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
								<button onclick="viewOrderDetails(${order.id})" class="text-blue-600 hover:text-blue-900 mr-3">Operations</button>
								<button onclick="editOrder(${order.id})" class="text-green-600 hover:text-green-900 mr-3">Edit</button>
								<button onclick="downloadOrderPDF(${order.id})" class="text-purple-600 hover:text-purple-900 mr-3">PDF</button>
								<button onclick="deleteOrder(${order.id})" class="text-red-600 hover:text-red-900">Delete</button>
							</td>
						</tr>
					`).join('')}
				</tbody>
			</table>
		</div>`;
}

export function renderBoatOrdersTable(orders: any[]): string {
	return `
		<table class="min-w-full divide-y divide-gray-200">
			<thead class="bg-gray-50">
				<tr>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ship Name</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IMO No</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Berth</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ETB</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Flag</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Amount</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Schedule</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
				</tr>
			</thead>
			<tbody class="bg-white divide-y divide-gray-200">
				${orders.map((o: any) => `
					<tr>
						<td class="px-6 py-4 text-sm text-gray-900">${o.ship_name}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.imo_no || '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.berth || '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.etb ? new Date(o.etb).toLocaleString() : '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.flag || '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-900">${o.total_amount != null ? o.total_amount : '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-700">
							<div class="flex items-center gap-2">
								<input id="sched_date_${o.id}" type="date" value="${formatDateInput(o.scheduled_offload_at)}" class="border rounded px-2 py-1" />
								<input id="sched_time_${o.id}" type="time" value="${formatTimeInput(o.scheduled_offload_at)}" class="border rounded px-2 py-1" />
								<button class="text-blue-600 hover:text-blue-900" onclick="setSchedule(${o.id})">Set</button>
							</div>
						</td>
						<td class="px-6 py-4 text-sm">
							<button class="text-blue-600 hover:text-blue-900" onclick="boatOrderView(${o.id})">View</button>
						</td>
					</tr>
				`).join('')}
			</tbody>
		</table>`;
}



