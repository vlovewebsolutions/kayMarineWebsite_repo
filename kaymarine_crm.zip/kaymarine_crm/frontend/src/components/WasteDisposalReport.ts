﻿/**
 * Waste Disposal List Excel export (Reports tab)
 * Styled workbook matching Kay Marine waste disposal list format.
 */

import ExcelJS from 'exceljs';
import { listOrders } from '../services/orders';
import { calculateTotalQuantities, roundQuantity } from './CertificateGenerator';

const HEADERS = [
  'S.No',
  'Name',
  'Total Volume in Cubic',
  'Last 12 Month',
  'Cat A. Plastic',
  'Cat. C Domestic Waste',
  'Cat. E Incinerator Ashes',
  'Cat. F Operational Waste',
  'Cat. G Cargo residue',
  'Cat. I Fishing Gear',
  'Cat. J Other (E-Waste)',
  'Remark',
] as const;

const COL_COUNT = HEADERS.length; // B..M => 12 cols
const FIRST_COL = 2; // column B
const LAST_COL = FIRST_COL + COL_COUNT - 1;

const COLORS = {
  company: '0F4C81',
  titleBg: 'E8F1F8',
  headerBg: '1B6CA8',
  headerFg: 'FFFFFF',
  altRow: 'F3F8FC',
  noDisposal: 'FFF4E5',
  noDisposalText: '9A6700',
  totalBg: 'D1E7DD',
  totalFg: '0F5132',
  border: 'B6C9D8',
  thinBorder: 'D0D7DE',
};

function ordinal(day: number): string {
  const j = day % 10;
  const k = day % 100;
  if (k === 11 || k === 12 || k === 13) return `${day}th`;
  if (j === 1) return `${day}st`;
  if (j === 2) return `${day}nd`;
  if (j === 3) return `${day}rd`;
  return `${day}th`;
}

function formatTitleDate(d: Date, shortMonth = false): string {
  const months = shortMonth
    ? ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    : ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  return `${ordinal(d.getDate())} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

function formatFileDate(d: Date): string {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${months[d.getMonth()]} ${String(d.getDate()).padStart(2, '0')} ${d.getFullYear()}`;
}

function monthKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

function firstOfMonth(year: number, monthIndex: number): Date {
  return new Date(year, monthIndex, 1);
}

function getOrderDate(order: any): Date | null {
  const raw = order.collecting_boat?.collection_time || order.date || order.created_at;
  if (!raw) return null;
  const d = new Date(raw);
  return Number.isNaN(d.getTime()) ? null : d;
}

function getPort(orders: any[]): string {
  for (const o of orders) {
    if (o.port) return o.port;
  }
  return 'Port Hedland';
}

function filterOrdersByDateRange(
  orders: any[],
  startDate?: Date | null,
  endDate?: Date | null
): any[] {
  if (!startDate && !endDate) return orders;

  return orders.filter((o) => {
    const d = getOrderDate(o);
    if (!d) return false;
    if (startDate && d < startDate) return false;
    if (endDate && d > endDate) return false;
    return true;
  });
}

interface ReportRow {
  name: string | null;
  date: Date;
  cat_a: number | null;
  cat_c: number | null;
  cat_e: number | null;
  cat_f: number | null;
  cat_g: number | null;
  cat_i: number | null;
  cat_j: number | null;
  remark: string | null;
}

function buildReportRows(orders: any[], startDate: Date, endDate: Date): ReportRow[] {
  const disposals: ReportRow[] = [];

  for (const order of orders) {
    const date = getOrderDate(order);
    if (!date) continue;
    const totals = calculateTotalQuantities(order);
    disposals.push({
      name: order.ship_name || null,
      date,
      cat_a: totals.cat_a_plastic,
      cat_c: totals.cat_c_domestic_waste,
      cat_e: totals.cat_e_incinerator_ashes,
      cat_f: totals.cat_f_operational_waste,
      cat_g: totals.cat_g_cargo_residue,
      cat_i: totals.cat_i_fishing_gear,
      cat_j: totals.cat_j_other_e_waste,
      remark: null,
    });
  }

  disposals.sort((a, b) => a.date.getTime() - b.date.getTime());

  const monthsWithDisposal = new Set(disposals.map((r) => monthKey(r.date)));
  const emptyMonths: ReportRow[] = [];
  const cursor = firstOfMonth(startDate.getFullYear(), startDate.getMonth());
  const endMonth = firstOfMonth(endDate.getFullYear(), endDate.getMonth());

  while (cursor <= endMonth) {
    const key = monthKey(cursor);
    if (!monthsWithDisposal.has(key)) {
      emptyMonths.push({
        name: null,
        date: new Date(cursor),
        cat_a: null,
        cat_c: null,
        cat_e: null,
        cat_f: null,
        cat_g: null,
        cat_i: null,
        cat_j: null,
        remark: 'No Disposal',
      });
    }
    cursor.setMonth(cursor.getMonth() + 1);
  }

  return [...disposals, ...emptyMonths].sort((a, b) => a.date.getTime() - b.date.getTime());
}

function readKpiDateRange(): { startDate: Date | null; endDate: Date | null } {
  const startInput = document.getElementById('kpiStartDate') as HTMLInputElement | null;
  const endInput = document.getElementById('kpiEndDate') as HTMLInputElement | null;

  let startDate: Date | null = null;
  let endDate: Date | null = null;

  if (startInput?.value) {
    startDate = new Date(startInput.value);
    startDate.setHours(0, 0, 0, 0);
  }
  if (endInput?.value) {
    endDate = new Date(endInput.value);
    endDate.setHours(23, 59, 59, 999);
  }

  return { startDate, endDate };
}

function thinBorder(color = COLORS.thinBorder): Partial<ExcelJS.Borders> {
  const side: Partial<ExcelJS.Border> = { style: 'thin', color: { argb: `FF${color}` } };
  return { top: side, left: side, bottom: side, right: side };
}

function applyFill(cell: ExcelJS.Cell, argb: string) {
  cell.fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: `FF${argb}` },
  };
}

async function downloadWorkbook(workbook: ExcelJS.Workbook, filename: string) {
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export class WasteDisposalReport {
  static async export(): Promise<void> {
    let orders = await listOrders();
    let { startDate, endDate } = readKpiDateRange();

    orders = filterOrdersByDateRange(orders, startDate, endDate);

    if (!startDate || !endDate) {
      const dates: Date[] = [];
      for (const order of orders) {
        const d = getOrderDate(order);
        if (d) dates.push(d);
      }
      dates.sort((a: Date, b: Date) => a.getTime() - b.getTime());

      if (dates.length === 0) {
        throw new Error(
          'No disposal orders found to export. Apply a date range or ensure orders exist.'
        );
      }
      if (!startDate) {
        startDate = new Date(dates[0]);
        startDate.setHours(0, 0, 0, 0);
      }
      if (!endDate) {
        endDate = new Date(dates[dates.length - 1]);
        endDate.setHours(23, 59, 59, 999);
      }
    }

    const rows = buildReportRows(orders, startDate, endDate);
    const port = getPort(orders);
    const title = `Waste Disposal At ${port}  ${formatTitleDate(startDate)} to ${formatTitleDate(endDate, true)}`;

    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'Kay Marine CRM';
    const ws = workbook.addWorksheet('Waste Disposal', {
      views: [{ state: 'frozen', ySplit: 4 }],
    });

    // Column widths (A spacer + B..M)
    ws.getColumn(1).width = 3;
    const widths = [7, 24, 14, 13, 12, 14, 14, 14, 13, 13, 14, 14];
    widths.forEach((w, i) => {
      ws.getColumn(FIRST_COL + i).width = w;
    });

    // Row 2 — company title
    ws.mergeCells(2, FIRST_COL, 2, LAST_COL);
    const companyCell = ws.getCell(2, FIRST_COL);
    companyCell.value = 'KAY MARINE PTY LTD';
    companyCell.font = { name: 'Calibri', size: 22, bold: true, color: { argb: 'FFFFFFFF' } };
    companyCell.alignment = { horizontal: 'center', vertical: 'middle' };
    applyFill(companyCell, COLORS.company);
    ws.getRow(2).height = 36;
    for (let c = FIRST_COL; c <= LAST_COL; c++) {
      applyFill(ws.getCell(2, c), COLORS.company);
      ws.getCell(2, c).border = thinBorder(COLORS.company);
    }

    // Row 3 — subtitle / date range
    ws.mergeCells(3, FIRST_COL, 3, LAST_COL);
    const titleCell = ws.getCell(3, FIRST_COL);
    titleCell.value = title;
    titleCell.font = { name: 'Calibri', size: 12, bold: true, color: { argb: `FF${COLORS.company}` } };
    titleCell.alignment = { horizontal: 'center', vertical: 'middle' };
    applyFill(titleCell, COLORS.titleBg);
    ws.getRow(3).height = 24;
    for (let c = FIRST_COL; c <= LAST_COL; c++) {
      applyFill(ws.getCell(3, c), COLORS.titleBg);
      ws.getCell(3, c).border = thinBorder(COLORS.border);
    }

    // Row 4 — headers
    const headerRow = ws.getRow(4);
    headerRow.height = 42;
    HEADERS.forEach((header, i) => {
      const cell = ws.getCell(4, FIRST_COL + i);
      cell.value = header;
      cell.font = { name: 'Calibri', size: 10, bold: true, color: { argb: `FF${COLORS.headerFg}` } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      applyFill(cell, COLORS.headerBg);
      cell.border = thinBorder(COLORS.border);
    });

    // Data rows
    let grandTotal = 0;
    const firstDataRow = 5;

    rows.forEach((row, index) => {
      const excelRow = firstDataRow + index;
      const isEmpty = row.remark === 'No Disposal';
      const cats = isEmpty
        ? [null, null, null, null, null, null, null]
        : [
            roundQuantity(row.cat_a),
            roundQuantity(row.cat_c),
            roundQuantity(row.cat_e),
            roundQuantity(row.cat_f),
            roundQuantity(row.cat_g),
            roundQuantity(row.cat_i),
            roundQuantity(row.cat_j),
          ];

      const total = isEmpty
        ? null
        : roundQuantity((cats as number[]).reduce((sum, v) => sum + (v || 0), 0));

      if (total != null) grandTotal = roundQuantity(grandTotal + total);

      const values: (string | number | Date | null)[] = [
        index + 1,
        row.name,
        total,
        row.date,
        ...cats,
        row.remark,
      ];

      const bg = isEmpty ? COLORS.noDisposal : index % 2 === 1 ? COLORS.altRow : 'FFFFFF';

      values.forEach((value, i) => {
        const cell = ws.getCell(excelRow, FIRST_COL + i);
        cell.value = value as ExcelJS.CellValue;
        cell.font = {
          name: 'Calibri',
          size: 11,
          italic: isEmpty,
          color: { argb: isEmpty ? `FF${COLORS.noDisposalText}` : 'FF1F2328' },
        };
        cell.alignment = {
          horizontal: i === 1 || i === 11 ? 'left' : 'center',
          vertical: 'middle',
        };
        applyFill(cell, bg);
        cell.border = thinBorder(COLORS.thinBorder);

        if (i === 3 && value instanceof Date) {
          cell.numFmt = 'mmm-yy';
        }
        if ((i === 2 || (i >= 4 && i <= 10)) && typeof value === 'number') {
          cell.numFmt = '0.00';
        }
      });

      ws.getRow(excelRow).height = 20;
    });

    // Total row
    const totalRowNum = firstDataRow + rows.length + 2;
    const labelCell = ws.getCell(totalRowNum, FIRST_COL + 1);
    labelCell.value = 'Total Volume in cubics';
    labelCell.font = { name: 'Calibri', size: 11, bold: true, color: { argb: `FF${COLORS.totalFg}` } };
    labelCell.alignment = { horizontal: 'right', vertical: 'middle' };
    applyFill(labelCell, COLORS.totalBg);
    labelCell.border = thinBorder(COLORS.border);

    const totalCell = ws.getCell(totalRowNum, FIRST_COL + 2);
    totalCell.value = grandTotal;
    totalCell.numFmt = '0.00';
    totalCell.font = { name: 'Calibri', size: 12, bold: true, color: { argb: `FF${COLORS.totalFg}` } };
    totalCell.alignment = { horizontal: 'center', vertical: 'middle' };
    applyFill(totalCell, COLORS.totalBg);
    totalCell.border = thinBorder(COLORS.border);

    // Fill remaining total-row cells for a continuous bar look
    for (const col of [FIRST_COL, FIRST_COL + 3, FIRST_COL + 4, FIRST_COL + 5, FIRST_COL + 6, FIRST_COL + 7, FIRST_COL + 8, FIRST_COL + 9, FIRST_COL + 10, FIRST_COL + 11]) {
      const cell = ws.getCell(totalRowNum, col);
      applyFill(cell, COLORS.totalBg);
      cell.border = thinBorder(COLORS.border);
    }
    ws.getRow(totalRowNum).height = 24;

    const filename = `Waste disposal list - ${formatFileDate(startDate)} to ${formatFileDate(endDate)}.xlsx`;
    await downloadWorkbook(workbook, filename);
  }
}
