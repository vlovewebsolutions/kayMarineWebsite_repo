function renderBoatUserDashboard() {
  app.innerHTML = `
    <div class="min-h-dvh bg-gray-50">
      <header class="bg-white shadow-lg border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-20">
            <div class="flex items-center space-x-3">
              <img src="/logo.png" class="h-12 w-12 rounded-full border-2 border-blue-100" />
              <div>
                <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                <p class="text-sm text-gray-500">Boat Company View</p>
              </div>
            </div>
            <button id="logout" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">Logout</button>
          </div>
        </div>
      </header>

      <div class="max-w-7xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow">
          <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6">
              <button id="boatOrdersTab" class="py-4 px-1 border-b-2 border-blue-500 font-medium text-blue-600">Orders</button>
              <button id="receiptsTab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Landfill Receipts</button>
            </nav>
          </div>
          <div id="boatOrdersView" class="p-6">
            <div id="boatOrdersTable" class="overflow-x-auto"></div>
          </div>
          <div id="receiptsView" class="p-6 hidden">
            <div class="space-y-4">
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Select Order</label>
                <select id="receipt_order" class="border rounded px-2 py-1"></select>
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Upload Receipt</label>
                <input id="receipt_file" type="file" class="border rounded px-2 py-1" accept="image/*,application/pdf">
              </div>
              <div>
                <button id="uploadReceiptBtn" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Upload</button>
              </div>
              <div id="receiptsList" class="border rounded p-3 bg-gray-50"></div>
            </div>
          </div>
        </div>
      </div>
    </div>`;

  document.getElementById('logout')!.addEventListener('click', logout);
  loadBoatOrders();
  // Tabs
  document.getElementById('boatOrdersTab')!.addEventListener('click', () => switchBoatTab('orders'));
  document.getElementById('receiptsTab')!.addEventListener('click', () => switchBoatTab('receipts'));
  // Init receipts tab
  initReceiptsTab();
  // Wire up Additional button in boat view if present later
  const addBtn = document.getElementById('additionalDetails');
  if (addBtn) addBtn.addEventListener('click', openAdditionalDetailsModal);
}

async function loadBoatOrders() {
  const table = document.getElementById('boatOrdersTable')!;
  UIComponents.showLoadingSpinner(table, 'Loading orders...');
  try {
    const orders = await listOrders();
    // Sort: jobs with ETB first (desc by ETB), then without ETB (desc by ETA)
    orders.sort(compareOrdersByEtbEta);
    table.innerHTML = renderBoatOrdersTable(orders);
  } catch (e) {
    table.innerHTML = `<div class="text-center text-red-600">Failed to load orders</div>`;
  }
}

(window as any).boatOrderView = async (orderId: number) => {
  try {
    const order = await getOrder(orderId);
    openBoatChecklistModal(order);
  } catch (e) {
    UIComponents.showAlert('Failed to load order', 'error');
  }
}
import './index.css'
// dates used via components
import { compareOrdersByEtbEta } from './utils/sort'
import { UIComponents } from './utils/ui'
import { getOrder, listOrders, patchOrder, deleteOrderReq } from './services/orders'
import { uploadReceipt } from './services/orders'
import { openBoatChecklistModal } from './components/BoatChecklistModal'
import { openEditOrderModal } from './components/EditOrderModal'
import { renderAdminOrdersTable, renderBoatOrdersTable } from './components/OrdersTable'
import jsPDF from 'jspdf';

const apiBase = import.meta.env.VITE_API_BASE || 'http://localhost:8000/api';

const app = document.querySelector<HTMLDivElement>('#app')!;
function switchBoatTab(tab: 'orders' | 'receipts') {
  const ordersView = document.getElementById('boatOrdersView')!;
  const receiptsView = document.getElementById('receiptsView')!;
  const ordersTab = document.getElementById('boatOrdersTab')!;
  const receiptsTab = document.getElementById('receiptsTab')!;
  if (tab === 'orders') {
    ordersView.classList.remove('hidden');
    receiptsView.classList.add('hidden');
    ordersTab.classList.add('border-blue-500', 'text-blue-600');
    ordersTab.classList.remove('border-transparent', 'text-gray-500');
    receiptsTab.classList.add('border-transparent', 'text-gray-500');
    receiptsTab.classList.remove('border-blue-500', 'text-blue-600');
  } else {
    receiptsView.classList.remove('hidden');
    ordersView.classList.add('hidden');
    receiptsTab.classList.add('border-blue-500', 'text-blue-600');
    receiptsTab.classList.remove('border-transparent', 'text-gray-500');
    ordersTab.classList.add('border-transparent', 'text-gray-500');
    ordersTab.classList.remove('border-blue-500', 'text-blue-600');
  }
}

async function initReceiptsTab() {
  try {
    const orders = await listOrders();
    const sel = document.getElementById('receipt_order') as HTMLSelectElement;
    sel.innerHTML = orders.map((o: any) => `<option value="${o.id}">${o.ship_name} (Job ${o.id})</option>`).join('');
    const listDiv = document.getElementById('receiptsList')!;
    const refreshList = async () => {
      const orderId = Number(sel.value);
      const order = orders.find((x: any) => x.id === orderId);
      if (!order) { listDiv.innerHTML = ''; return; }
      const rows = (order.receipts || []).map((r: any, i: number) => `<li class="flex items-center justify-between">
        <a class="text-blue-700 underline" href="${r.file}" target="_blank">Receipt ${i + 1}</a>
        <span class="text-xs text-gray-500">${new Date(r.uploaded_at).toLocaleString()}</span>
      </li>`).join('');
      listDiv.innerHTML = `<h4 class="font-medium mb-2">Uploaded Receipts</h4><ul class="space-y-1">${rows || '<li class=\"text-sm text-gray-500\">No receipts uploaded yet.</li>'}</ul>`;
    };
    sel.onchange = refreshList;
    await refreshList();
    document.getElementById('uploadReceiptBtn')!.addEventListener('click', async () => {
      const fileEl = document.getElementById('receipt_file') as HTMLInputElement;
      const file = fileEl.files && fileEl.files[0];
      if (!file) { UIComponents.showAlert('Please choose a file to upload', 'error'); return; }
      const orderId = Number(sel.value);
      try {
        await uploadReceipt(orderId, file);
        UIComponents.showAlert('Receipt uploaded', 'success');
        // refresh order to get latest receipts
        const fresh = await getOrder(orderId);
        const idx = orders.findIndex((o: any) => o.id === orderId);
        if (idx >= 0) orders[idx] = fresh;
        await refreshList();
        fileEl.value = '';
      } catch (e) {
        UIComponents.showAlert('Failed to upload receipt', 'error');
      }
    });
  } catch (e) {
    console.error(e);
  }
}

// Component-based approach for DRY practice
// Moved to utils/ui.ts

// moved to components/BoatChecklistModal.ts
/* function openBoatChecklistModal(order: any) {
  const vesselRows = [
    'Cat A. Plastic','Cat B. Food Waste','Cat C. Domestic Waste','Cat D. Cooking Oil (N/A)',
    'Cat E. Incinerator Ashes','Cat F. Operational Waste','Cat G. Cargo Residue','Cat H. Animal Carcasses',
    'Cat I. Fishing Gear','Cat J. Other (E-Waste)'
  ].map((label, idx) => `
    <tr>
      <td>${idx + 1}</td>
      <td>${label}</td>
      <td><input type="number" step="0.01" id="v_qty_${idx}" class="border rounded px-2 py-1 w-full"></td>
      <td><input type="text" id="v_org_${idx}" class="border rounded px-2 py-1 w-full"></td>
    </tr>
  `).join('');

  const content = `
    <div class="space-y-6 text-sm">
      <h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Vessel Checklist</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label>Ship Name: <input type="text" id="v_ship_name" value="${order.ship_name || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Flag: <input type="text" id="v_flag" value="${order.flag || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>IMO No: <input type="text" id="v_imo" value="${order.imo_no || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Berth: <input type="text" id="v_berth" value="${order.berth || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Port: <input type="text" id="v_port" value="${order.port || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Date: <input type="date" id="v_date" value="${formatDateInput(order.date)}" class="border rounded px-2 py-1 w-full"></label>
        <label>Time: <input type="time" id="v_time" value="${formatTimeInput(order.time)}" class="border rounded px-2 py-1 w-full"></label>
        </div>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-2 py-1 text-left">No.</th>
              <th class="px-2 py-1 text-left">Garbage Category</th>
              <th class="px-2 py-1 text-left">Quantity (m³)</th>
              <th class="px-2 py-1 text-left">Origin</th>
            </tr>
          </thead>
          <tbody>
            ${vesselRows}
          </tbody>
        </table>
        </div>
      <label>Total Volume: <input type="number" step="0.01" id="v_total" value="${order.total_volume || ''}" class="border rounded px-2 py-1 w-32"></label>
      <label>Master's Name & Signature: <input type="text" id="v_master" class="border rounded px-2 py-1 w-full"></label>

      <h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Collecting Boat Checklist</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label>Collecting Boat Name: <input type="text" id="c_boat" class="border rounded px-2 py-1 w-full"></label>
        <label>Truck Reg No: <input type="text" id="c_truck" class="border rounded px-2 py-1 w-full"></label>
        <label class="sm:col-span-2">Disposal Date & Time: <input type="datetime-local" id="c_disposal" class="border rounded px-2 py-1 w-full"></label>
        </div>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-2 py-1 text-left">No.</th>
              <th class="px-2 py-1 text-left">Checklist Item</th>
              <th class="px-2 py-1 text-left">Yes</th>
              <th class="px-2 py-1 text-left">No</th>
            </tr>
          </thead>
          <tbody>
            ${[ 
              'Clearance taken from Bio Security (Form 44)',
              'Clearance taken from Customs (Form 44)',
              'Verbal clearance taken on phone for Form 44',
              'Checklist for Accredited Person Completed',
              'Checklist for Driver Completed'
            ].map((item, i) => `
              <tr>
                <td class="px-2 py-1">${i + 1}</td>
                <td class="px-2 py-1">${item}</td>
                <td class="px-2 py-1"><input type="radio" name="chk_${i}" value="yes"></td>
                <td class="px-2 py-1"><input type="radio" name="chk_${i}" value="no"></td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <label>Contingency Plan: <textarea id="c_contingency" rows="3" class="border rounded px-2 py-1 w-full"></textarea></label>
      </div>
    `;

  UIComponents.openModal(`Checklist - ${order.ship_name || ''}`, content, async () => {
    // Collect a minimal placeholder payload
    const checklist: Record<string, string> = {};
    for (let i = 0; i < 5; i++) {
      const sel = document.querySelector(`input[name="chk_${i}"]:checked`) as HTMLInputElement | null;
      checklist[`item_${i + 1}`] = sel?.value || '';
    }
    const payload = {
      vessel_checklist_meta: {
        ship_name: (document.getElementById('v_ship_name') as HTMLInputElement | null)?.value || '',
        flag: (document.getElementById('v_flag') as HTMLInputElement | null)?.value || '',
        imo_no: (document.getElementById('v_imo') as HTMLInputElement | null)?.value || '',
        berth: (document.getElementById('v_berth') as HTMLInputElement | null)?.value || '',
        port: (document.getElementById('v_port') as HTMLInputElement | null)?.value || '',
        date: (document.getElementById('v_date') as HTMLInputElement | null)?.value || '',
        time: (document.getElementById('v_time') as HTMLInputElement | null)?.value || '',
        total_volume: parseFloat((document.getElementById('v_total') as HTMLInputElement | null)?.value || '0') || 0,
        master_signature: (document.getElementById('v_master') as HTMLInputElement | null)?.value || ''
      },
      vessel_checklist_rows: Array.from({ length: 10 }).map((_, idx) => ({
        no: idx + 1,
        quantity_m3: parseFloat((document.getElementById(`v_qty_${idx}`) as HTMLInputElement | null)?.value || '0') || 0,
        origin: (document.getElementById(`v_org_${idx}`) as HTMLInputElement | null)?.value || ''
      })),
      collecting_boat: {
        boat_name: (document.getElementById('c_boat') as HTMLInputElement | null)?.value || '',
        truck_reg: (document.getElementById('c_truck') as HTMLInputElement | null)?.value || '',
        disposal_time: (document.getElementById('c_disposal') as HTMLInputElement | null)?.value || ''
      },
      collecting_checklist: checklist,
      contingency_plan: (document.getElementById('c_contingency') as HTMLTextAreaElement | null)?.value || ''
    };
    // Placeholder PATCH; adjust endpoint/keys as needed later
    await patchOrder(order.id, payload);
  });
} */

class PDFGenerator {
  static generateDischargeFormPDF(formData?: any) {
    const doc = new jsPDF('p', 'mm', 'a4'); // A4 format
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15; // 15mm margins
    const contentWidth = pageWidth - (margin * 2);
    
    // Colors
    const primaryColor = [37, 99, 235]; // Blue
    const secondaryColor = [55, 65, 81]; // Gray

    // Header with company branding
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.rect(0, 0, pageWidth, 25, 'F');

    // Company logo placeholder
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text('KAY MARINE CRM', margin, 15);
    
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Supply and Services', margin, 20);

    // Form title
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('VESSEL DISCHARGE FORM', pageWidth - margin, 12, { align: 'right' });
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('MARPOL Annex V - Garbage Discharge', pageWidth - margin, 17, { align: 'right' });

    // Reset colors
    doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);

    let yPosition = 35;

    // Vessel Information Section
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('VESSEL INFORMATION', margin, yPosition);
    
    yPosition += 8;
    
    // Vessel details - optimized layout for A4
    const vesselFields = [
      { label: 'Ship Name:', value: formData?.ship_name || '_________________', x: margin, width: 60 },
      { label: 'IMO Number:', value: formData?.imo_no || '_________________', x: margin + 70, width: 50 },
      { label: 'Flag:', value: formData?.flag || '_________________', x: margin + 130, width: 40 }
    ];
    
    // First row
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    vesselFields.forEach(field => {
      doc.text(field.label, field.x, yPosition);
      doc.text(field.value, field.x, yPosition + 4);
    });
    
    yPosition += 12;
    
    // Second row
    const vesselFields2 = [
      { label: 'Vessel Type:', value: formData?.vessel_type || '_________________', x: margin, width: 60 },
      { label: 'Berth:', value: formData?.berth || '_________________', x: margin + 70, width: 50 },
      { label: 'Port:', value: formData?.port || 'Port Hedland', x: margin + 130, width: 40 }
    ];
    
    vesselFields2.forEach(field => {
      doc.text(field.label, field.x, yPosition);
      doc.text(field.value, field.x, yPosition + 4);
    });
    
    yPosition += 12;
    
    // Third row
    const vesselFields3 = [
      { label: 'Date:', value: formData?.date || '_________________', x: margin, width: 60 },
      { label: 'Time:', value: formData?.time || '_________________', x: margin + 70, width: 50 }
    ];
    
    vesselFields3.forEach(field => {
      doc.text(field.label, field.x, yPosition);
      doc.text(field.value, field.x, yPosition + 4);
    });
    
    yPosition += 12;
    
    // Fourth row (ETA / ETB)
    const etaValue = formData?.eta ? new Date(formData.eta).toLocaleString() : '_________________';
    const etbValue = formData?.etb ? new Date(formData.etb).toLocaleString() : '_________________';
    const vesselFields4 = [
      { label: 'ETA:', value: etaValue, x: margin, width: 80 },
      { label: 'ETB:', value: etbValue, x: margin + 90, width: 80 }
    ];
    vesselFields4.forEach(field => {
      doc.text(field.label, field.x, yPosition);
      doc.text(field.value, field.x, yPosition + 4);
    });
    
    yPosition += 15;

    // Additional Waste Choice Row
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Dispose additional waste beyond free 1 m³?', margin, yPosition);
    doc.setFont('helvetica', 'normal');
    const yesChecked = formData?.dispose_additional_waste === true;
    const noChecked = formData?.dispose_additional_waste === false || formData?.dispose_additional_waste === undefined ? true : false;
    // Draw Yes checkbox
    const boxSize = 4;
    const yesX = margin + 120;
    const yesY = yPosition - 3.5;
    doc.rect(yesX, yesY, boxSize, boxSize);
    if (yesChecked) {
      doc.line(yesX, yesY, yesX + boxSize, yesY + boxSize);
      doc.line(yesX + boxSize, yesY, yesX, yesY + boxSize);
    }
    doc.text('Yes', yesX + 7, yPosition);
    // Draw No checkbox
    const noX = yesX + 30;
    const noY = yesY;
    doc.rect(noX, noY, boxSize, boxSize);
    if (noChecked) {
      doc.line(noX, noY, noX + boxSize, noY + boxSize);
      doc.line(noX + boxSize, noY, noX, noY + boxSize);
    }
    doc.text('No', noX + 7, yPosition);

    yPosition += 12;
    
    // Garbage Discharge Section
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('VESSEL PLANNED TO DISCHARGE', margin, yPosition);
    
    yPosition += 8;
    
    // Table headers
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('No.', margin, yPosition);
    doc.text('MARPOL Annex V. Garbage', margin + 10, yPosition);
    doc.text('Quantity (m³)', margin + 100, yPosition);
    doc.text('Origin', margin + 130, yPosition);
    
    yPosition += 3;

    // Draw table header line
    doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setLineWidth(0.3);
    doc.line(margin, yPosition, pageWidth - margin, yPosition);

    yPosition += 6;
    
    // Garbage categories - optimized spacing
    const garbageCategories = [
      { no: '1', category: 'Cat A. Plastic', qty: formData?.cat_a_plastic || '', origin: '' },
      { no: '2', category: 'Cat B. Food Waste', qty: 'N/A', origin: 'N/A' },
      { no: '3', category: 'Cat C. Domestic Waste', qty: formData?.cat_c_domestic_waste || '', origin: '' },
      { no: '4', category: 'Cat D. Cooking Oil', qty: 'N/A', origin: 'N/A' },
      { no: '5', category: 'Cat E. Incinerator Ashes', qty: formData?.cat_e_incinerator_ashes || '', origin: '' },
      { no: '6', category: 'Cat F. Operational Waste', qty: formData?.cat_f_operational_waste || '', origin: '' },
      { no: '7', category: 'Cat G. Cargo Residue', qty: formData?.cat_g_cargo_residue || '', origin: '' },
      { no: '8', category: 'Cat H. Animal Carcasses', qty: 'N/A', origin: 'N/A' },
      { no: '9', category: 'Cat I. Fishing Gear', qty: formData?.cat_i_fishing_gear || '', origin: '' },
      { no: '10', category: 'Cat J. Other (E-Waste)', qty: formData?.cat_j_other_e_waste || '', origin: '' }
    ];
    
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    
    garbageCategories.forEach((item, index) => {
      // Check if we need a new page
      if (yPosition > pageHeight - 40) {
        doc.addPage();
        yPosition = 20;
        
        // Redraw headers on new page
        doc.setFontSize(8);
        doc.setFont('helvetica', 'bold');
        doc.text('No.', margin, yPosition);
        doc.text('MARPOL Annex V. Garbage', margin + 10, yPosition);
        doc.text('Quantity (m³)', margin + 100, yPosition);
        doc.text('Origin', margin + 130, yPosition);
        
        yPosition += 3;
        doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
        doc.setLineWidth(0.3);
        doc.line(margin, yPosition, pageWidth - margin, yPosition);
        yPosition += 6;
        doc.setFontSize(8);
        doc.setFont('helvetica', 'normal');
      }
      
      doc.text(item.no, margin, yPosition);
      doc.text(item.category, margin + 10, yPosition);
      
      if (item.qty === 'N/A') {
        doc.text(item.qty, margin + 100, yPosition);
        doc.text(item.origin, margin + 130, yPosition);
      } else {
        // Draw input field for quantity
        doc.setDrawColor(200, 200, 200);
        doc.setLineWidth(0.2);
        doc.rect(margin + 95, yPosition - 2.5, 12, 4);
        doc.text(item.qty || '', margin + 97, yPosition);
        
        // Draw input field for origin
        doc.rect(margin + 125, yPosition - 2.5, 25, 4);
        doc.text(item.origin || '', margin + 127, yPosition);
      }
      
      yPosition += 5.5; // Reduced spacing
    });
    
    // Total volume row
    yPosition += 3;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.setFillColor(232, 245, 233); // Light green
    doc.rect(margin, yPosition - 2.5, contentWidth, 5, 'F');
    doc.text('Total Volume:', margin + 5, yPosition);
    
    // Draw input field for total
    doc.setDrawColor(200, 200, 200);
    doc.setLineWidth(0.2);
    doc.rect(margin + 95, yPosition - 2.5, 12, 4);
    doc.text(formData?.total_volume?.toString() || '', margin + 97, yPosition);
    
    yPosition += 15;
    
    // Signature section - check if we need new page
    if (yPosition > pageHeight - 60) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('SIGNATURES', margin, yPosition);

    yPosition += 8;

    // Signature fields - aligned 3-column layout
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');

    const colWidth = Math.floor(contentWidth / 3);
    const colXs = [margin, margin + colWidth, margin + 2 * colWidth];
    const labels = ['Vessel Master', 'Port Authority', 'Waste Collection Service'];

    const lineLeftPadding = 28; // space reserved for label text
    const lineRightPadding = 8;
    const dateLabelWidth = 18; // 'Date:' width allocation before the line

    // First row of signature blocks
    for (let i = 0; i < labels.length; i++) {
      const x = colXs[i];
      // Label
      doc.text(`${labels[i]}:`, x, yPosition);
      // Signature line (same row)
      doc.setDrawColor(200, 200, 200);
      doc.setLineWidth(0.2);
      const sigLineStart = x + lineLeftPadding;
      const sigLineEnd = x + colWidth - lineRightPadding;
      doc.line(sigLineStart, yPosition - 0.5, sigLineEnd, yPosition - 0.5);

      // Date label and line beneath with consistent spacing
      const dateY = yPosition + 7;
      doc.text('Date:', x, dateY);
      const dateLineStart = x + dateLabelWidth;
      const dateLineEnd = x + colWidth - lineRightPadding;
      doc.line(dateLineStart, dateY - 0.5, dateLineEnd, dateY - 0.5);
    }

    // Advance below signature blocks
    yPosition += 16;
    
    // Footer
    const footerY = pageHeight - 10;
    doc.setFontSize(7);
    doc.setTextColor(150, 150, 150);
    doc.text('Generated by Kay Marine CRM System', margin, footerY);
    doc.text(new Date().toLocaleString(), pageWidth - margin, footerY, { align: 'right' });
    
    // Download the PDF
    const fileName = `Discharge_Form_${formData?.ship_name || 'New'}_${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(fileName);
  }
  
  static downloadBlankForm() {
    PDFGenerator.generateDischargeFormPDF();
  }
  
  static downloadFilledForm(formData: any) {
    PDFGenerator.generateDischargeFormPDF(formData);
  }
}

class FormHandler {
  static setupFormHandlers() {
    // Hook up total calculation
    const qtyInputs = document.querySelectorAll<HTMLInputElement>('.qty');
    const updateTotal = () => {
      let total = 0;
      qtyInputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
      (document.getElementById('totalVol') as HTMLTableCellElement).textContent = total.toFixed(2);
    };
    qtyInputs.forEach(i => i.addEventListener('input', updateTotal));
    
    // Enhanced form submission with redirect
    const submitButton = document.getElementById('submitOrder');
    if (submitButton) {
      submitButton.addEventListener('click', FormHandler.handleFormSubmission);
    }
  }

  static async handleFormSubmission(ev: Event) {
    ev.preventDefault();
    
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    const originalText = submitButton.textContent;
    
    try {
      // Show loading state
      submitButton.disabled = true;
      submitButton.innerHTML = `
        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        Submitting...
      `;

      // Collect form data
      const formData = FormHandler.collectFormData();
      
      // Submit to API
      const success = await FormHandler.submitToAPI(formData);
      
      if (success) {
        UIComponents.showAlert('Discharge order submitted successfully!', 'success');
        
        // Redirect to orders list after 1.5 seconds
        setTimeout(() => {
          // Check if user is admin and redirect accordingly
          checkUserRole().then(isAdmin => {
            if (isAdmin) {
              switchTab('orders');
              loadOrders();
            } else {
              // For regular users, just show success message
              UIComponents.showAlert('Your order has been submitted for review.', 'success');
            }
          });
        }, 1500);
      }
    } catch (error) {
      console.error('Form submission error:', error);
      UIComponents.showAlert('Failed to submit order. Please try again.', 'error');
    } finally {
      // Reset button state
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  }

  static collectFormData() {
    // Collect vessel form values
    const ship_name = (document.getElementById('ship_name') as HTMLInputElement)?.value || '';
    const berth = (document.getElementById('berth') as HTMLInputElement)?.value || '';
    const date = (document.getElementById('date') as HTMLInputElement)?.value || '';
    const time = (document.getElementById('time') as HTMLInputElement)?.value || '';
    const eta = (document.getElementById('eta') as HTMLInputElement)?.value || '';
    const etb = (document.getElementById('etb') as HTMLInputElement)?.value || '';
    const port = (document.getElementById('port') as HTMLInputElement)?.value || 'Port Hedland';
    const flag = (document.getElementById('flag') as HTMLInputElement)?.value || '';
    const vessel_type = (document.getElementById('type') as HTMLInputElement)?.value || '';
    const imo_no = (document.getElementById('imo') as HTMLInputElement)?.value || '';
    const dispose_additional_waste = (document.getElementById('dispose_additional_waste') as HTMLInputElement)?.checked || false;

    // Map quantities to backend fields
    const qtyInputs = Array.from(document.querySelectorAll<HTMLInputElement>('.qty'));
    const getNum = (el?: HTMLInputElement) => {
      if (!el) return null;
      const n = parseFloat(el.value);
      return isNaN(n) ? null : n;
    };
    const cat_a_plastic = getNum(qtyInputs[0]);
    const cat_c_domestic_waste = getNum(qtyInputs[1]);
    const cat_e_incinerator_ashes = getNum(qtyInputs[2]);
    const cat_f_operational_waste = getNum(qtyInputs[3]);
    const cat_g_cargo_residue = getNum(qtyInputs[4]);
    const cat_i_fishing_gear = getNum(qtyInputs[5]);
    const cat_j_other_e_waste = getNum(qtyInputs[6]);

    return {
      ship_name,
      berth: berth || null,
      date,
      time: time || null,
      eta: eta || null,
      etb: etb || null,
      port,
      flag: flag || null,
      vessel_type: vessel_type || null,
      imo_no: imo_no || null,
      dispose_additional_waste,
      cat_a_plastic,
      cat_c_domestic_waste,
      cat_e_incinerator_ashes,
      cat_f_operational_waste,
      cat_g_cargo_residue,
      cat_i_fishing_gear,
      cat_j_other_e_waste,
    };
  }

  static async submitToAPI(formData: any): Promise<boolean> {
    const res = await fetch(`${apiBase}/discharge-forms/`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json', 
        'Authorization': `Bearer ${localStorage.getItem('access')}` 
      },
      body: JSON.stringify(formData),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      const msg = (errorData && (errorData.detail || JSON.stringify(errorData))) || `HTTP ${res.status}`;
      throw new Error(msg);
    }

    return true;
  }
}

function openAdditionalDetailsModal() {
  const placeholder = `
    <div class="space-y-4">
      <p class="text-sm text-gray-600">Additional details form will appear here.</p>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <label class="text-sm">
          <span class="block text-gray-600 mb-1">Placeholder Field 1</span>
          <input id="additional_field_1" type="text" class="w-full border rounded px-3 py-2" placeholder="Enter value" />
        </label>
        <label class="text-sm">
          <span class="block text-gray-600 mb-1">Placeholder Field 2</span>
          <input id="additional_field_2" type="text" class="w-full border rounded px-3 py-2" placeholder="Enter value" />
        </label>
      </div>
      <label class="text-sm block">
        <span class="block text-gray-600 mb-1">Notes</span>
        <textarea id="additional_notes" class="w-full border rounded px-3 py-2" rows="4" placeholder="Any notes..."></textarea>
      </label>
    </div>`;

  UIComponents.openModal('Additional Details', placeholder, () => {
    // For now just collect and stash in memory or console. Later we can wire to API.
    const values = {
      field1: (document.getElementById('additional_field_1') as HTMLInputElement | null)?.value || '',
      field2: (document.getElementById('additional_field_2') as HTMLInputElement | null)?.value || '',
      notes: (document.getElementById('additional_notes') as HTMLTextAreaElement | null)?.value || ''
    };
    console.log('Additional details (placeholder):', values);
  });
}

function render() {
  const access = localStorage.getItem('access');
  console.log('Access token exists:', !!access);
  if (access) {
    // Check if user is admin by trying to fetch user profile
    checkUserRole().then(isAdmin => {
      console.log('User is admin:', isAdmin);
      if (isAdmin) {
        renderAdminDashboard();
      } else {
        renderBoatUserDashboard();
      }
    });
  } else {
    renderLoginForm();
  }
}

async function checkUserRole(): Promise<boolean> {
  try {
    const res = await fetch(`${apiBase}/auth/me/`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
    });
    if (res.ok) {
      const user = await res.json();
      console.log('User data:', user);
      console.log('Is staff:', user.is_staff, 'Is superuser:', user.is_superuser);
      return user.is_staff || user.is_superuser;
    }
  } catch (error) {
    console.error('Error checking user role:', error);
  }
  return false;
}

function renderAdminDashboard() {
    app.innerHTML = `
    <div class="min-h-dvh bg-gray-50">
      <!-- Enhanced Header -->
      <header class="bg-white shadow-lg border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-20">
            <!-- Logo and Brand -->
            <div class="flex items-center space-x-4">
              <div class="flex items-center space-x-3">
                <div class="relative">
                  <img src="/logo.png" alt="Kay Marine" class="h-12 w-12 object-contain rounded-full shadow-md border-2 border-blue-100" />
                  <div class="absolute -top-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-white"></div>
                </div>
                <div>
                  <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                  <p class="text-sm text-gray-500 font-medium">Admin Dashboard</p>
                </div>
              </div>
            </div>
            
            <!-- User Info and Actions -->
            <div class="flex items-center space-x-4">
              <div class="hidden sm:block text-right">
                <p class="text-sm font-medium text-gray-900">Welcome, Admin</p>
                <p class="text-xs text-gray-500">System Administrator</p>
              </div>
              <div class="flex items-center space-x-2">
                <button id="refreshOrders" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Refresh Orders">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                  </svg>
                </button>
                <button id="logout" class="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors shadow-sm btn-enhanced">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                  </svg>
                  <span class="hidden sm:inline">Logout</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Main Content -->
      <div class="max-w-7xl mx-auto p-6">

        <!-- Navigation Tabs -->
        <div class="bg-white rounded-lg shadow mb-6">
          <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6">
              <button id="ordersTab" class="py-4 px-1 border-b-2 border-blue-500 font-medium text-blue-600">Orders List</button>
              <button id="createTab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Create Order</button>
              <button id="last24Tab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Last 24 Hours</button>
              <button id="next24Tab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Next 24 Hours</button>
              <button id="kpiTab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Reports</button>
            </nav>
          </div>
        </div>

        <!-- KPI View (Hidden by default) -->
        <div id="kpiView" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Key Performance Indicators</h2>
              <button id="refreshKpi" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
            </div>
          </div>
          <div class="p-6">
            <div id="kpiContainer" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <!-- KPI cards will render here -->
            </div>
          </div>
        </div>

        <!-- Orders List View -->
        <div id="ordersView" class="bg-white rounded-lg shadow">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Discharge Orders</h2>
              <div class="flex items-center space-x-3">
                <button id="downloadBlankForm" class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <span>Download Blank Form</span>
                </button>
                <button id="refreshOrders" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="ordersTable" class="overflow-x-auto">
              <div class="flex justify-center items-center h-32">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span class="ml-2 text-gray-600">Loading orders...</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Last 24 Hours View (Hidden by default) -->
        <div id="last24View" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Completed in Last 24 Hours</h2>
              <div class="flex items-center space-x-3">
                <button id="refreshLast24" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="last24Table" class="overflow-x-auto"></div>
          </div>
        </div>

        <!-- Next 24 Hours View (Hidden by default) -->
        <div id="next24View" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Scheduled in Next 24 Hours</h2>
              <div class="flex items-center space-x-3">
                <button id="refreshNext24" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="next24Table" class="overflow-x-auto"></div>
          </div>
        </div>

        <!-- Create Order View (Hidden by default) -->
        <div id="createView" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Create New Discharge Order</h2>
              <div class="flex items-center space-x-3">
                <button id="downloadFilledForm" class="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <span>Download PDF</span>
                </button>
                <button id="downloadBlankFormCreate" class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <span>Download Blank</span>
                </button>
              </div>
            </div>
          </div>
          <div class="p-6">
            ${getDischargeFormHTML()}
          </div>
        </div>

        <!-- Service Purchase View removed; now part of Create Order collapsible -->
      </div>
    </div>`;

  // Add event listeners
  document.getElementById('logout')!.addEventListener('click', logout);
  document.getElementById('ordersTab')!.addEventListener('click', () => switchTab('orders'));
  document.getElementById('createTab')!.addEventListener('click', () => switchTab('create'));
  document.getElementById('last24Tab')!.addEventListener('click', () => switchTab('last24'));
  document.getElementById('next24Tab')!.addEventListener('click', () => switchTab('next24'));
  document.getElementById('refreshOrders')!.addEventListener('click', loadOrders);
  document.getElementById('refreshLast24')!.addEventListener('click', loadLast24);
  document.getElementById('refreshNext24')!.addEventListener('click', loadNext24);
  document.getElementById('kpiTab')!.addEventListener('click', () => switchTab('kpi'));
  document.getElementById('refreshKpi')!.addEventListener('click', loadKpi);
  
  // PDF download event listeners
  document.getElementById('downloadBlankForm')!.addEventListener('click', () => {
    PDFGenerator.downloadBlankForm();
    UIComponents.showAlert('Blank discharge form downloaded successfully!', 'success');
  });
  
  document.getElementById('downloadBlankFormCreate')!.addEventListener('click', () => {
    PDFGenerator.downloadBlankForm();
    UIComponents.showAlert('Blank discharge form downloaded successfully!', 'success');
  });
  
  document.getElementById('downloadFilledForm')!.addEventListener('click', () => {
    const formData = FormHandler.collectFormData();
    PDFGenerator.downloadFilledForm(formData);
    UIComponents.showAlert('Filled discharge form downloaded successfully!', 'success');
  });

  // Wire up collapsibles in admin create view
  const addToggle = document.getElementById('toggleAdditional');
  const addPanel = document.getElementById('additionalPanel');
  const addChevron = document.getElementById('additionalChevron');
  if (addToggle && addPanel && addChevron) {
    addToggle.addEventListener('click', () => {
      const hidden = addPanel.classList.contains('hidden');
      addPanel.classList.toggle('hidden');
      addChevron!.textContent = hidden ? '▲' : '▼';
    });
  }
  const svcToggle = document.getElementById('toggleService');
  const svcPanel = document.getElementById('servicePanel');
  const svcChevron = document.getElementById('serviceChevron');
  if (svcToggle && svcPanel && svcChevron) {
    svcToggle.addEventListener('click', () => {
      const hidden = svcPanel.classList.contains('hidden');
      svcPanel.classList.toggle('hidden');
      svcChevron!.textContent = hidden ? '▲' : '▼';
    });
  }

  // Load orders initially
  loadOrders();
  // Preload KPI silently
  loadKpi();
  // Wire save button for Service Purchase (dummy action)
  const saveSvc = document.getElementById('saveServicePurchase');
  if (saveSvc) {
    saveSvc.addEventListener('click', () => {
      const data = {
        vendor: (document.getElementById('svc_vendor') as HTMLInputElement | null)?.value || '',
        type: (document.getElementById('svc_type') as HTMLInputElement | null)?.value || '',
        amount: (document.getElementById('svc_amount') as HTMLInputElement | null)?.value || '',
        date: (document.getElementById('svc_date') as HTMLInputElement | null)?.value || '',
        notes: (document.getElementById('svc_notes') as HTMLTextAreaElement | null)?.value || '',
      };
      console.log('Service Purchase (dummy):', data);
      UIComponents.showAlert('Service purchase saved (dummy).', 'success');
    });
  }
}

// deprecated legacy view removed

function renderLoginForm() {
  app.innerHTML = `
    <div class="min-h-dvh bg-gradient-to-br from-blue-50 to-gray-100">
      <!-- Enhanced Header -->
      <header class="bg-white shadow-sm border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-center items-center h-16">
            <div class="flex items-center space-x-3">
              <div class="relative">
                <img src="/logo.png" alt="Kay Marine" class="h-12 w-12 object-contain rounded-full shadow-md border-2 border-blue-100" />
                <div class="absolute -top-1 -right-1 h-4 w-4 bg-blue-500 rounded-full border-2 border-white"></div>
              </div>
              <div>
                <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                <p class="text-sm text-gray-500 font-medium">Supply and Services</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Login Form -->
      <div class="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
          <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="px-8 py-10">
              <div class="text-center mb-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h2>
                <p class="text-gray-600">Sign in to your account</p>
              </div>
              <form id="loginForm" class="space-y-6">
                <div>
                  <label for="username" class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                  <input id="username" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors" placeholder="Enter your username" required />
                </div>
                <div>
                  <label for="password" class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                  <input id="password" type="password" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors" placeholder="Enter your password" required />
                </div>
                <button class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors" type="submit">
                  Sign In
                </button>
                <p id="error" class="text-red-600 text-sm text-center h-4"></p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  document.getElementById('loginForm')!.addEventListener('submit', login);
}

function getDischargeFormHTML(): string {
  return `
          <style>
            .frm table{width:100%;border-collapse:collapse;margin-top:15px}
            .frm th,.frm td{border:1px solid #444;padding:8px;text-align:center}
            .frm th{background:#f2f2f2}
            .frm input[type=text],.frm input[type=number],.frm input[type=date],.frm input[type=time]{width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:6px;box-sizing:border-box}
            .frm .total-cell{font-weight:bold;background:#e8f5e9}
            .frm .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-top:8px}
            .frm .form-field{display:flex;flex-direction:column}
            .frm .form-field label{font-weight:600;color:#334155;margin-bottom:6px}
            .frm h2{margin-bottom:12px}
          </style>
          <div class="frm">
            <h2 class="text-xl font-bold mb-2">Vessel Discharge Form</h2>
            <form id="dischargeForm">
              <div class="form-grid">
                <div class="form-field"><label for="ship_name">Ship Name</label><input type="text" name="ship_name" id="ship_name"></div>
                <div class="form-field"><label for="berth">Berth</label><input type="text" name="berth" id="berth"></div>
                <div class="form-field"><label for="date">Order Created At</label><input type="date" name="date" id="date"></div>
                <div class="form-field"><label for="time">Time</label><input type="time" name="time" id="time"></div>
          <div class="form-field"><label for="eta">ETA (Estimated Time of Arrival)</label><input type="datetime-local" name="eta" id="eta"></div>
          <div class="form-field"><label for="etb">ETB (Estimated Time of Berth)</label><input type="datetime-local" name="etb" id="etb"></div>
                <div class="form-field"><label for="port">Port</label><input type="text" name="port" id="port" value="Port Hedland"></div>
                <div class="form-field"><label for="flag">Flag</label><input type="text" name="flag" id="flag"></div>
                <div class="form-field"><label for="type">Vessel Type</label><input type="text" name="type" id="type"></div>
                <div class="form-field"><label for="imo">IMO no.</label><input type="text" name="imo" id="imo"></div>
                <div class="form-field"><label for="dispose_additional_waste">Dispose additional waste (beyond free 1 m³)?</label><input type="checkbox" name="dispose_additional_waste" id="dispose_additional_waste"></div>
              </div>
            </form>

            <div class="mt-6 border rounded-lg">
              <button id="toggleAdditional" class="w-full flex justify-between items-center px-4 py-3 bg-gray-50 hover:bg-gray-100">
                <span class="font-medium">Additional Details</span>
                <span id="additionalChevron">▼</span>
              </button>
              <div id="additionalPanel" class="p-4 hidden">
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <label class="text-sm">
                    <span class="block text-gray-600 mb-1">Placeholder Field 1</span>
                    <input id="additional_field_1" type="text" class="w-full border rounded px-3 py-2" placeholder="Enter value" />
                  </label>
                  <label class="text-sm">
                    <span class="block text-gray-600 mb-1">Placeholder Field 2</span>
                    <input id="additional_field_2" type="text" class="w-full border rounded px-3 py-2" placeholder="Enter value" />
                  </label>
                </div>
                <label class="text-sm block mt-3">
                  <span class="block text-gray-600 mb-1">Notes</span>
                  <textarea id="additional_notes" class="w-full border rounded px-3 py-2" rows="4" placeholder="Any notes..."></textarea>
                </label>
              </div>
            </div>

            <div class="mt-4 border rounded-lg">
              <button id="toggleService" class="w-full flex justify-between items-center px-4 py-3 bg-gray-50 hover:bg-gray-100">
                <span class="font-medium">Service Purchase</span>
                <span id="serviceChevron">▼</span>
              </button>
              <div id="servicePanel" class="p-4 hidden">
                <form id="servicePurchaseForm" class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <label class="text-sm">
                    <span class="block text-gray-600 mb-1">Vendor</span>
                    <input id="svc_vendor" type="text" class="w-full border rounded px-3 py-2" placeholder="Vendor name" />
                  </label>
                  <label class="text-sm">
                    <span class="block text-gray-600 mb-1">Service Type</span>
                    <input id="svc_type" type="text" class="w-full border rounded px-3 py-2" placeholder="Type of service" />
                  </label>
                  <label class="text-sm">
                    <span class="block text-gray-600 mb-1">Amount</span>
                    <input id="svc_amount" type="number" step="0.01" class="w-full border rounded px-3 py-2" placeholder="0.00" />
                  </label>
                  <label class="text-sm">
                    <span class="block text-gray-600 mb-1">Date</span>
                    <input id="svc_date" type="date" class="w-full border rounded px-3 py-2" />
                  </label>
                  <label class="text-sm sm:col-span-2">
                    <span class="block text-gray-600 mb-1">Notes</span>
                    <textarea id="svc_notes" rows="4" class="w-full border rounded px-3 py-2" placeholder="Additional notes..."></textarea>
                  </label>
                </form>
                <div class="mt-3">
                  <button id="saveServicePurchase" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save</button>
                </div>
              </div>
            </div>

            <h3 class="mt-4 font-semibold">Vessel Planned to Discharge</h3>
            <table>
              <thead>
                <tr>
                  <th>No.</th>
                  <th>MARPOL Annex V. Garbage</th>
                  <th>Quantity (m³)</th>
                  <th>Origin</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>1</td><td>Cat A. Plastic</td><td><input type="number" step="0.01" class="qty"></td><td></td></tr>
                <tr><td>2</td><td>Cat B. Food Waste</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>3</td><td>Cat C. Domestic Waste</td><td><input type="number" step="0.01" class="qty"></td><td></td></tr>
                <tr><td>4</td><td>Cat D. Cooking Oil</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>5</td><td>Cat E. Incinerator Ashes</td><td><input type="number" step="0.01" class="qty"></td><td></td></tr>
                <tr><td>6</td><td>Cat F. Operational Waste</td><td><input type="number" step="0.01" class="qty"></td><td></td></tr>
                <tr><td>7</td><td>Cat G. Cargo Residue</td><td><input type="number" step="0.01" class="qty"></td><td></td></tr>
                <tr><td>8</td><td>Cat H. Animal Carcasses</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>9</td><td>Cat I. Fishing Gear</td><td><input type="number" step="0.01" class="qty"></td><td></td></tr>
                <tr><td>10</td><td>Cat J. Other (E-Waste)</td><td><input type="number" step="0.01" class="qty"></td><td></td></tr>
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="2" class="total-cell">Total Vol:</td>
                  <td class="total-cell" id="totalVol">0</td>
                  <td></td>
                </tr>
              </tfoot>
          </table>
          <div class="mt-4 flex items-center justify-end">
            <button id="submitOrder" class="px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700">Submit Discharge Request</button>
          </div>
          <p id="msg" class="text-green-700 text-sm h-4 mt-2 text-right"></p>
    </div>`;
}

function switchTab(tab: 'orders' | 'create' | 'last24' | 'next24' | 'kpi') {
  const ordersView = document.getElementById('ordersView')!;
  const createView = document.getElementById('createView')!;
  const kpiView = document.getElementById('kpiView')!;
  const last24View = document.getElementById('last24View')!;
  const next24View = document.getElementById('next24View')!;
  const ordersTab = document.getElementById('ordersTab')!;
  const createTab = document.getElementById('createTab')!;
  const last24Tab = document.getElementById('last24Tab')!;
  const next24Tab = document.getElementById('next24Tab')!;
  const kpiTab = document.getElementById('kpiTab')!;

  if (tab === 'orders') {
    ordersView.classList.remove('hidden');
    createView.classList.add('hidden');
    last24View.classList.add('hidden');
    next24View.classList.add('hidden');
    kpiView.classList.add('hidden');
    ordersTab.classList.add('border-blue-500', 'text-blue-600');
    ordersTab.classList.remove('border-transparent', 'text-gray-500');
    createTab.classList.add('border-transparent', 'text-gray-500');
    createTab.classList.remove('border-blue-500', 'text-blue-600');
    last24Tab.classList.add('border-transparent', 'text-gray-500');
    last24Tab.classList.remove('border-blue-500', 'text-blue-600');
    next24Tab.classList.add('border-transparent', 'text-gray-500');
    next24Tab.classList.remove('border-blue-500', 'text-blue-600');
    kpiTab.classList.add('border-transparent', 'text-gray-500');
    kpiTab.classList.remove('border-blue-500', 'text-blue-600');
  } else {
    if (tab === 'create') {
      ordersView.classList.add('hidden');
      kpiView.classList.add('hidden');
      last24View.classList.add('hidden');
      next24View.classList.add('hidden');
      createView.classList.remove('hidden');
      createTab.classList.add('border-blue-500', 'text-blue-600');
      createTab.classList.remove('border-transparent', 'text-gray-500');
      ordersTab.classList.add('border-transparent', 'text-gray-500');
      ordersTab.classList.remove('border-blue-500', 'text-blue-600');
      last24Tab.classList.add('border-transparent', 'text-gray-500');
      last24Tab.classList.remove('border-blue-500', 'text-blue-600');
      next24Tab.classList.add('border-transparent', 'text-gray-500');
      next24Tab.classList.remove('border-blue-500', 'text-blue-600');
      kpiTab.classList.add('border-transparent', 'text-gray-500');
      kpiTab.classList.remove('border-blue-500', 'text-blue-600');
      FormHandler.setupFormHandlers();
    } else {
      if (tab === 'last24') {
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        kpiView.classList.add('hidden');
        next24View.classList.add('hidden');
        last24View.classList.remove('hidden');
        last24Tab.classList.add('border-blue-500', 'text-blue-600');
        last24Tab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        next24Tab.classList.add('border-transparent', 'text-gray-500');
        next24Tab.classList.remove('border-blue-500', 'text-blue-600');
        kpiTab.classList.add('border-transparent', 'text-gray-500');
        kpiTab.classList.remove('border-blue-500', 'text-blue-600');
        loadLast24();
      } else if (tab === 'next24') {
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        kpiView.classList.add('hidden');
        last24View.classList.add('hidden');
        next24View.classList.remove('hidden');
        next24Tab.classList.add('border-blue-500', 'text-blue-600');
        next24Tab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        last24Tab.classList.add('border-transparent', 'text-gray-500');
        last24Tab.classList.remove('border-blue-500', 'text-blue-600');
        kpiTab.classList.add('border-transparent', 'text-gray-500');
        kpiTab.classList.remove('border-blue-500', 'text-blue-600');
        loadNext24();
      } else {
        // KPI
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        last24View.classList.add('hidden');
        next24View.classList.add('hidden');
        kpiView.classList.remove('hidden');
        kpiTab.classList.add('border-blue-500', 'text-blue-600');
        kpiTab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        last24Tab.classList.add('border-transparent', 'text-gray-500');
        last24Tab.classList.remove('border-blue-500', 'text-blue-600');
        next24Tab.classList.add('border-transparent', 'text-gray-500');
        next24Tab.classList.remove('border-blue-500', 'text-blue-600');
        loadKpi();
      }
    }
  }
}

async function loadOrders() {
  const ordersTable = document.getElementById('ordersTable')!;
  UIComponents.showLoadingSpinner(ordersTable, 'Loading orders...');

  try {
    const orders = await listOrders();
    orders.sort(compareOrdersByEtbEta);
    if (orders.length === 0) {
      ordersTable.innerHTML = `
        <div class="text-center py-12">
          <div class="text-gray-400 text-6xl mb-4">📋</div>
          <h3 class="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
          <p class="text-gray-500">No discharge orders have been submitted yet.</p>
        </div>`;
      return;
    }

    ordersTable.innerHTML = renderAdminOrdersTable(orders);
  } catch (error) {
    console.error('Error loading orders:', error);
    ordersTable.innerHTML = `
      <div class="text-center py-12">
        <div class="text-red-400 text-6xl mb-4">⚠️</div>
        <h3 class="text-lg font-medium text-gray-900 mb-2">Error loading orders</h3>
        <p class="text-gray-500">Failed to load discharge orders. Please try again.</p>
      </div>`;
  }
}

async function loadLast24() {
  const table = document.getElementById('last24Table')!;
  UIComponents.showLoadingSpinner(table, 'Loading last 24 hours...');
  try {
    const orders = await listOrders();
    const now = new Date();
    const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const completed = orders.filter((o: any) => o.actual_offload_at && new Date(o.actual_offload_at) >= dayAgo && new Date(o.actual_offload_at) <= now);
    completed.sort((a: any, b: any) => new Date(b.actual_offload_at).getTime() - new Date(a.actual_offload_at).getTime());
    table.innerHTML = renderAdminOrdersTable(completed);
  } catch (e) {
    table.innerHTML = '<div class="text-center text-red-600">Failed to load</div>';
  }
}

async function loadNext24() {
  const table = document.getElementById('next24Table')!;
  UIComponents.showLoadingSpinner(table, 'Loading next 24 hours...');
  try {
    const orders = await listOrders();
    const now = new Date();
    const next = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const upcoming = orders.filter((o: any) => o.scheduled_offload_at && new Date(o.scheduled_offload_at) >= now && new Date(o.scheduled_offload_at) <= next);
    upcoming.sort((a: any, b: any) => new Date(a.scheduled_offload_at).getTime() - new Date(b.scheduled_offload_at).getTime());
    table.innerHTML = renderAdminOrdersTable(upcoming);
  } catch (e) {
    table.innerHTML = '<div class="text-center text-red-600">Failed to load</div>';
  }
}
async function loadKpi() {
  const container = document.getElementById('kpiContainer');
  if (!container) return;
  container.innerHTML = `
    <div class="col-span-full flex justify-center items-center h-24">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      <span class="ml-2 text-gray-600">Calculating KPIs...</span>
    </div>`;

  try {
    const orders = await listOrders();

    const total = orders.length;
    const ms30 = 30 * 60 * 1000;
    const onTime = orders.filter((o: any) => {
      if (!o.scheduled_offload_at || !o.actual_offload_at) return false;
      const diff = Math.abs(new Date(o.actual_offload_at).getTime() - new Date(o.scheduled_offload_at).getTime());
      return diff <= ms30;
    }).length;
    const timelinessPct = total ? Math.round((onTime / total) * 100) : 0;

    const sum = (arr: any[], key: string) => arr.reduce((acc, x) => acc + (parseFloat(x[key] || 0) || 0), 0);
    const supplied = sum(orders, 'ppa_supplied_volume_m3');
    const used = sum(orders, 'used_volume_m3');
    const volumeAllocationPct = supplied > 0 ? Math.round((used / supplied) * 100) : 0;

    const noIncident = orders.filter((o: any) => !o.incident_occurred).length;
    const incidentFreePct = total ? Math.round((noIncident / total) * 100) : 0;

    const docsComplete = orders.filter((o: any) => !!o.documentation_complete).length;
    const docsIncomplete = total - docsComplete;
    const docsPct = total ? Math.round((docsComplete / total) * 100) : 0;

    const rated = orders.filter((o: any) => typeof o.customer_rating === 'number');
    const avgRating = rated.length ? (rated.reduce((a: number, o: any) => a + (o.customer_rating || 0), 0) / rated.length).toFixed(2) : '0.00';

    const recent = [...orders].sort((a: any,b: any) => (new Date(b.created_at).getTime()-new Date(a.created_at).getTime())).slice(0,5);

    const card = (title: string, value: string, color: string) => `
      <div class="p-5 rounded-xl border shadow-sm bg-white">
        <p class="text-sm text-gray-500">${title}</p>
        <p class="mt-1 text-2xl font-bold ${color}">${value}</p>
      </div>`;

    container.innerHTML = `
      ${card('Timeliness Compliance', timelinessPct + '%', 'text-green-600')}
      ${card('Volume Allocation Used', volumeAllocationPct + '%', 'text-blue-600')}
      ${card('Incident Free', incidentFreePct + '%', 'text-emerald-600')}
      ${card('Documentation Complete', docsPct + '%', 'text-indigo-600')}
      ${card('Docs Incomplete', String(docsIncomplete), 'text-gray-600')}
      ${card('Customer Rating (avg /5)', String(avgRating), 'text-yellow-600')}
      <div class="col-span-full p-5 rounded-xl border shadow-sm bg-white">
        <p class="text-sm text-gray-500 mb-3">Recent Orders</p>
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Job ID</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ship Name</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Allocated</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Additional</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service purchase</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200 text-sm">
              ${recent.map((o: any) => {
                const allocated = typeof o.total_volume === 'number' ? o.total_volume : parseFloat(o.total_volume || 0) || 0;
                const additional = typeof o.additional_total === 'number' ? o.additional_total : parseFloat(o.additional_total || 0) || 0;
                const service = typeof o.service_purchase_total === 'number' ? o.service_purchase_total : parseFloat(o.service_purchase_total || 0) || 0;
                return `
                  <tr>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-900">${o.id}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${o.ship_name}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${allocated.toFixed(2)}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${additional.toFixed(2)}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${service.toFixed(2)}</td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } catch (e) {
    console.error(e);
    container.innerHTML = `<div class="col-span-full text-center text-red-600">Failed to load KPIs</div>`;
  }
}

// Global functions for order actions
(window as any).viewOrderDetails = (orderId: number) => {
  openOrderDetailsModal(orderId);
};

function openOrderDetailsModal(orderId: number) {
  // Create modal container
  const overlay = document.createElement('div');
  overlay.id = 'orderModalOverlay';
  overlay.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/50';

  const modal = document.createElement('div');
  modal.className = 'bg-white w-full max-w-3xl max-h-[90vh] rounded-2xl shadow-xl overflow-hidden flex flex-col';
  modal.innerHTML = `
    <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
      <h3 class="text-lg font-semibold">Operations & Details</h3>
      <button id="closeOrderModal" class="text-gray-500 hover:text-gray-700">✕</button>
    </div>
    <div id="orderModalBody" class="p-6 overflow-y-auto">
      <div class="flex justify-center items-center h-32">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <span class="ml-2 text-gray-600">Loading order...</span>
      </div>
    </div>
    <div class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
      <button id="saveOrderStages" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save</button>
      <button id="cancelOrderStages" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Close</button>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const close = () => {
    overlay.remove();
  };
  (document.getElementById('closeOrderModal') as HTMLButtonElement).onclick = close;
  (document.getElementById('cancelOrderStages') as HTMLButtonElement).onclick = close;

  // Load order details
  fetch(`${apiBase}/discharge-forms/${orderId}/`, {
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
  }).then(async (res) => {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const order = await res.json();
    renderOrderStages(orderId, order);
  }).catch((err) => {
    console.error(err);
    const body = document.getElementById('orderModalBody')!;
    body.innerHTML = `<p class="text-red-600">Failed to load order.</p>`;
  });

  (document.getElementById('saveOrderStages') as HTMLButtonElement).onclick = async () => {
    try {
      const payload = collectStageForm();
      // block save if any required op is pending
      const requiredOk = (
        payload.form44_submitted &&
        payload.biosecurity_status === 'approved' &&
        payload.govt_status === 'approved' &&
        payload.bio_witness &&
        payload.landfill_booked &&
        payload.discharge_certificate_created
      );
      if (!requiredOk) {
        UIComponents.showAlert('Complete all operations before saving.', 'error');
        return;
      }
      await patchOrder(orderId, payload);
      UIComponents.showAlert('Order stages updated', 'success');
      close();
      // Refresh list to reflect color later if needed
      loadOrders();
    } catch (e) {
      console.error(e);
      UIComponents.showAlert('Failed to update order stages', 'error');
    }
  };
}

function renderOrderStages(orderId: number, order: any) {
  const color = computeStageColor(order);
  const badgeClass = colorToBadge(color);

  const body = document.getElementById('orderModalBody')!;
  body.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between">
  <div>
          <h4 class="text-base font-semibold">${order.ship_name} <span class="text-sm text-gray-500">(IMO: ${order.imo_no || '-'}, ${order.port})</span></h4>
          <p class="text-sm text-gray-500">${new Date(order.date).toLocaleDateString()} • Berth: ${order.berth || '-'}</p>
              </div>
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${badgeClass}">
          ${color.toUpperCase()} STATUS
        </span>
            </div>

      <!-- Details section -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg border">
        ${detailRow('Vessel Type', order.vessel_type)}
        ${detailRow('Flag', order.flag)}
        ${detailRow('Port', order.port)}
        ${detailRow('Date', new Date(order.date).toLocaleDateString())}
        ${detailRow('Time', order.time || '-')}
        ${detailRow('ETA', order.eta ? new Date(order.eta).toLocaleString() : '-')}
        ${detailRow('ETB', order.etb ? new Date(order.etb).toLocaleString() : '-')}
        ${detailRow('Total Volume (m³)', order.total_volume != null ? String(order.total_volume) : '-')}
        ${detailRow('Scheduled Offload', order.scheduled_offload_at ? new Date(order.scheduled_offload_at).toLocaleString() : '-')}
        ${detailRow('Actual Offload', order.actual_offload_at ? new Date(order.actual_offload_at).toLocaleString() : '-')}
        ${detailRow('PPA Supplied Vol (m³)', order.ppa_supplied_volume_m3 != null ? String(order.ppa_supplied_volume_m3) : '-')}
        ${detailRow('Used Vol (m³)', order.used_volume_m3 != null ? String(order.used_volume_m3) : '-')}
        ${detailRow('Documentation', order.documentation_complete ? 'Complete' : 'Incomplete')}
        ${detailRow('Incident', order.incident_occurred ? 'Occurred' : 'None')}
        ${detailRow('Customer Rating', order.customer_rating != null ? `${order.customer_rating}/5` : '-')}
        ${detailRow('Created', new Date(order.created_at).toLocaleString())}
        ${detailRow('Updated', new Date(order.updated_at).toLocaleString())}
    </div>

      <div class="grid gap-4">
        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot('blue')}
            <div>
              <p class="font-medium">1) Order created</p>
              <p class="text-xs text-gray-500">Order has been created in the system</p>
  </div>
  </div>
          <span class="text-xs text-green-700 bg-green-100 px-2 py-1 rounded">Done</span>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.form44_submitted ? 'green' : 'gray')}
            <div>
              <p class="font-medium">2) Form 44 submitted</p>
              <p class="text-xs text-gray-500">Permission request for ship waste disposal (AUS)</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="form44_submitted" type="checkbox" ${order.form44_submitted ? 'checked' : ''} class="h-4 w-4">
            <span>${order.form44_submitted ? 'Submitted' : 'submitted'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.biosecurity_status === 'approved' ? 'orange' : order.biosecurity_status === 'rejected' ? 'red' : 'gray')}
            <div>
              <p class="font-medium">3) Biosecurity permission</p>
              <p class="text-xs text-gray-500">Set to Approved/Rejected/Pending</p>
            </div>
          </div>
          <select id="biosecurity_status" class="border rounded px-2 py-1 text-sm">
            ${selectOption('pending', order.biosecurity_status)}
            ${selectOption('approved', order.biosecurity_status)}
            ${selectOption('rejected', order.biosecurity_status)}
          </select>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.govt_status === 'approved' ? 'green' : order.govt_status === 'rejected' ? 'red' : 'gray')}
            <div>
              <p class="font-medium">4) Custom permission</p>
              <p class="text-xs text-gray-500">Set to Approved/Rejected/Pending</p>
            </div>
          </div>
          <select id="govt_status" class="border rounded px-2 py-1 text-sm">
            ${selectOption('pending', order.govt_status)}
            ${selectOption('approved', order.govt_status)}
            ${selectOption('rejected', order.govt_status)}
          </select>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.bio_witness ? 'green' : 'gray')}
            <div>
              <p class="font-medium">5) Bio security inspector booked to witness disposal</p>
              <p class="text-xs text-gray-500">Set by operations</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="bio_witness" type="checkbox" ${order.bio_witness ? 'checked' : ''} class="h-4 w-4">
            <span>${order.bio_witness ? 'Booked' : 'booked'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.landfill_booked ? 'green' : 'gray')}
            <div>
              <p class="font-medium">6) Landfill booked for disposal</p>
              <p class="text-xs text-gray-500">Set by operations</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="landfill_booked" type="checkbox" ${order.landfill_booked ? 'checked' : ''} class="h-4 w-4">
            <span>${order.landfill_booked ? 'Booked' : 'booked'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.discharge_certificate_created ? 'green' : 'gray')}
            <div>
              <p class="font-medium">7) Create discharge certificate</p>
              <p class="text-xs text-gray-500">Must be created before completion</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="discharge_certificate_created" type="checkbox" ${order.discharge_certificate_created ? 'checked' : ''} class="h-4 w-4">
            <span>${order.discharge_certificate_created ? 'Created' : 'Created'}</span>
          </label>
        </div>
      </div>
    </div>
  `;
}

function collectStageForm() {
  const form44 = (document.getElementById('form44_submitted') as HTMLInputElement)?.checked || false;
  const bio = (document.getElementById('biosecurity_status') as HTMLSelectElement)?.value || 'pending';
  const govt = (document.getElementById('govt_status') as HTMLSelectElement)?.value || 'pending';
  const bio_witness = (document.getElementById('bio_witness') as HTMLInputElement)?.checked || false;
  const landfill_booked = (document.getElementById('landfill_booked') as HTMLInputElement)?.checked || false;
  const discharge_certificate_created = (document.getElementById('discharge_certificate_created') as HTMLInputElement)?.checked || false;
  return {
    form44_submitted: form44,
    biosecurity_status: bio,
    govt_status: govt,
    bio_witness,
    landfill_booked,
    discharge_certificate_created,
  };
}

// moved to services/orders.ts

function computeStageColor(order: any): 'green' | 'orange' | 'red' | 'gray' {
  if (order.govt_status === 'approved') return 'green';
  if (order.govt_status === 'rejected' || order.biosecurity_status === 'rejected') return 'red';
  if (order.biosecurity_status === 'approved') return 'orange';
  return 'gray';
}

function colorToBadge(color: string) {
  switch (color) {
    case 'green': return 'bg-green-100 text-green-800';
    case 'orange': return 'bg-orange-100 text-orange-800';
    case 'red': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
}

function dot(color: 'green' | 'orange' | 'red' | 'gray' | 'blue') {
  const map: Record<string,string> = {
    green: 'bg-green-500',
    orange: 'bg-orange-500',
    red: 'bg-red-500',
    gray: 'bg-gray-400',
    blue: 'bg-blue-500',
  };
  return `<span class="h-3 w-3 rounded-full ${map[color]}"></span>`;
}

// Moved to utils/dates.ts

// Moved to utils/sort.ts and utils/dates.ts

function selectOption(value: string, current: string) {
  const selected = value === current ? 'selected' : '';
  const label = value.charAt(0).toUpperCase() + value.slice(1);
  return `<option value="${value}" ${selected}>${label}</option>`;
}

function detailRow(label: string, value: any) {
  const safe = (v: any) => (v === null || v === undefined || v === '' ? '-' : String(v));
  return `
    <div class="flex items-center justify-between gap-4">
      <span class="text-sm text-gray-500">${label}</span>
      <span class="text-sm font-medium text-gray-900">${safe(value)}</span>
    </div>
  `;
}

(window as any).downloadOrderPDF = async (orderId: number) => {
  try {
    const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
      headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
    });
    
    if (res.ok) {
      const orderData = await res.json();
      PDFGenerator.downloadFilledForm(orderData);
      UIComponents.showAlert('Order PDF downloaded successfully!', 'success');
    } else {
      UIComponents.showAlert('Failed to fetch order data', 'error');
    }
  } catch (error) {
    console.error('Error downloading order PDF:', error);
    UIComponents.showAlert('Error downloading order PDF', 'error');
  }
};

(window as any).deleteOrder = async (orderId: number) => {
  if (confirm('Are you sure you want to delete this order?')) {
    try {
      await deleteOrderReq(orderId);
        UIComponents.showAlert('Order deleted successfully!', 'success');
      loadOrders();
    } catch (error) {
      console.error('Error deleting order:', error);
      UIComponents.showAlert('Failed to delete order', 'error');
    }
  }
};

(window as any).setSchedule = async (orderId: number) => {
  try {
    const dEl = document.getElementById(`sched_date_${orderId}`) as HTMLInputElement | null;
    const tEl = document.getElementById(`sched_time_${orderId}`) as HTMLInputElement | null;
    const date = dEl?.value || '';
    const time = tEl?.value || '';
    if (!date || !time) {
      UIComponents.showAlert('Please select both date and time for schedule.', 'error');
      return;
    }
    const iso = new Date(`${date}T${time}`);
    if (isNaN(iso.getTime())) {
      UIComponents.showAlert('Invalid schedule date/time.', 'error');
      return;
    }
    await patchOrder(orderId, { scheduled_offload_at: iso.toISOString() });
    UIComponents.showAlert('Schedule updated', 'success');
    // Refresh boat orders table if present; otherwise try admin list
    if (document.getElementById('boatOrdersTable')) {
      loadBoatOrders();
    } else if (document.getElementById('ordersTable')) {
      loadOrders();
    }
    } catch (e) {
    console.error(e);
    UIComponents.showAlert('Failed to update schedule', 'error');
  }
};

(window as any).editOrder = (orderId: number) => {
  openEditOrderModal(orderId);
};

// moved to components/EditOrderModal.ts

async function login(ev: Event) {
  ev.preventDefault();
  const username = (document.getElementById('username') as HTMLInputElement).value;
  const password = (document.getElementById('password') as HTMLInputElement).value;
  const res = await fetch(`${apiBase}/auth/login/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) {
    (document.getElementById('error') as HTMLParagraphElement).textContent = 'Invalid credentials';
    return;
  }
  const data = await res.json();
  localStorage.setItem('access', data.access);
  localStorage.setItem('refresh', data.refresh);
  render();
}

async function logout() {
  const refresh = localStorage.getItem('refresh');
  try {
    await fetch(`${apiBase}/auth/logout/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('access')}` },
      body: JSON.stringify({ refresh })
    });
  } finally {
    localStorage.removeItem('access');
    localStorage.removeItem('refresh');
    render();
  }
}

render();

// legacy constants removed

// deprecated legacy helpers removed

// deprecated legacy helpers removed

// legacy helpers removed

// legacy helpers removed

// deprecated legacy submission removed

render();
