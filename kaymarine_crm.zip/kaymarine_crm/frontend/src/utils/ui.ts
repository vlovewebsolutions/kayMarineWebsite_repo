export class UIComponents {
	static showAlert(message: string, type: 'success' | 'error' = 'error') {
		const alertDiv = document.createElement('div');
		alertDiv.className = `fixed top-4 right-4 z-50 p-4 rounded-lg shadow-lg max-w-md ${
			type === 'success' ? 'bg-green-100 border border-green-400 text-green-700' : 'bg-red-100 border border-red-400 text-red-700'
		}`;
		alertDiv.innerHTML = `
			<div class="flex items-center">
				<div class="flex-shrink-0">
					${type === 'success' ? 
						'<svg class="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>' :
						'<svg class="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"></path></svg>'
					}
				</div>
				<div class="ml-3">
					<p class="text-sm font-medium">${message}</p>
				</div>
				<div class="ml-auto pl-3">
					<button onclick="this.parentElement.parentElement.parentElement.remove()" class="inline-flex text-gray-400 hover:text-gray-600">
						<svg class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path></svg>
					</button>
				</div>
			</div>
		`;
		document.body.appendChild(alertDiv);
		setTimeout(() => {
			if (alertDiv.parentElement) alertDiv.remove();
		}, 5000);
	}

	static showLoadingSpinner(container: HTMLElement, message: string = 'Loading...') {
		container.innerHTML = `
			<div class="flex justify-center items-center h-32">
				<div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
				<span class="ml-2 text-gray-600">${message}</span>
			</div>`;
	}

	static createButton(text: string, onClick: () => void, classes: string = '', icon?: string) {
		const button = document.createElement('button');
		button.className = classes;
		button.innerHTML = icon ? `${icon} ${text}` : text;
		button.addEventListener('click', onClick);
		return button;
	}

	static createInput(label: string, type: string = 'text', placeholder: string = '', required: boolean = false, value: string = '') {
		const container = document.createElement('div');
		container.className = 'form-field';
		container.innerHTML = `
			<label class="font-weight:600;color:#334155;margin-bottom:6px">${label}</label>
			<input type="${type}" placeholder="${placeholder}" ${required ? 'required' : ''} value="${value}" 
					class="w-full;padding:8px;border:1px solid #cbd5e1;border-radius:6px;box-sizing:border-box">
		`;
		return container;
	}

	static openModal(title: string, contentHtml: string, onSave?: () => Promise<void> | void) {
		const overlay = document.createElement('div');
		overlay.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/50';
		const modal = document.createElement('div');
		modal.className = 'bg-white w-full max-w-xl max-h-[85vh] rounded-2xl shadow-xl overflow-hidden flex flex-col';
		modal.innerHTML = `
			<div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
				<h3 class="text-lg font-semibold">${title}</h3>
				<button id="modalCloseBtn" class="text-gray-500 hover:text-gray-700">✕</button>
			</div>
			<div id="modalBody" class="p-6 overflow-y-auto">${contentHtml}</div>
			<div class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
				${onSave ? '<button id="modalSaveBtn" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save</button>' : ''}
				<button id="modalCancelBtn" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Close</button>
			</div>`;
		overlay.appendChild(modal);
		document.body.appendChild(overlay);
		const close = () => overlay.remove();
		(document.getElementById('modalCloseBtn') as HTMLButtonElement).onclick = close;
		(document.getElementById('modalCancelBtn') as HTMLButtonElement).onclick = close;
		const saveBtn = document.getElementById('modalSaveBtn') as HTMLButtonElement | null;
		if (saveBtn && onSave) {
			saveBtn.onclick = async () => {
				try { await onSave(); close(); UIComponents.showAlert('Saved', 'success'); } catch (e) { UIComponents.showAlert('Failed to save', 'error'); }
			};
		}
		return { close };
	}
}



