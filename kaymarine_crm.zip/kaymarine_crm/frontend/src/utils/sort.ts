import { parseTimeToMs } from './dates';

export function compareOrdersByEtbEta(a: any, b: any): number {
	const aHasEtb = !!a.etb;
	const bHasEtb = !!b.etb;
	if (aHasEtb !== bHasEtb) return aHasEtb ? -1 : 1;
	const aTime = aHasEtb ? parseTimeToMs(a.etb) : parseTimeToMs(a.eta);
	const bTime = bHasEtb ? parseTimeToMs(b.etb) : parseTimeToMs(b.eta);
	return bTime - aTime;
}

