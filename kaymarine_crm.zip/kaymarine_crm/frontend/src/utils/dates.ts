const ISO_DATETIME_RE =
	/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2}))?(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)?/;
const DATE_ONLY_RE = /^(\d{4})-(\d{2})-(\d{2})/;
const TIME_ONLY_RE = /^(\d{2}):(\d{2})(?::(\d{2}))?/;

export interface ParsedDateTimeParts {
	year: number;
	month: number;
	day: number;
	hour: number;
	minute: number;
	second: number;
}

/** Parse ISO date/time strings without applying browser timezone conversion */
export function parseIsoDateTime(value: any): ParsedDateTimeParts | null {
	if (!value) return null;
	const dateStr = typeof value === 'string' ? value.trim() : value.toString().trim();
	const match = dateStr.match(ISO_DATETIME_RE);
	if (!match) return null;

	const [, year, month, day, hour = '0', minute = '0', second = '0'] = match;
	return {
		year: Number(year),
		month: Number(month),
		day: Number(day),
		hour: Number(hour),
		minute: Number(minute),
		second: Number(second),
	};
}

export function parseTimeToMs(value: any): number {
	const parts = parseIsoDateTime(value);
	if (parts) {
		return Date.UTC(
			parts.year,
			parts.month - 1,
			parts.day,
			parts.hour,
			parts.minute,
			parts.second
		);
	}

	if (!value) return -Infinity;
	let v: any = value;
	if (typeof v === 'string') {
		v = v.includes('T') ? v : v.replace(' ', 'T');
	}
	const t = new Date(v).getTime();
	return isNaN(t) ? -Infinity : t;
}

export function formatDateInput(value: any): string {
	if (!value) return '';
	const parts = parseIsoDateTime(value);
	if (parts) {
		return `${parts.year}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`;
	}

	const dateStr = typeof value === 'string' ? value : value.toString();
	const match = dateStr.match(DATE_ONLY_RE);
	if (match) return `${match[1]}-${match[2]}-${match[3]}`;
	return '';
}

export function formatTimeInput(value: any): string {
	if (!value) return '';
	const parts = parseIsoDateTime(value);
	if (parts && String(value).includes('T')) {
		return `${String(parts.hour).padStart(2, '0')}:${String(parts.minute).padStart(2, '0')}`;
	}

	const dateStr = typeof value === 'string' ? value : value.toString();
	const match = dateStr.match(TIME_ONLY_RE);
	if (match) return `${match[1]}:${match[2]}`;
	return '';
}

/** Format date-only values without timezone conversion */
export function formatDateNoTZ(value: any): string {
	if (!value) return '-';
	const parts = parseIsoDateTime(value);
	if (parts) {
		const mm = String(parts.month).padStart(2, '0');
		const dd = String(parts.day).padStart(2, '0');
		return `${mm}/${dd}/${parts.year}`;
	}

	const dateStr = typeof value === 'string' ? value : value.toString();
	const match = dateStr.match(DATE_ONLY_RE);
	if (match) {
		const [, year, month, day] = match;
		return `${month}/${day}/${year}`;
	}
	return '-';
}

// Format datetime without timezone conversion - displays the same time as stored in database
export function formatDateTimeNoTZ(value: any): string {
	if (!value) return '-';
	const parts = parseIsoDateTime(value);
	if (parts) {
		const mm = String(parts.month).padStart(2, '0');
		const dd = String(parts.day).padStart(2, '0');
		const hh = String(parts.hour).padStart(2, '0');
		const mi = String(parts.minute).padStart(2, '0');
		const ss = String(parts.second).padStart(2, '0');
		return `${mm}/${dd}/${parts.year}, ${hh}:${mi}:${ss}`;
	}

	const d = new Date(value);
	if (isNaN(d.getTime())) return '-';
	const yyyy = d.getUTCFullYear();
	const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
	const dd = String(d.getUTCDate()).padStart(2, '0');
	const hh = String(d.getUTCHours()).padStart(2, '0');
	const mi = String(d.getUTCMinutes()).padStart(2, '0');
	const ss = String(d.getUTCSeconds()).padStart(2, '0');
	return `${mm}/${dd}/${yyyy}, ${hh}:${mi}:${ss}`;
}

/** Value for HTML datetime-local inputs without timezone shift */
export function formatDateTimeLocalInput(value: any): string {
	const parts = parseIsoDateTime(value);
	if (!parts) return '';
	return `${parts.year}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}T${String(parts.hour).padStart(2, '0')}:${String(parts.minute).padStart(2, '0')}`;
}

/** Combine date + time for API payloads without browser timezone conversion */
export function combineDateAndTime(date: string, time: string): string {
	if (!date || !time) return '';
	const normalizedTime = time.length >= 5 ? time.slice(0, 5) : time;
	return `${date}T${normalizedTime}:00`;
}

/** Extract YYYY-MM-DD key for grouping/filtering without timezone conversion */
export function toDateKey(value: any): string {
	if (!value) return '';
	const parts = parseIsoDateTime(value);
	if (parts) {
		return `${parts.year}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`;
	}

	const dateStr = typeof value === 'string' ? value : value.toString();
	const match = dateStr.match(DATE_ONLY_RE);
	return match ? `${match[1]}-${match[2]}-${match[3]}` : '';
}
