export function parseTimeToMs(value: any): number {
	if (!value) return -Infinity;
	let v: any = value;
	if (typeof v === 'string') {
		v = v.includes('T') ? v : v.replace(' ', 'T');
	}
	const t = new Date(v).getTime();
	return isNaN(t) ? -Infinity : t;
}

export function formatDateInput(value: any): string {
	if (!value) return '';
	const t = parseTimeToMs(value);
	if (!isFinite(t)) return '';
	const d = new Date(t);
	const yyyy = d.getFullYear();
	const mm = String(d.getMonth() + 1).padStart(2, '0');
	const dd = String(d.getDate()).padStart(2, '0');
	return `${yyyy}-${mm}-${dd}`;
}

export function formatTimeInput(value: any): string {
	if (!value) return '';
	const t = parseTimeToMs(value);
	if (!isFinite(t)) return '';
	const d = new Date(t);
	const hh = String(d.getHours()).padStart(2, '0');
	const mi = String(d.getMinutes()).padStart(2, '0');
	return `${hh}:${mi}`;
}

