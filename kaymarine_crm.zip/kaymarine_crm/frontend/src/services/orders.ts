import { apiBase } from '../config';

export async function listOrders() {
	const res = await fetch(`${apiBase}/discharge-forms/`, {
		headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
	});
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
	return await res.json();
}

export async function getOrder(orderId: number) {
	const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
		headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
	});
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
	return await res.json();
}

export async function patchOrder(orderId: number, payload: any) {
	const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
		method: 'PATCH',
		headers: {
			'Content-Type': 'application/json',
			'Authorization': `Bearer ${localStorage.getItem('access')}`
		},
		body: JSON.stringify(payload)
	});
	if (!res.ok) {
		const data = await res.json().catch(() => ({}));
		throw new Error(data.detail || `HTTP ${res.status}`);
	}
}

export async function deleteOrderReq(orderId: number) {
	const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
		method: 'DELETE',
		headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
	});
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

export async function uploadReceipt(orderId: number, file: File) {
  const form = new FormData();
  form.append('file', file);
  const res = await fetch(`${apiBase}/discharge-forms/${orderId}/upload-receipt/`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` },
    body: form,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

