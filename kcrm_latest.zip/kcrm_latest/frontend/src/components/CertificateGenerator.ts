/**
 * Certificate Generator for Discharge Certificates
 * Handles generation of HTML certificates for discharge orders
 */

/**
 * Calculate total quantities from all vessel plans
 */
export function calculateTotalQuantities(order: any) {
  const totals = {
    cat_a_plastic: 0,
    cat_c_domestic_waste: 0,
    cat_e_incinerator_ashes: 0,
    cat_f_operational_waste: 0,
    cat_g_cargo_residue: 0,
    cat_i_fishing_gear: 0,
    cat_j_other_e_waste: 0,
    total_volume: 0
  };
  
  if (order.vessel_plans && order.vessel_plans.length > 0) {
    order.vessel_plans.forEach((plan: any) => {
      totals.cat_a_plastic += parseFloat(plan.cat_a_plastic || 0);
      totals.cat_c_domestic_waste += parseFloat(plan.cat_c_domestic_waste || 0);
      totals.cat_e_incinerator_ashes += parseFloat(plan.cat_e_incinerator_ashes || 0);
      totals.cat_f_operational_waste += parseFloat(plan.cat_f_operational_waste || 0);
      totals.cat_g_cargo_residue += parseFloat(plan.cat_g_cargo_residue || 0);
      totals.cat_i_fishing_gear += parseFloat(plan.cat_i_fishing_gear || 0);
      totals.cat_j_other_e_waste += parseFloat(plan.cat_j_other_e_waste || 0);
    });
    
    // Calculate total volume
    totals.total_volume = totals.cat_a_plastic + totals.cat_c_domestic_waste + 
                          totals.cat_e_incinerator_ashes + totals.cat_f_operational_waste + 
                          totals.cat_g_cargo_residue + totals.cat_i_fishing_gear + 
                          totals.cat_j_other_e_waste;
  }
  
  return totals;
}

/**
 * Generate discharge certificate HTML and open in new window for printing
 */
export function generateDischargeCertificate(order: any) {
  // Calculate total quantities from all vessel plans
  const totals = calculateTotalQuantities(order);
  
  // Create certificate HTML
  const certificateHTML = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Garbage Discharge Certificate - ${order.ship_name}</title>
      <style>
        @page {
          size: A4;
          margin: 10mm;
        }
        
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: white;
          font-size: 14px;
          line-height: 1.4;
          height: 100vh;
          display: flex;
          flex-direction: column;
        }
        
        .certificate {
          width: 100%;
          height: 100%;
          margin: 0 auto;
          border: 2px solid #333;
          padding: 20px;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          position: relative;
        }
        
        .header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 25px;
        }
        
        .logo {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        
        .logo-icon {
          width: 45px;
          height: 45px;
          background-image: url('${import.meta.env.BASE_URL}logo.png');
          background-size: contain;
          background-repeat: no-repeat;
          background-position: center;
        }
        
        .logo-text {
          font-weight: bold;
          font-size: 16px;
        }
        
        .logo-subtitle {
          font-size: 12px;
          color: #666;
        }
        
        .title {
          text-align: center;
          font-size: 18px;
          font-weight: bold;
          margin: 20px 0;
        }
        
        .company-info {
          text-align: right;
          font-size: 13px;
        }
        
        .vessel-info {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 15px;
          margin-bottom: 25px;
        }
        
        .info-field {
          display: flex;
          flex-direction: column;
        }
        
        .info-label {
          font-size: 11px;
          color: #666;
          margin-bottom: 5px;
        }
        
        .info-value {
          font-weight: bold;
          border-bottom: 1px solid #333;
          padding-bottom: 5px;
          min-height: 20px;
          font-size: 12px;
        }
        
        .table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 25px;
          font-size: 12px;
          flex-grow: 1;
        }
        
        .table th, .table td {
          border: 1px solid #333;
          padding: 8px;
          text-align: center;
        }
        
        .table th {
          background-color: #f0f0f0;
          font-weight: bold;
          font-size: 11px;
          padding: 10px 8px;
        }
        
        .table td {
          padding: 10px 8px;
        }
        
        .quantity-cell {
          background-color: #e8f5e9;
          font-weight: bold;
        }
        
        .total-row {
          background-color: #e8f5e9;
          font-weight: bold;
          font-size: 13px;
        }
        
        .footer {
          text-align: center;
          margin-top: auto;
          font-size: 13px;
          padding-left: 120px;
          min-height: 120px;
        }
        
        .footer-title {
          font-weight: bold;
          margin-bottom: 10px;
          font-size: 14px;
        }
        
        .footer-contact {
          color: #666;
          font-size: 12px;
        }
        
        .stamp-container {
          position: absolute;
          bottom: 20px;
          left: 20px;
          z-index: 10;
        }
        
        .stamp-image {
          width: 100px;
          height: 100px;
          object-fit: contain;
          display: block;
        }
        
        /* Print-specific styles */
        @media print {
          body {
            margin: 0;
            padding: 0;
            height: auto;
          }
          
          .certificate {
            border: 2px solid #333;
            padding: 20px;
            margin: 0;
            height: auto;
            min-height: 100vh;
            position: relative;
          }
          
          .table-wrapper {
            position: relative;
            page-break-inside: avoid;
          }
          
          .stamp-container {
            position: absolute;
            bottom: 20px;
            left: 20px;
            page-break-inside: avoid;
            page-break-after: avoid;
          }
          
          .table {
            page-break-inside: avoid;
          }
          
          .footer {
            page-break-inside: avoid;
          }
        }
      </style>
    </head>
    <body>
      <div class="certificate">
        <div class="header">
          <div class="logo">
            <div class="logo-icon"></div>
            <div>
              <div class="logo-text">Kay Marine</div>
              <div class="logo-subtitle">Ship Survey and Services</div>
            </div>
          </div>
          <div class="company-info">
            <div><strong>KAY MARINE PTY LTD</strong></div>
            <div>A.B.N 44 643 899 414</div>
          </div>
        </div>
        
        <div class="title">Garbage Discharge Certificate as per MARPOL Annex V</div>
        
        <div class="vessel-info">
          <div class="info-field">
            <div class="info-label">Ship Name</div>
            <div class="info-value">${order.ship_name || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Berth</div>
            <div class="info-value">${order.berth || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Collection Date & Time</div>
            <div class="info-value">${order.collecting_boat?.collection_time ? new Date(order.collecting_boat.collection_time).toLocaleString() : ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Flag</div>
            <div class="info-value">${order.flag || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Port</div>
            <div class="info-value">${order.port || 'Port Hedland'}</div>
          </div>
          <div class="info-field">
            <div class="info-label">IMO no.</div>
            <div class="info-value">${order.imo_no || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Type</div>
            <div class="info-value">${order.vessel_type || ''}</div>
          </div>
        </div>
        
        <div class="stamp-container">
          <img src="${import.meta.env.BASE_URL}stamp.jpg" alt="Stamp" class="stamp-image" />
        </div>
        
        <div class="table-wrapper">
        <table class="table">
          <thead>
            <tr>
              <th>No.</th>
              <th>MARPOL Annex V. Garbage</th>
              <th>Quantity in Meter cubes</th>
              <th>Origin</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Cat A. Plastic</td>
              <td class="quantity-cell">${totals.cat_a_plastic || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Cat B. Food Waste</td>
              <td>N/A</td>
              <td>N/A</td>
            </tr>
            <tr>
              <td>3</td>
              <td>Cat C. Domestic Waste</td>
              <td class="quantity-cell">${totals.cat_c_domestic_waste || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>4</td>
              <td>Cat D. Cooking Oil (N/A)</td>
              <td>N/A</td>
              <td>N/A</td>
            </tr>
            <tr>
              <td>5</td>
              <td>Cat E. Incinerator Ashes</td>
              <td class="quantity-cell">${totals.cat_e_incinerator_ashes || '0'}</td>
              <td>ER</td>
            </tr>
            <tr>
              <td>6</td>
              <td>Cat F. Operational Waste</td>
              <td class="quantity-cell">${totals.cat_f_operational_waste || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>7</td>
              <td>Cat. G Animal carcass(es)</td>
              <td class="quantity-cell">${totals.cat_g_cargo_residue || '0'}</td>
              <td>Cargo Holds</td>
            </tr>
            <tr>
              <td>8</td>
              <td>Cat. H Fishing gear</td>
              <td>N/A</td>
              <td>N/A</td>
            </tr>
            <tr>
              <td>9</td>
              <td>Cat. I E-waste (No Batteries)</td>
              <td class="quantity-cell">${totals.cat_i_fishing_gear || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>10</td>
              <td>Cat. J Cargo residues (non-Harmful to the Marine Environment)</td>
              <td class="quantity-cell">${totals.cat_j_other_e_waste || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
          </tbody>
          <tfoot>
            <tr class="total-row">
              <td colspan="2"><strong>Total Vol:</strong></td>
              <td><strong>${totals.total_volume || '0'} CUBIC</strong></td>
              <td></td>
            </tr>
          </tfoot>
        </table>
        </div>
        
        <div class="footer">
          <div class="footer-title">**** RECEIVED AT PORT HEDLAND</div>
          <div class="footer-contact">
            <div><strong>Kay Marine</strong></div>
            <div>Ship Survey, Supplies and Services</div>
            <div>info@kaymarine.com.au</div>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
  
  // Open certificate in new window
  const newWindow = window.open('', '_blank');
  if (newWindow) {
    newWindow.document.write(certificateHTML);
    newWindow.document.close();
    
    // Wait for content to load, then print
    newWindow.onload = () => {
      newWindow.print();
    };
  }
}

