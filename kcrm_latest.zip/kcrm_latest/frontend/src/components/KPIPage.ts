import { Chart, registerables } from 'chart.js';
import { listOrders } from '../services/orders';

// Register Chart.js components
Chart.register(...registerables);

export interface KPIData {
  timelinessPct: number;
  volumeAllocationPct: number;
  incidentFreePct: number;
  docsPct: number;
  avgRating: number;
  total: number;
  recentOrders: any[];
  dailyVolumes: Record<string, number>;
  timelinessData: { onTime: number; late: number };
  incidentData: { incidentFree: number; withIncidents: number };
  docsData: { complete: number; incomplete: number };
  ratingDistribution: { rating: number; count: number }[];
}

export class KPIPage {
  private chartInstances: Chart[] = [];

  /**
   * Calculate all KPI metrics from orders
   */
  async calculateKPIs(orders: any[]): Promise<KPIData> {
    const total = orders.length;
    const ms60 = 60 * 60 * 1000; // 60 minutes tolerance

    // Timeliness calculation
    const onTime = orders.filter((o: any) => {
      if (!o.scheduled_offload_at || !o.collecting_boat?.collection_time) return false;
      const diff = Math.abs(
        new Date(o.collecting_boat.collection_time).getTime() -
        new Date(o.scheduled_offload_at).getTime()
      );
      return diff <= ms60;
    }).length;
    const timelinessPct = total ? Math.round((onTime / total) * 100) : 0;

    // Volume Allocation calculation
    const dailyVolumes: Record<string, number> = {};
    const dailyLimit = 10; // 10 cubic meters per day

    orders.forEach((order: any) => {
      if (!order.date) return;
      const orderDate = new Date(order.date);
      const dateKey = orderDate.toISOString().split('T')[0];
      const orderVolume =
        typeof order.total_volume === 'number'
          ? order.total_volume
          : parseFloat(order.total_volume || 0) || 0;

      if (!dailyVolumes[dateKey]) {
        dailyVolumes[dateKey] = 0;
      }
      dailyVolumes[dateKey] += orderVolume;
    });

    const dailyPercentages: number[] = [];
    Object.keys(dailyVolumes).forEach((dateKey) => {
      const dailyUsed = dailyVolumes[dateKey];
      const dailyPct = Math.min((dailyUsed / dailyLimit) * 100, 100);
      dailyPercentages.push(dailyPct);
    });

    const volumeAllocationPct =
      dailyPercentages.length > 0
        ? Math.round(
            dailyPercentages.reduce((sum, pct) => sum + pct, 0) /
              dailyPercentages.length
          )
        : 0;

    // Incident Free calculation
    const noIncident = orders.filter((o: any) => !o.incident_occurred).length;
    const incidentFreePct = total ? Math.round((noIncident / total) * 100) : 0;

    // Documentation Complete calculation
    const docsComplete = orders.filter((o: any) => !!o.docs_complete).length;
    const docsPct = total ? Math.round((docsComplete / total) * 100) : 0;

    // Customer Rating calculation
    const rated = orders.filter(
      (o: any) => typeof o.customer_rating === 'number'
    );
    const avgRating = rated.length
      ? parseFloat(
          (
            rated.reduce((a: number, o: any) => a + (o.customer_rating || 0), 0) /
            rated.length
          ).toFixed(2)
        )
      : 0;

    // Recent orders
    const recent = [...orders]
      .sort(
        (a: any, b: any) =>
          new Date(b.created_at).getTime() -
          new Date(a.created_at).getTime()
      )
      .slice(0, 5);

    // Data for charts
    const timelinessData = {
      onTime,
      late: total - onTime,
    };

    const incidentData = {
      incidentFree: noIncident,
      withIncidents: total - noIncident,
    };

    const docsData = {
      complete: docsComplete,
      incomplete: total - docsComplete,
    };

    // Rating distribution
    const ratingMap: Record<number, number> = {};
    rated.forEach((o: any) => {
      const rating = Math.floor(o.customer_rating || 0);
      ratingMap[rating] = (ratingMap[rating] || 0) + 1;
    });
    const ratingDistribution = Object.keys(ratingMap)
      .map((r) => ({
        rating: parseInt(r),
        count: ratingMap[parseInt(r)],
      }))
      .sort((a, b) => a.rating - b.rating);

    return {
      timelinessPct,
      volumeAllocationPct,
      incidentFreePct,
      docsPct,
      avgRating,
      total,
      recentOrders: recent,
      dailyVolumes,
      timelinessData,
      incidentData,
      docsData,
      ratingDistribution,
    };
  }

  /**
   * Create a doughnut chart
   */
  private createDoughnutChart(
    canvasId: string,
    _label: string,
    data: { label: string; value: number; color: string }[],
    centerText?: string
  ): Chart {
    const canvas = document.getElementById(canvasId) as HTMLCanvasElement;
    if (!canvas) {
      throw new Error(`Canvas element with id ${canvasId} not found`);
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Could not get canvas context');
    }

    // Destroy existing chart if it exists
    const existingChart = Chart.getChart(canvas);
    if (existingChart) {
      existingChart.destroy();
    }

    return new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: data.map((d) => d.label),
        datasets: [
          {
            data: data.map((d) => d.value),
            backgroundColor: data.map((d) => d.color),
            borderWidth: 2,
            borderColor: '#ffffff',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 10,
              font: {
                size: 12,
              },
            },
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const label = context.label || '';
                const value = context.parsed || 0;
                const total = context.dataset.data.reduce(
                  (a: number, b: number) => a + b,
                  0
                );
                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : '0';
                return `${label}: ${value} (${percentage}%)`;
              },
            },
          },
        },
      },
      plugins: [
        {
          id: 'centerText',
          beforeDraw: (chart) => {
            if (centerText) {
              const ctx = chart.ctx;
              const centerX = chart.chartArea.left + (chart.chartArea.right - chart.chartArea.left) / 2;
              const centerY = chart.chartArea.top + (chart.chartArea.bottom - chart.chartArea.top) / 2;
              
              ctx.save();
              ctx.font = 'bold 20px Arial';
              ctx.fillStyle = '#374151';
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.fillText(centerText, centerX, centerY);
              ctx.restore();
            }
          },
        },
      ],
    });
  }

  /**
   * Create a bar chart
   */
  private createBarChart(
    canvasId: string,
    label: string,
    labels: string[],
    data: number[],
    backgroundColor: string
  ): Chart {
    const canvas = document.getElementById(canvasId) as HTMLCanvasElement;
    if (!canvas) {
      throw new Error(`Canvas element with id ${canvasId} not found`);
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Could not get canvas context');
    }

    // Destroy existing chart if it exists
    const existingChart = Chart.getChart(canvas);
    if (existingChart) {
      existingChart.destroy();
    }

    return new Chart(ctx, {
      type: 'bar',
      data: {
        labels,
        datasets: [
          {
            label,
            data,
            backgroundColor,
            borderColor: backgroundColor,
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: false,
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                return `${label}: ${context.parsed.y}`;
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
            },
          },
        },
      },
    });
  }

  /**
   * Create a line chart for volume over time
   */
  private createLineChart(
    canvasId: string,
    label: string,
    labels: string[],
    data: number[],
    color: string
  ): Chart {
    const canvas = document.getElementById(canvasId) as HTMLCanvasElement;
    if (!canvas) {
      throw new Error(`Canvas element with id ${canvasId} not found`);
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      throw new Error('Could not get canvas context');
    }

    // Destroy existing chart if it exists
    const existingChart = Chart.getChart(canvas);
    if (existingChart) {
      existingChart.destroy();
    }

    return new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [
          {
            label,
            data,
            borderColor: color,
            backgroundColor: color + '20',
            borderWidth: 2,
            fill: true,
            tension: 0.4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            display: true,
            position: 'top',
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                return `${label}: ${context.parsed.y?.toFixed(2) ?? '0'} m³`;
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            title: {
              display: true,
              text: 'Volume (m³)',
            },
          },
        },
      },
    });
  }

  /**
   * Render KPI cards
   */
  private renderKPICards(data: KPIData): string {
    const card = (title: string, value: string, color: string) => `
      <div class="p-5 rounded-xl border shadow-sm bg-white">
        <p class="text-sm text-gray-500 mb-1">${title}</p>
        <p class="text-2xl font-bold ${color}">${value}</p>
      </div>`;

    return `
      ${card('Timeliness Compliance', data.timelinessPct + '%', 'text-green-600')}
      ${card('Volume Allocation Used', data.volumeAllocationPct + '%', 'text-blue-600')}
      ${card('Incident Free', data.incidentFreePct + '%', 'text-emerald-600')}
      ${card('Documentation Complete', data.docsPct + '%', 'text-indigo-600')}
      ${card('Customer Rating (avg /10)', data.avgRating.toFixed(2), 'text-yellow-600')}
    `;
  }

  /**
   * Render charts section
   */
  private renderCharts(data: KPIData): string {
    return `
      <!-- Timeliness Chart -->
      <div class="col-span-full lg:col-span-1 p-5 rounded-xl border shadow-sm bg-white">
        <h3 class="text-sm font-semibold text-gray-700 mb-4">Timeliness Compliance</h3>
        <div class="h-64">
          <canvas id="timelinessChart"></canvas>
        </div>
      </div>

      <!-- Volume Allocation Chart -->
      <div class="col-span-full lg:col-span-1 p-5 rounded-xl border shadow-sm bg-white">
        <h3 class="text-sm font-semibold text-gray-700 mb-4">Volume Over Time</h3>
        <div class="h-64">
          <canvas id="volumeChart"></canvas>
        </div>
      </div>

      <!-- Incident Free Chart -->
      <div class="col-span-full lg:col-span-1 p-5 rounded-xl border shadow-sm bg-white">
        <h3 class="text-sm font-semibold text-gray-700 mb-4">Incident Status</h3>
        <div class="h-64">
          <canvas id="incidentChart"></canvas>
        </div>
      </div>

      <!-- Documentation Chart -->
      <div class="col-span-full lg:col-span-1 p-5 rounded-xl border shadow-sm bg-white">
        <h3 class="text-sm font-semibold text-gray-700 mb-4">Documentation Status</h3>
        <div class="h-64">
          <canvas id="docsChart"></canvas>
        </div>
      </div>

      <!-- Rating Distribution Chart -->
      <div class="col-span-full lg:col-span-2 p-5 rounded-xl border shadow-sm bg-white">
        <h3 class="text-sm font-semibold text-gray-700 mb-4">Customer Rating Distribution</h3>
        <div class="h-64 relative">
          <canvas id="ratingChart"></canvas>
          ${data.ratingDistribution.length === 0 ? `
            <div class="absolute inset-0 flex items-center justify-center bg-white bg-opacity-90">
              <p class="text-gray-500 text-sm">No customer ratings available</p>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  }

  /**
   * Render recent orders table
   */
  private renderRecentOrders(recentOrders: any[]): string {
    return `
      <div class="col-span-full p-5 rounded-xl border shadow-sm bg-white">
        <p class="text-sm text-gray-500 mb-3 font-semibold">Recent Orders</p>
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Job ID</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ship Name</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Volume</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Additional</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service purchase</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200 text-sm">
              ${recentOrders
                .map((o: any) => {
                  let totalVolume =
                    typeof o.total_volume === 'number'
                      ? o.total_volume
                      : parseFloat(o.total_volume || 0) || 0;
                  let additionalVolume = 0;
                  let serviceVolume = 0;

                  if (o.vessel_plans && o.vessel_plans.length > 0) {
                    o.vessel_plans.forEach((plan: any) => {
                      if (
                        plan.plan_type === 'additional' &&
                        plan.total_volume
                      ) {
                        additionalVolume = parseFloat(plan.total_volume) || 0;
                      } else if (
                        plan.plan_type === 'service_purchase' &&
                        plan.total_volume
                      ) {
                        serviceVolume = parseFloat(plan.total_volume) || 0;
                      }
                    });
                  }

                  return `
                    <tr>
                      <td class="px-4 py-2 whitespace-nowrap text-gray-900">${o.id}</td>
                      <td class="px-4 py-2 whitespace-nowrap text-gray-700">${o.ship_name}</td>
                      <td class="px-4 py-2 whitespace-nowrap text-gray-700">${totalVolume.toFixed(2)}</td>
                      <td class="px-4 py-2 whitespace-nowrap text-gray-700">${additionalVolume.toFixed(2)}</td>
                      <td class="px-4 py-2 whitespace-nowrap text-gray-700">${serviceVolume.toFixed(2)}</td>
                    </tr>`;
                })
                .join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  }

  /**
   * Initialize and render charts
   */
  private initializeCharts(data: KPIData): void {
    // Clear existing charts
    this.chartInstances.forEach((chart) => chart.destroy());
    this.chartInstances = [];

    // Timeliness Chart
    const timelinessChart = this.createDoughnutChart(
      'timelinessChart',
      'Timeliness',
      [
        {
          label: 'On Time',
          value: data.timelinessData.onTime,
          color: '#10b981',
        },
        {
          label: 'Late',
          value: data.timelinessData.late,
          color: '#ef4444',
        },
      ],
      data.timelinessPct + '%'
    );
    this.chartInstances.push(timelinessChart);

    // Volume Over Time Chart
    const volumeDates = Object.keys(data.dailyVolumes).sort();
    const volumeValues = volumeDates.map((date) => data.dailyVolumes[date]);
    const formattedDates = volumeDates.map((date) => {
      const d = new Date(date);
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    });

    if (volumeDates.length > 0) {
      const volumeChart = this.createLineChart(
        'volumeChart',
        'Daily Volume',
        formattedDates,
        volumeValues,
        '#3b82f6'
      );
      this.chartInstances.push(volumeChart);
    }

    // Incident Chart
    const incidentChart = this.createDoughnutChart(
      'incidentChart',
      'Incidents',
      [
        {
          label: 'Incident Free',
          value: data.incidentData.incidentFree,
          color: '#10b981',
        },
        {
          label: 'With Incidents',
          value: data.incidentData.withIncidents,
          color: '#ef4444',
        },
      ],
      data.incidentFreePct + '%'
    );
    this.chartInstances.push(incidentChart);

    // Documentation Chart
    const docsChart = this.createDoughnutChart(
      'docsChart',
      'Documentation',
      [
        {
          label: 'Complete',
          value: data.docsData.complete,
          color: '#6366f1',
        },
        {
          label: 'Incomplete',
          value: data.docsData.incomplete,
          color: '#94a3b8',
        },
      ],
      data.docsPct + '%'
    );
    this.chartInstances.push(docsChart);

    // Rating Distribution Chart
    if (data.ratingDistribution.length > 0) {
      const ratingLabels = data.ratingDistribution.map((r) => `Rating ${r.rating}`);
      const ratingCounts = data.ratingDistribution.map((r) => r.count);
      const ratingChart = this.createBarChart(
        'ratingChart',
        'Orders',
        ratingLabels,
        ratingCounts,
        '#eab308'
      );
      this.chartInstances.push(ratingChart);
    } else {
      // Show empty state - the HTML overlay will handle the display
      // Just ensure canvas doesn't cause issues
      const canvas = document.getElementById('ratingChart') as HTMLCanvasElement;
      if (canvas) {
        // Set canvas size to prevent layout issues
        canvas.width = canvas.offsetWidth || 400;
        canvas.height = canvas.offsetHeight || 256;
      }
    }
  }

  /**
   * Load and render KPI page
   */
  async load(): Promise<void> {
    const container = document.getElementById('kpiContainer');
    if (!container) return;

    // Show loading state
    container.innerHTML = `
      <div class="col-span-full flex justify-center items-center h-24">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <span class="ml-2 text-gray-600">Calculating KPIs...</span>
      </div>`;

    try {
      let orders = await listOrders();

      // Apply date range filter if set
      const startDateInput = document.getElementById(
        'kpiStartDate'
      ) as HTMLInputElement;
      const endDateInput = document.getElementById(
        'kpiEndDate'
      ) as HTMLInputElement;

      if (
        startDateInput &&
        endDateInput &&
        startDateInput.value &&
        endDateInput.value
      ) {
        const startDate = new Date(startDateInput.value);
        startDate.setHours(0, 0, 0, 0);
        const endDate = new Date(endDateInput.value);
        endDate.setHours(23, 59, 59, 999);

        orders = orders.filter((o: any) => {
          if (!o.date) return false;
          const orderDate = new Date(o.date);
          return orderDate >= startDate && orderDate <= endDate;
        });
      }

      // Calculate KPIs
      const kpiData = await this.calculateKPIs(orders);

      // Render HTML
      container.innerHTML = `
        ${this.renderKPICards(kpiData)}
        ${this.renderCharts(kpiData)}
        ${this.renderRecentOrders(kpiData.recentOrders)}
      `;

      // Initialize charts after a short delay to ensure DOM is ready
      setTimeout(() => {
        this.initializeCharts(kpiData);
      }, 100);
    } catch (e: any) {
      console.error('Failed to load KPIs:', e);
      container.innerHTML = `<div class="col-span-full text-center text-red-600">Failed to load KPIs: ${e.message}</div>`;
    }
  }

  /**
   * Cleanup charts when component is destroyed
   */
  destroy(): void {
    this.chartInstances.forEach((chart) => chart.destroy());
    this.chartInstances = [];
  }
}

