import jsPDF from 'jspdf';

/**
 * PDF Generator for Discharge Forms
 * Handles generation of PDF documents for discharge forms
 */
export class PDFGenerator {
  /**
   * Helper function to load logo image
   */
  static async loadLogoImage(): Promise<string | null> {
    try {
      // Use dynamic base URL that works in both dev and production
      const logoPath = `${import.meta.env.BASE_URL}logo.png`;
      const response = await fetch(logoPath);
      if (!response.ok) {
        console.warn(`Logo not found at ${logoPath}, trying /logo.png`);
        // Fallback to root path
        const fallbackResponse = await fetch('/logo.png');
        if (!fallbackResponse.ok) {
          return null;
        }
        const blob = await fallbackResponse.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(blob);
        });
      }
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error('Failed to load logo:', error);
      return null;
    }
  }

  /**
   * Generate discharge form PDF
   */
  static async generateDischargeFormPDF(formData?: any) {
    const doc = new jsPDF('p', 'mm', 'a4'); // A4 format
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15; // 15mm margins
    const contentWidth = pageWidth - (margin * 2);
    
    // Colors
    const primaryColor = [37, 99, 235]; // Blue
    const textColor = [0, 0, 0]; // Black text

    // Header Section with Logo and Company Info
    // Load and add logo image
    const logoDataUrl = await PDFGenerator.loadLogoImage();
    if (logoDataUrl) {
      doc.addImage(logoDataUrl, 'PNG', margin, 15, 20, 15);
    } else {
      // Fallback to text logo if image fails
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(margin, 15, 20, 15, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text('KM', margin + 7, 22);
    }
    
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Kay marine', margin + 22, 20);
    doc.text('Supply and services', margin + 22, 23);

    // Company Information (right side)
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('KAY MARINE PTY LTD', pageWidth - margin, 20, { align: 'right' });
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('A.B.N 44 643 899 414', pageWidth - margin, 24, { align: 'right' });

    let yPosition = 45;

    // Form Title
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('MARPOL Annex V. Garbage Discharge Form', pageWidth / 2, yPosition, { align: 'center' });

    yPosition += 15;

    // Vessel Information Section
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    
    // Two column layout for vessel info
    const leftColX = margin;
    const rightColX = margin + 90;
    
    // Left column
    doc.text('Ship Name:', leftColX, yPosition);
    doc.text(formData?.ship_name || '_________________', leftColX + 25, yPosition);
    
    doc.text('Voyage no.', leftColX, yPosition + 6);
    doc.text(formData?.voyage_no || '_________________', leftColX + 25, yPosition + 6);
    
    doc.text('Flag:', leftColX, yPosition + 12);
    doc.text(formData?.flag || '_________________', leftColX + 25, yPosition + 12);
    
    doc.text('IMO no.:', leftColX, yPosition + 18);
    doc.text(formData?.imo_no || '_________________', leftColX + 25, yPosition + 18);

    // Right column
    doc.text('Berth:', rightColX, yPosition);
    doc.text(formData?.berth || '_________________', rightColX + 15, yPosition);
    
    doc.text('Port:', rightColX, yPosition + 6);
    doc.text(formData?.port || 'Port Hedland', rightColX + 15, yPosition + 6);
    
    doc.text('Type:', rightColX, yPosition + 12);
    doc.text(formData?.vessel_type || '_________________', rightColX + 15, yPosition + 12);
    
    doc.text('Vessel Email:', rightColX, yPosition + 18);
    doc.text(formData?.vessel_email || '_________________', rightColX + 30, yPosition + 18);

    // Date and Time (to the right of Berth and Port)
    doc.text('Date:', rightColX + 60, yPosition);
    doc.text(formData?.date || '____', rightColX + 75, yPosition);
    
    doc.text('Time:', rightColX + 60, yPosition + 6);
    doc.text(formData?.time || '____', rightColX + 75, yPosition + 6);

    yPosition += 25;

    // Allowance Statement
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Vessel allocated one cubic allowance.', margin, yPosition);

    yPosition += 10;

    // MARPOL Annex V. Garbage Table
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    
    // Table headers
    const colWidths = [12, 85, 45, 35];
    let xPos = margin;
    
    doc.text('No.', xPos, yPosition);
    xPos += colWidths[0];
    doc.text('MARPOL Annex V. Garbage', xPos, yPosition);
    xPos += colWidths[1];
    doc.text('Quantity in Meter cubes', xPos, yPosition);
    xPos += colWidths[2];
    doc.text('Origin', xPos, yPosition);
    
    yPosition += 6;

    // Table rows
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    
    // Helper to format origin array as comma-separated string
    const formatOrigin = (originArray: string[] | undefined): string => {
      if (!originArray || !Array.isArray(originArray) || originArray.length === 0) return '';
      return originArray.join(', ');
    };
    
    const garbageCategories = [
      { no: '1', category: 'Cat A. Plastic', quantity: formData?.cat_a_plastic || '0', origin: formatOrigin(formData?.cat_a_plastic_origin) || 'Galley' },
      { no: '2', category: 'Cat. B Food Waste', quantity: 'N/A', origin: 'N/A' },
      { no: '3', category: 'Cat. C Domestic Waste', quantity: formData?.cat_c_domestic || '0', origin: formatOrigin(formData?.cat_c_domestic_waste_origin) },
      { no: '4', category: 'Cat. D Cooking Oil (N/A)', quantity: 'N/A', origin: 'N/A' },
      { no: '5', category: 'Cat. E Incinerator Ashes', quantity: formData?.cat_e_incinerator || '0', origin: formatOrigin(formData?.cat_e_incinerator_ashes_origin) },
      { no: '6', category: 'Cat. F Operational Waste', quantity: formData?.cat_f_operational || '0', origin: formatOrigin(formData?.cat_f_operational_waste_origin) },
      { no: '7', category: 'Cat. G Animal carcass(es)', quantity: formData?.cat_g_cargo || '0', origin: formatOrigin(formData?.cat_g_cargo_residue_origin) },
      { no: '8', category: 'Cat. H Fishing gear', quantity: 'N/A', origin: 'N/A' },
      { no: '9', category: 'Cat. I E-waste (No Batteries)', quantity: formData?.cat_i_fishing || '0', origin: formatOrigin(formData?.cat_i_fishing_gear_origin) },
      { no: '10', category: 'Cat. J Cargo residues (non-Harmful to the Marine Environment)', quantity: formData?.cat_j_other || '0', origin: formatOrigin(formData?.cat_j_other_e_waste_origin) }
    ];

    garbageCategories.forEach(row => {
      xPos = margin;
      doc.text(row.no, xPos, yPosition);
      xPos += colWidths[0];
      doc.text(row.category, xPos, yPosition);
      xPos += colWidths[1];
      doc.text(row.quantity, xPos, yPosition);
      xPos += colWidths[2];
      doc.text(row.origin, xPos, yPosition);
      yPosition += 5;
    });

    // Total row
    yPosition += 3;
    doc.setFont('helvetica', 'bold');
    doc.text('Total Vol:', margin, yPosition);
    doc.text(formData?.total_volume || '1', margin + colWidths[0] + colWidths[1], yPosition);
    
    yPosition += 15;
    
    // Garbage Discharge Section
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('VESSEL PLANNED TO DISCHARGE', margin, yPosition);
    
    yPosition += 8;
    
    // Table headers
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('No.', margin, yPosition);
    doc.text('MARPOL Annex V. Garbage', margin + 10, yPosition);
    doc.text('Quantity (m³)', margin + 100, yPosition);
    doc.text('Origin', margin + 130, yPosition);
    
    yPosition += 3;

    // Draw table header line
    doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setLineWidth(0.3);
    doc.line(margin, yPosition, pageWidth - margin, yPosition);

    yPosition += 6;
    
    // Signature section - check if we need new page
    if (yPosition > pageHeight - 60) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('SIGNATURES', margin, yPosition);

    yPosition += 8;

    // Signature fields - aligned 3-column layout
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');

    const colWidth = Math.floor(contentWidth / 3);
    const colXs = [margin, margin + colWidth, margin + 2 * colWidth];
    const labels = ['Vessel Master', 'Port Authority', 'Waste Collection Service'];

    const lineLeftPadding = 28; // space reserved for label text
    const lineRightPadding = 8;
    const dateLabelWidth = 18; // 'Date:' width allocation before the line

    // First row of signature blocks
    for (let i = 0; i < labels.length; i++) {
      const x = colXs[i];
      // Label
      doc.text(`${labels[i]}:`, x, yPosition);
      // Signature line (same row)
      doc.setDrawColor(200, 200, 200);
      doc.setLineWidth(0.2);
      const sigLineStart = x + lineLeftPadding;
      const sigLineEnd = x + colWidth - lineRightPadding;
      doc.line(sigLineStart, yPosition - 0.5, sigLineEnd, yPosition - 0.5);

      // Date label and line beneath with consistent spacing
      const dateY = yPosition + 7;
      doc.text('Date:', x, dateY);
      const dateLineStart = x + dateLabelWidth;
      const dateLineEnd = x + colWidth - lineRightPadding;
      doc.line(dateLineStart, dateY - 0.5, dateLineEnd, dateY - 0.5);
    }

    // Advance below signature blocks
    yPosition += 16;
    
    // Signature line
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Master\'s Name & Signature', pageWidth - margin - 60, yPosition);
    doc.line(pageWidth - margin - 60, yPosition + 2, pageWidth - margin, yPosition + 2);
    
    yPosition += 20;

    // Instructions section
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    
    const instructions = [
      '* Only nonperishables garbage',
      '* Please declare exact volume to be discharged and origin Galley/Accommodation/ER/Bridge etc.',
      '* Please double, all the bags of garbage before dumping them into the supplied bulk bag inside bin..',
      '* How much garbage remaining on board . __________Cubic',
      '* Would you like to discharge more if Port allowance is available? Yes/No',
      '** if yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.'
    ];

    instructions.forEach(instruction => {
      doc.text(instruction, margin, yPosition);
      yPosition += 4;
    });

    // Generate filename
    const timestamp = new Date().toISOString().split('T')[0];
    const fileName = formData ? `Discharge_Form_${formData.ship_name || 'Vessel'}_${timestamp}.pdf` : `Blank_Discharge_Form_${timestamp}.pdf`;

    doc.save(fileName);
  }
  
  /**
   * Download blank discharge form PDF
   */
  static async downloadBlankForm() {
    await PDFGenerator.generateDischargeFormPDF();
  }
  
  /**
   * Download filled discharge form PDF
   */
  static async downloadFilledForm(formData: any) {
    await PDFGenerator.generateDischargeFormPDF(formData);
  }
}

