import { patchOrder } from '../services/orders';
import { UIComponents } from '../utils/ui';
import { apiBase } from '../config';

/**
 * Navigation callbacks interface
 * These functions are provided from main.ts to avoid circular dependencies
 */
export interface NavigationCallbacks {
  switchTab: (tab: 'orders' | 'create' | 'last24' | 'next24' | 'kpi') => void;
  loadOrders: () => Promise<void>;
  checkUserRole: () => Promise<boolean>;
}

/**
 * Form Handler for Discharge Order Forms
 * Handles form setup, validation, submission, and data collection
 */
export class FormHandler {
  private static navigationCallbacks: NavigationCallbacks | null = null;

  /**
   * Set navigation callbacks (called from main.ts)
   */
  static setNavigationCallbacks(callbacks: NavigationCallbacks) {
    FormHandler.navigationCallbacks = callbacks;
  }

  static setupFormHandlers() {
    // Check if we're in editing mode
    const editingOrder = (window as any).editingOrder;
    
    if (editingOrder) {
      // Populate form fields with existing order data
      FormHandler.populateFormFields(editingOrder);
    } else {
      // Clear form first to remove any previous values
      FormHandler.clearForm();
      
      // Auto-populate current date and time for new orders
      const dateInput = document.getElementById('date') as HTMLInputElement;
      const timeInput = document.getElementById('time') as HTMLInputElement;
      
      if (dateInput) {
        const now = new Date();
        const currentDate = now.toISOString().split('T')[0]; // Format: YYYY-MM-DD
        dateInput.value = currentDate;
      }
      
      if (timeInput) {
        const now = new Date();
        const currentTime = now.toTimeString().split(' ')[0].substring(0, 5); // Format: HH:MM
        timeInput.value = currentTime;
      }
    }
    
    // Hook up total calculation for each table separately
    const updateMainTotal = () => {
      let total = 0;
      const mainInputs = document.querySelectorAll<HTMLInputElement>('#main_cat_a, #main_cat_c, #main_cat_e, #main_cat_f, #main_cat_g, #main_cat_i, #main_cat_j');
      mainInputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
      (document.getElementById('totalVol') as HTMLTableCellElement).textContent = total.toFixed(2);
    };
    
    const updateAdditionalTotal = () => {
      let total = 0;
      const additionalInputs = document.querySelectorAll<HTMLInputElement>('#additional_cat_a, #additional_cat_c, #additional_cat_e, #additional_cat_f, #additional_cat_g, #additional_cat_i, #additional_cat_j');
      additionalInputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
      (document.getElementById('additional_totalVol') as HTMLTableCellElement).textContent = total.toFixed(2);
    };
    
    const updateServiceTotal = () => {
      let total = 0;
      const serviceInputs = document.querySelectorAll<HTMLInputElement>('#service_cat_a, #service_cat_c, #service_cat_e, #service_cat_f, #service_cat_g, #service_cat_i, #service_cat_j');
      serviceInputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
      (document.getElementById('service_totalVol') as HTMLTableCellElement).textContent = total.toFixed(2);
    };
    
    // Add event listeners to main table inputs
    const mainInputs = document.querySelectorAll<HTMLInputElement>('#main_cat_a, #main_cat_c, #main_cat_e, #main_cat_f, #main_cat_g, #main_cat_i, #main_cat_j');
    mainInputs.forEach(i => i.addEventListener('input', updateMainTotal));
    
    // Add event listeners to additional table inputs
    const additionalInputs = document.querySelectorAll<HTMLInputElement>('#additional_cat_a, #additional_cat_c, #additional_cat_e, #additional_cat_f, #additional_cat_g, #additional_cat_i, #additional_cat_j');
    additionalInputs.forEach(i => i.addEventListener('input', updateAdditionalTotal));
    
    // Add event listeners to service table inputs
    const serviceInputs = document.querySelectorAll<HTMLInputElement>('#service_cat_a, #service_cat_c, #service_cat_e, #service_cat_f, #service_cat_g, #service_cat_i, #service_cat_j');
    serviceInputs.forEach(i => i.addEventListener('input', updateServiceTotal));
    
    // Handle dispose additional waste checkbox
    const disposeAdditionalCheckbox = document.getElementById('dispose_additional_waste') as HTMLInputElement;
    if (disposeAdditionalCheckbox) {
      // Function to toggle additional inputs based on checkbox state
      const toggleAdditionalInputs = () => {
        const isChecked = disposeAdditionalCheckbox.checked;
        additionalInputs.forEach(input => {
          input.disabled = !isChecked;
          if (!isChecked) {
            input.value = ''; // Clear values when disabled
            input.classList.add('opacity-50', 'bg-gray-100');
          } else {
            input.classList.remove('opacity-50', 'bg-gray-100');
          }
        });
        // Update additional total when inputs are cleared
        if (!isChecked) {
          updateAdditionalTotal();
        }
      };
      
      // Set initial state
      toggleAdditionalInputs();
      
      // Add event listener for checkbox changes
      disposeAdditionalCheckbox.addEventListener('change', toggleAdditionalInputs);
    }
    
    // Handle service purchased checkbox
    const servicePurchasedCheckbox = document.getElementById('service_purchased') as HTMLInputElement;
    if (servicePurchasedCheckbox) {
      // Function to toggle service inputs based on checkbox state
      const toggleServiceInputs = () => {
        const isChecked = servicePurchasedCheckbox.checked;
        serviceInputs.forEach(input => {
          input.disabled = !isChecked;
          if (!isChecked) {
            input.value = ''; // Clear values when disabled
            input.classList.add('opacity-50', 'bg-gray-100');
          } else {
            input.classList.remove('opacity-50', 'bg-gray-100');
          }
        });
        // Update service total when inputs are cleared
        if (!isChecked) {
          updateServiceTotal();
        }
      };
      
      // Set initial state
      toggleServiceInputs();
      
      // Add event listener for checkbox changes
      servicePurchasedCheckbox.addEventListener('change', toggleServiceInputs);
    }
    
    // Enhanced form submission with redirect
    const submitButton = document.getElementById('submitOrder');
    if (submitButton) {
      submitButton.addEventListener('click', FormHandler.handleFormSubmission);
    }
    
    // Handle New Order button
    const newOrderButton = document.getElementById('newOrderBtn');
    if (newOrderButton) {
      newOrderButton.addEventListener('click', FormHandler.resetToNewOrder);
    }
  }

  static populateFormFields(order: any) {
    // Helper function to safely set input values
    const setValue = (id: string, value: any) => {
      const element = document.getElementById(id) as HTMLInputElement;
      if (element && value !== null && value !== undefined) {
        element.value = value;
      }
    };
    
    // Helper function to set selected values in multi-select dropdown
    const setSelectedValues = (id: string, values: string[] | null | undefined) => {
      const select = document.getElementById(id) as HTMLSelectElement;
      if (select && values && Array.isArray(values) && values.length > 0) {
        Array.from(select.options).forEach(option => {
          option.selected = values.includes(option.value);
        });
      }
    };
    
    // Helper function to format datetime for datetime-local inputs
    const formatDateTime = (value: any) => {
      if (!value) return '';
      const date = new Date(value);
      return date.toISOString().slice(0, 16); // Format: YYYY-MM-DDTHH:MM
    };
    
    // Helper function to format date for date inputs
    const formatDate = (value: any) => {
      if (!value) return '';
      const date = new Date(value);
      return date.toISOString().split('T')[0]; // Format: YYYY-MM-DD
    };
    
    // Helper function to format time for time inputs
    const formatTime = (value: any) => {
      if (!value) return '';
      const date = new Date(value);
      return date.toTimeString().split(' ')[0].substring(0, 5); // Format: HH:MM
    };
    
    // Populate basic form fields
    setValue('ship_name', order.ship_name);
    setValue('voyage_number', order.voyage_number);
    setValue('berth', order.berth);
    setValue('port', order.port);
    setValue('flag', order.flag);
    setValue('type', order.vessel_type);
    setValue('imo', order.imo_no);
    setValue('email', order.email);
    setValue('date', formatDate(order.date));
    setValue('time', formatTime(order.time));
    setValue('eta', formatDateTime(order.eta));
    setValue('etb', formatDateTime(order.etb));
    setValue('garbage_remaining_on_board', order.garbage_remaining_on_board_m3);
    
    // Set checkboxes
    const disposeCheckbox = document.getElementById('dispose_additional_waste') as HTMLInputElement;
    if (disposeCheckbox) {
      disposeCheckbox.checked = !!order.dispose_additional_waste;
      // Trigger change event to update additional inputs state
      disposeCheckbox.dispatchEvent(new Event('change'));
    }
    
    const serviceCheckbox = document.getElementById('service_purchased') as HTMLInputElement;
    if (serviceCheckbox) {
      serviceCheckbox.checked = !!order.service_purchased;
      // Trigger change event to update service inputs state
      serviceCheckbox.dispatchEvent(new Event('change'));
    }
    
    const shipWantsToDischargeMoreCheckbox = document.getElementById('ship_wants_to_discharge_more') as HTMLInputElement;
    if (shipWantsToDischargeMoreCheckbox) {
      shipWantsToDischargeMoreCheckbox.checked = !!order.ship_wants_to_discharge_more;
    }
    
    const alongSideCheckbox = document.getElementById('along_side') as HTMLInputElement;
    if (alongSideCheckbox) {
      alongSideCheckbox.checked = !!order.along_side;
    }
    
    // Populate note field if editable (kayadmin)
    const noteField = document.getElementById('note') as HTMLTextAreaElement;
    if (noteField) {
      const defaultNote = 'If yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.';
      noteField.value = order.note || defaultNote;
    } else {
      // If not editable, update the static note text
      const noteText = document.getElementById('noteText');
      if (noteText) {
        const defaultNote = 'If yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.';
        noteText.textContent = order.note || defaultNote;
      }
    }
    
    // Populate vessel plan data if available
    if (order.vessel_plans && order.vessel_plans.length > 0) {
      // Find vessel plans by type
      const freePlan = order.vessel_plans.find((plan: any) => plan.plan_type === 'free');
      const additionalPlan = order.vessel_plans.find((plan: any) => plan.plan_type === 'additional');
      const servicePlan = order.vessel_plans.find((plan: any) => plan.plan_type === 'service_purchase');
      
      // Populate main table (free plan)
      if (freePlan) {
        setValue('main_cat_a', freePlan.cat_a_plastic);
        setValue('main_cat_c', freePlan.cat_c_domestic_waste);
        setValue('main_cat_e', freePlan.cat_e_incinerator_ashes);
        setValue('main_cat_f', freePlan.cat_f_operational_waste);
        setValue('main_cat_g', freePlan.cat_g_cargo_residue);
        setValue('main_cat_i', freePlan.cat_i_fishing_gear);
        setValue('main_cat_j', freePlan.cat_j_other_e_waste);
        
        // Populate origin fields for main table
        setSelectedValues('main_origin_a', freePlan.cat_a_plastic_origin);
        setSelectedValues('main_origin_c', freePlan.cat_c_domestic_waste_origin);
        setSelectedValues('main_origin_e', freePlan.cat_e_incinerator_ashes_origin);
        setSelectedValues('main_origin_f', freePlan.cat_f_operational_waste_origin);
        setSelectedValues('main_origin_g', freePlan.cat_g_cargo_residue_origin);
        setSelectedValues('main_origin_i', freePlan.cat_i_fishing_gear_origin);
        setSelectedValues('main_origin_j', freePlan.cat_j_other_e_waste_origin);
        
        // Update main total volume display
        const totalVolElement = document.getElementById('totalVol');
        if (totalVolElement && freePlan.total_volume) {
          totalVolElement.textContent = freePlan.total_volume.toString();
        }
      }
      
      // Populate additional table
      if (additionalPlan) {
        setValue('additional_cat_a', additionalPlan.cat_a_plastic);
        setValue('additional_cat_c', additionalPlan.cat_c_domestic_waste);
        setValue('additional_cat_e', additionalPlan.cat_e_incinerator_ashes);
        setValue('additional_cat_f', additionalPlan.cat_f_operational_waste);
        setValue('additional_cat_g', additionalPlan.cat_g_cargo_residue);
        setValue('additional_cat_i', additionalPlan.cat_i_fishing_gear);
        setValue('additional_cat_j', additionalPlan.cat_j_other_e_waste);
        
        // Populate origin fields for additional table
        setSelectedValues('additional_origin_a', additionalPlan.cat_a_plastic_origin);
        setSelectedValues('additional_origin_c', additionalPlan.cat_c_domestic_waste_origin);
        setSelectedValues('additional_origin_e', additionalPlan.cat_e_incinerator_ashes_origin);
        setSelectedValues('additional_origin_f', additionalPlan.cat_f_operational_waste_origin);
        setSelectedValues('additional_origin_g', additionalPlan.cat_g_cargo_residue_origin);
        setSelectedValues('additional_origin_i', additionalPlan.cat_i_fishing_gear_origin);
        setSelectedValues('additional_origin_j', additionalPlan.cat_j_other_e_waste_origin);
        
        // Update additional total volume display
        const additionalTotalVolElement = document.getElementById('additional_totalVol');
        if (additionalTotalVolElement && additionalPlan.total_volume) {
          additionalTotalVolElement.textContent = additionalPlan.total_volume.toString();
        }
      }
      
      // Populate service table
      if (servicePlan) {
        setValue('service_cat_a', servicePlan.cat_a_plastic);
        setValue('service_cat_c', servicePlan.cat_c_domestic_waste);
        setValue('service_cat_e', servicePlan.cat_e_incinerator_ashes);
        setValue('service_cat_f', servicePlan.cat_f_operational_waste);
        setValue('service_cat_g', servicePlan.cat_g_cargo_residue);
        setValue('service_cat_i', servicePlan.cat_i_fishing_gear);
        setValue('service_cat_j', servicePlan.cat_j_other_e_waste);
        
        // Populate origin fields for service table
        setSelectedValues('service_origin_a', servicePlan.cat_a_plastic_origin);
        setSelectedValues('service_origin_c', servicePlan.cat_c_domestic_waste_origin);
        setSelectedValues('service_origin_e', servicePlan.cat_e_incinerator_ashes_origin);
        setSelectedValues('service_origin_f', servicePlan.cat_f_operational_waste_origin);
        setSelectedValues('service_origin_g', servicePlan.cat_g_cargo_residue_origin);
        setSelectedValues('service_origin_i', servicePlan.cat_i_fishing_gear_origin);
        setSelectedValues('service_origin_j', servicePlan.cat_j_other_e_waste_origin);
        
        // Update service total volume display
        const serviceTotalVolElement = document.getElementById('service_totalVol');
        if (serviceTotalVolElement && servicePlan.total_volume) {
          serviceTotalVolElement.textContent = servicePlan.total_volume.toString();
        }
      }
    }
    
    // Update submit button text for editing mode
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Update Discharge Order';
    }
  }

  static async handleFormSubmission(ev: Event) {
    ev.preventDefault();
    
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    const editingOrder = (window as any).editingOrder;
    
    if (!FormHandler.navigationCallbacks) {
      console.error('Navigation callbacks not set. Call FormHandler.setNavigationCallbacks() first.');
      return;
    }
    
    try {
      // Show loading state
      submitButton.disabled = true;
      const loadingText = editingOrder ? 'Updating...' : 'Submitting...';
      submitButton.innerHTML = `
        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        ${loadingText}
      `;

      // Collect form data
      const formData = FormHandler.collectFormData();
      
      if (editingOrder) {
        // Update existing order
        await patchOrder(editingOrder.id, formData);
        UIComponents.showAlert('Order updated successfully!', 'success');
        
        // Clear editing state
        (window as any).editingOrder = null;
        
        // Reset tab title
        const createTab = document.getElementById('createTab')!;
        createTab.textContent = 'Create Order';
        
        // Reset form title
        const createView = document.getElementById('createView')!;
        const titleElement = createView.querySelector('h2')!;
        titleElement.textContent = 'Create New Discharge Order';
        
        // Redirect to orders list after 1.5 seconds
        setTimeout(() => {
          FormHandler.navigationCallbacks!.switchTab('orders');
          FormHandler.navigationCallbacks!.loadOrders();
        }, 1500);
      } else {
        // Create new order
        const success = await FormHandler.submitToAPI(formData);
        
        if (success) {
          UIComponents.showAlert('Discharge order submitted successfully!', 'success');
          
          // Clear form after successful submission
          FormHandler.clearForm();
        
          // Redirect to orders list after 1.5 seconds
          setTimeout(() => {
            // Check if user is admin and redirect accordingly
            FormHandler.navigationCallbacks!.checkUserRole().then(isAdmin => {
              if (isAdmin) {
                FormHandler.navigationCallbacks!.switchTab('orders');
                FormHandler.navigationCallbacks!.loadOrders();
              } else {
                // For regular users, just show success message
                UIComponents.showAlert('Your order has been submitted for review.', 'success');
              }
            });
          }, 1500);
        }
      }
    } catch (error) {
      console.error('Form submission error:', error);
      const errorMessage = editingOrder ? 'Failed to update order. Please try again.' : 'Failed to submit order. Please try again.';
      UIComponents.showAlert(errorMessage, 'error');
    } finally {
      // Reset button state
      submitButton.disabled = false;
      const buttonText = editingOrder ? 'Update Discharge Order' : 'Submit Discharge Request';
      submitButton.textContent = buttonText;
    }
  }

  static clearForm() {
    // Clear all form inputs, textareas, and select elements
    const inputs = document.querySelectorAll('#dischargeForm input, #dischargeForm textarea, #dischargeForm select');
    inputs.forEach((input: any) => {
      if (input.type === 'checkbox') {
        input.checked = false;
      } else if (input.tagName === 'SELECT') {
        // For multi-select elements, deselect all options
        if (input.multiple) {
          Array.from<HTMLOptionElement>(input.options).forEach((option) => {
            option.selected = false;
          });
        } else {
          // For single-select, reset to first option
          input.selectedIndex = 0;
        }
      } else {
        input.value = '';
      }
    });
    
    // Explicitly clear all table quantity inputs (main, additional, service)
    const tableInputIds = [
      'main_cat_a', 'main_cat_c', 'main_cat_e', 'main_cat_f', 'main_cat_g', 'main_cat_i', 'main_cat_j',
      'additional_cat_a', 'additional_cat_c', 'additional_cat_e', 'additional_cat_f', 'additional_cat_g', 'additional_cat_i', 'additional_cat_j',
      'service_cat_a', 'service_cat_c', 'service_cat_e', 'service_cat_f', 'service_cat_g', 'service_cat_i', 'service_cat_j'
    ];
    
    tableInputIds.forEach(id => {
      const input = document.getElementById(id) as HTMLInputElement;
      if (input) {
        input.value = '';
      }
    });
    
    // Explicitly clear all origin select elements (main, additional, service)
    const originSelectIds = [
      'main_origin_a', 'main_origin_c', 'main_origin_e', 'main_origin_f', 'main_origin_g', 'main_origin_i', 'main_origin_j',
      'additional_origin_a', 'additional_origin_c', 'additional_origin_e', 'additional_origin_f', 'additional_origin_g', 'additional_origin_i', 'additional_origin_j',
      'service_origin_a', 'service_origin_c', 'service_origin_e', 'service_origin_f', 'service_origin_g', 'service_origin_i', 'service_origin_j'
    ];
    
    originSelectIds.forEach(id => {
      const select = document.getElementById(id) as HTMLSelectElement;
      if (select && select.multiple) {
        Array.from<HTMLOptionElement>(select.options).forEach((option) => {
          option.selected = false;
        });
      }
    });
    
    // Reset all total volume displays
    const totalVolElement = document.getElementById('totalVol');
    if (totalVolElement) {
      totalVolElement.textContent = '0';
    }
    
    const additionalTotalVolElement = document.getElementById('additional_totalVol');
    if (additionalTotalVolElement) {
      additionalTotalVolElement.textContent = '0';
    }
    
    const serviceTotalVolElement = document.getElementById('service_totalVol');
    if (serviceTotalVolElement) {
      serviceTotalVolElement.textContent = '0';
    }
    
    // Trigger input events to recalculate totals (in case listeners are set up)
    tableInputIds.forEach(id => {
      const input = document.getElementById(id) as HTMLInputElement;
      if (input) {
        input.dispatchEvent(new Event('input', { bubbles: true }));
      }
    });
    
    // Reset submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Submit Discharge Request';
    }
  }

  static resetToNewOrder() {
    // Clear editing state
    (window as any).editingOrder = null;
    
    // Reset tab title
    const createTab = document.getElementById('createTab')!;
    createTab.textContent = 'Create Order';
    
    // Reset form title
    const createView = document.getElementById('createView')!;
    const titleElement = createView.querySelector('h2')!;
    titleElement.textContent = 'Create New Discharge Order';
    
    // Hide New Order button
    const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
    if (newOrderButton) {
      newOrderButton.classList.add('hidden');
    }
    
    // Reset submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Submit Discharge Request';
    }
    
    // Clear form
    FormHandler.clearForm();
    
    // Auto-populate current date and time for new orders
    const dateInput = document.getElementById('date') as HTMLInputElement;
    const timeInput = document.getElementById('time') as HTMLInputElement;
    
    if (dateInput) {
      const now = new Date();
      const currentDate = now.toISOString().split('T')[0]; // Format: YYYY-MM-DD
      dateInput.value = currentDate;
    }
    
    if (timeInput) {
      const now = new Date();
      const currentTime = now.toTimeString().split(' ')[0].substring(0, 5); // Format: HH:MM
      timeInput.value = currentTime;
    }
    
    // Trigger checkbox change events to reset input states
    const disposeCheckbox = document.getElementById('dispose_additional_waste') as HTMLInputElement;
    if (disposeCheckbox) {
      disposeCheckbox.dispatchEvent(new Event('change'));
    }
    
    const serviceCheckbox = document.getElementById('service_purchased') as HTMLInputElement;
    if (serviceCheckbox) {
      serviceCheckbox.dispatchEvent(new Event('change'));
    }
  }

  static collectFormData() {
    // Collect vessel form values
    const ship_name = (document.getElementById('ship_name') as HTMLInputElement)?.value || '';
    const voyage_number = (document.getElementById('voyage_number') as HTMLInputElement)?.value || '';
    const berth = (document.getElementById('berth') as HTMLInputElement)?.value || '';
    const date = (document.getElementById('date') as HTMLInputElement)?.value || '';
    const time = (document.getElementById('time') as HTMLInputElement)?.value || '';
    const eta = (document.getElementById('eta') as HTMLInputElement)?.value || '';
    const etb = (document.getElementById('etb') as HTMLInputElement)?.value || '';
    const port = (document.getElementById('port') as HTMLInputElement)?.value || 'Port Hedland';
    const flag = (document.getElementById('flag') as HTMLInputElement)?.value || '';
    const vessel_type = (document.getElementById('type') as HTMLInputElement)?.value || '';
    const imo_no = (document.getElementById('imo') as HTMLInputElement)?.value || '';
    const email = (document.getElementById('email') as HTMLInputElement)?.value || '';
    const dispose_additional_waste = (document.getElementById('dispose_additional_waste') as HTMLInputElement)?.checked || false;
    const service_purchased = (document.getElementById('service_purchased') as HTMLInputElement)?.checked || false;
    const ship_wants_to_discharge_more = (document.getElementById('ship_wants_to_discharge_more') as HTMLInputElement)?.checked || false;
    const along_side = (document.getElementById('along_side') as HTMLInputElement)?.checked || false;
    const note = (document.getElementById('note') as HTMLTextAreaElement)?.value || '';

    // Helper function to get numeric value from input
    // For quantity fields, empty means 0, not null
    const getNum = (id: string, allowNull: boolean = false) => {
      const el = document.getElementById(id) as HTMLInputElement;
      if (!el) return null;
      const value = el.value.trim();
      if (value === '') {
        return allowNull ? null : 0;
      }
      const n = parseFloat(value);
      return isNaN(n) ? (allowNull ? null : 0) : n;
    };

    const garbage_remaining_on_board = getNum('garbage_remaining_on_board', true);

    // Helper function to get selected values from multi-select
    const getSelectedValues = (id: string): string[] => {
      const select = document.getElementById(id) as HTMLSelectElement;
      if (!select) return [];
      return Array.from(select.selectedOptions).map(opt => opt.value);
    };

    // Collect main table data (free plan) - empty fields are 0
    const main_cat_a_plastic = getNum('main_cat_a');
    const main_cat_c_domestic_waste = getNum('main_cat_c');
    const main_cat_e_incinerator_ashes = getNum('main_cat_e');
    const main_cat_f_operational_waste = getNum('main_cat_f');
    const main_cat_g_cargo_residue = getNum('main_cat_g');
    const main_cat_i_fishing_gear = getNum('main_cat_i');
    const main_cat_j_other_e_waste = getNum('main_cat_j');
    
    // Collect main table origin data
    const main_cat_a_plastic_origin = getSelectedValues('main_origin_a');
    const main_cat_c_domestic_waste_origin = getSelectedValues('main_origin_c');
    const main_cat_e_incinerator_ashes_origin = getSelectedValues('main_origin_e');
    const main_cat_f_operational_waste_origin = getSelectedValues('main_origin_f');
    const main_cat_g_cargo_residue_origin = getSelectedValues('main_origin_g');
    const main_cat_i_fishing_gear_origin = getSelectedValues('main_origin_i');
    const main_cat_j_other_e_waste_origin = getSelectedValues('main_origin_j');

    // Collect additional table data - empty fields are 0
    const additional_cat_a_plastic = getNum('additional_cat_a');
    const additional_cat_c_domestic_waste = getNum('additional_cat_c');
    const additional_cat_e_incinerator_ashes = getNum('additional_cat_e');
    const additional_cat_f_operational_waste = getNum('additional_cat_f');
    const additional_cat_g_cargo_residue = getNum('additional_cat_g');
    const additional_cat_i_fishing_gear = getNum('additional_cat_i');
    const additional_cat_j_other_e_waste = getNum('additional_cat_j');
    
    // Collect additional table origin data
    const additional_cat_a_plastic_origin = getSelectedValues('additional_origin_a');
    const additional_cat_c_domestic_waste_origin = getSelectedValues('additional_origin_c');
    const additional_cat_e_incinerator_ashes_origin = getSelectedValues('additional_origin_e');
    const additional_cat_f_operational_waste_origin = getSelectedValues('additional_origin_f');
    const additional_cat_g_cargo_residue_origin = getSelectedValues('additional_origin_g');
    const additional_cat_i_fishing_gear_origin = getSelectedValues('additional_origin_i');
    const additional_cat_j_other_e_waste_origin = getSelectedValues('additional_origin_j');

    // Collect service table data - empty fields are 0
    const service_cat_a_plastic = getNum('service_cat_a');
    const service_cat_c_domestic_waste = getNum('service_cat_c');
    const service_cat_e_incinerator_ashes = getNum('service_cat_e');
    const service_cat_f_operational_waste = getNum('service_cat_f');
    const service_cat_g_cargo_residue = getNum('service_cat_g');
    const service_cat_i_fishing_gear = getNum('service_cat_i');
    const service_cat_j_other_e_waste = getNum('service_cat_j');
    
    // Collect service table origin data
    const service_cat_a_plastic_origin = getSelectedValues('service_origin_a');
    const service_cat_c_domestic_waste_origin = getSelectedValues('service_origin_c');
    const service_cat_e_incinerator_ashes_origin = getSelectedValues('service_origin_e');
    const service_cat_f_operational_waste_origin = getSelectedValues('service_origin_f');
    const service_cat_g_cargo_residue_origin = getSelectedValues('service_origin_g');
    const service_cat_i_fishing_gear_origin = getSelectedValues('service_origin_i');
    const service_cat_j_other_e_waste_origin = getSelectedValues('service_origin_j');

    return {
      ship_name,
      voyage_number: voyage_number || null,
      berth: berth || null,
      date,
      time: time || null,
      eta: eta || null,
      etb: etb || null,
      port,
      flag: flag || null,
      vessel_type: vessel_type || null,
      imo_no: imo_no || null,
      email: email || null,
      dispose_additional_waste,
      service_purchased,
      ship_wants_to_discharge_more,
      along_side,
      note: note || null,
      garbage_remaining_on_board_m3: garbage_remaining_on_board,
      // Main table (free plan) - keep for backward compatibility
      cat_a_plastic: main_cat_a_plastic,
      cat_c_domestic_waste: main_cat_c_domestic_waste,
      cat_e_incinerator_ashes: main_cat_e_incinerator_ashes,
      cat_f_operational_waste: main_cat_f_operational_waste,
      cat_g_cargo_residue: main_cat_g_cargo_residue,
      cat_i_fishing_gear: main_cat_i_fishing_gear,
      cat_j_other_e_waste: main_cat_j_other_e_waste,
      // Main table origin data
      cat_a_plastic_origin: main_cat_a_plastic_origin,
      cat_c_domestic_waste_origin: main_cat_c_domestic_waste_origin,
      cat_e_incinerator_ashes_origin: main_cat_e_incinerator_ashes_origin,
      cat_f_operational_waste_origin: main_cat_f_operational_waste_origin,
      cat_g_cargo_residue_origin: main_cat_g_cargo_residue_origin,
      cat_i_fishing_gear_origin: main_cat_i_fishing_gear_origin,
      cat_j_other_e_waste_origin: main_cat_j_other_e_waste_origin,
      // Additional table data
      additional_cat_a_plastic,
      additional_cat_c_domestic_waste,
      additional_cat_e_incinerator_ashes,
      additional_cat_f_operational_waste,
      additional_cat_g_cargo_residue,
      additional_cat_i_fishing_gear,
      additional_cat_j_other_e_waste,
      // Additional table origin data
      additional_cat_a_plastic_origin,
      additional_cat_c_domestic_waste_origin,
      additional_cat_e_incinerator_ashes_origin,
      additional_cat_f_operational_waste_origin,
      additional_cat_g_cargo_residue_origin,
      additional_cat_i_fishing_gear_origin,
      additional_cat_j_other_e_waste_origin,
      // Service table data
      service_cat_a_plastic,
      service_cat_c_domestic_waste,
      service_cat_e_incinerator_ashes,
      service_cat_f_operational_waste,
      service_cat_g_cargo_residue,
      service_cat_i_fishing_gear,
      service_cat_j_other_e_waste,
      // Service table origin data
      service_cat_a_plastic_origin,
      service_cat_c_domestic_waste_origin,
      service_cat_e_incinerator_ashes_origin,
      service_cat_f_operational_waste_origin,
      service_cat_g_cargo_residue_origin,
      service_cat_i_fishing_gear_origin,
      service_cat_j_other_e_waste_origin,
    };
  }

  static async submitToAPI(formData: any): Promise<boolean> {
    const res = await fetch(`${apiBase}/discharge-forms/`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json', 
        'Authorization': `Bearer ${localStorage.getItem('access')}` 
      },
      body: JSON.stringify(formData),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      const msg = (errorData && (errorData.detail || JSON.stringify(errorData))) || `HTTP ${res.status}`;
      throw new Error(msg);
    }

    return true;
  }
}

