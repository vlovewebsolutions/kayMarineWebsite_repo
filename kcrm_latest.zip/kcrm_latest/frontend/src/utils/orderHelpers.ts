/**
 * Order Helper Functions
 * Utility functions for order operations and status calculations
 */

/**
 * Check if all operations are completed (excluding the automatic "Order created")
 */
export function areAllOperationsComplete(order: any): boolean {
  return (
    order.form44_submitted === true &&
    order.biosecurity_status === 'approved' &&
    order.govt_status === 'approved' &&
    order.bio_witness === true &&
    order.landfill_booked === true &&
    order.docs_complete === true &&
    order.discharge_certificate_created === true &&
    order.invoice_created === true
  );
}

/**
 * Compute stage color based on order status
 */
export function computeStageColor(order: any): 'green' | 'orange' | 'red' | 'gray' {
  if (order.govt_status === 'approved') return 'green';
  if (order.govt_status === 'rejected' || order.biosecurity_status === 'rejected') return 'red';
  if (order.biosecurity_status === 'approved') return 'orange';
  return 'gray';
}

/**
 * Convert color to badge CSS classes
 */
export function colorToBadge(color: string): string {
  switch (color) {
    case 'green': return 'bg-green-100 text-green-800';
    case 'orange': return 'bg-orange-100 text-orange-800';
    case 'red': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
}

/**
 * Generate dot indicator HTML
 */
export function dot(color: 'green' | 'orange' | 'red' | 'gray' | 'blue'): string {
  const map: Record<string, string> = {
    green: 'bg-green-500',
    orange: 'bg-orange-500',
    red: 'bg-red-500',
    gray: 'bg-gray-400',
    blue: 'bg-blue-500',
  };
  return `<span class="h-3 w-3 rounded-full ${map[color]}"></span>`;
}

/**
 * Generate select option HTML
 */
export function selectOption(value: string, current: string): string {
  const selected = value === current ? 'selected' : '';
  const label = value.charAt(0).toUpperCase() + value.slice(1);
  return `<option value="${value}" ${selected}>${label}</option>`;
}

/**
 * Generate detail row HTML
 */
export function detailRow(label: string, value: any): string {
  const safe = (v: any) => (v === null || v === undefined || v === '' ? '-' : String(v));
  return `
    <div class="flex items-center justify-between gap-4">
      <span class="text-sm text-gray-500">${label}</span>
      <span class="text-sm font-medium text-gray-900">${safe(value)}</span>
    </div>
  `;
}

