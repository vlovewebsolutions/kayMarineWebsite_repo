// API base URL - works for both development and production
// Development: uses http://localhost:8004/api
// Production: uses relative path /crm/api
export const apiBase = import.meta.env.VITE_API_BASE || 
  (import.meta.env.PROD ? '/crm/api' : 'http://localhost:8004/api');



