# Quick Start Guide - Kay Marine CRM

## 🖥️ Windows Development Setup

### First Time Setup:
1. Install Python 3.8+ and Node.js 18+
2. Clone/download the project
3. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Install Node dependencies:
   ```bash
   cd frontend
   npm install
   cd ..
   ```

### Running the Application:

#### Option 1: Run Both Servers (Recommended)
Double-click `start_both.bat`

This will start:
- Backend on `http://localhost:8004`
- Frontend on `http://localhost:5173/crm/`

#### Option 2: Run Separately
- **Backend**: Double-click `start_backend.bat`
- **Frontend**: Double-click `start_frontend.bat`

### Access the Application:
- **Frontend**: http://localhost:5173/crm/
- **Backend API**: http://localhost:8004/api/
- **Admin**: http://localhost:8004/admin/
- **API Root**: http://localhost:8004/api/

### Default Login Credentials:
- **Admin**: `kayadmin` / `kayadmin@123`
- **Boat User**: `boatadmin` / `BoatAdmin@marine`

---

## 🚀 Deploy to Production Server

### Step 1: Create Zip File (Windows)
1. Exclude these folders from zip:
   - `node_modules/`
   - `.venv/`
   - `__pycache__/`
   
2. ✅ Keep these:
   - `db.sqlite3` (your data!)
   - `media/` folder (uploaded receipts!)
   
3. Create the zip file

### Step 2: Upload to Server
Upload the zip to your VPS at `/home/vinit/`

### Step 3: Deploy (SSH to Server)
```bash
# SSH to server
ssh vinit@your-server-ip

# Extract (first time) or replace files
cd /home/vinit
unzip -o kaymarine_crm.zip

# Navigate to project
cd kaymarine_crm

# Run deployment script
chmod +x deploy_prod.sh
./deploy_prod.sh
```

The script will:
- ✅ Install Python dependencies
- ✅ Install Node dependencies  
- ✅ Build frontend
- ✅ Collect static files
- ✅ Run migrations
- ✅ Restart services

### Access Production:
- **Application**: https://kaymarine.com.au/crm/
- **Admin**: https://kaymarine.com.au/crm/admin/

---

## 📋 Deployment Checklist

Before deploying:

- [ ] Test all features locally
- [ ] Keep `db.sqlite3` in zip (preserves data)
- [ ] Keep `media/` folder in zip (preserves receipts)
- [ ] Remove `node_modules/` from zip
- [ ] Remove `.venv/` from zip

After deploying:

- [ ] Check service is running: `sudo supervisorctl status kaymarine_crm`
- [ ] Visit https://kaymarine.com.au/crm/
- [ ] Test login
- [ ] Test all major features

---

## 🔧 Troubleshooting

### Development (Windows):

**Frontend not loading?**
```bash
cd frontend
npm install
npm run dev
```

**Backend not starting?**
```bash
pip install -r requirements.txt
python manage.py runserver 8000
```

### Production (Server):

**Service not running?**
```bash
sudo supervisorctl restart kaymarine_crm
sudo supervisorctl status kaymarine_crm
```

**Check logs:**
```bash
tail -f /home/vinit/kaymarine_crm/logs/app.log
```

**Check Nginx:**
```bash
sudo nginx -t
sudo systemctl reload nginx
```

---

## 📝 Configuration Files

- **Frontend Config**: `frontend/src/config.ts`
- **Vite Config**: `frontend/vite.config.js`
- **Django Settings**: `server/settings.py` (dev)
- **Production Settings**: `server/settings_production.py` (prod)
- **Deployment Script**: `deploy_prod.sh`

---

## 🎯 How It Works

**Development:**
- Backend runs on port 8004
- Frontend runs on port 5173 with `/crm/` base path
- API calls go to `http://localhost:8004/api`

**Production:**
- Backend runs on port 8004 via Gunicorn
- Frontend is built and served by Nginx
- API calls go to `/crm/api` (routed by Nginx)
- Everything served at `https://kaymarine.com.au/crm/`

---

For detailed instructions, see `DEPLOYMENT_SUMMARY.md`

