from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('crm_app', '0010_landfillreceipt'),
    ]

    operations = [
        migrations.AddField(
            model_name='dischargeform',
            name='aa_storage',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='dischargeform',
            name='aa_storage_in_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name='dischargeform',
            name='aa_storage_out_at',
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]


