from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('crm_app', '0011_dischargeform_aa_storage_fields'),
    ]

    operations = [
        migrations.AddField(
            model_name='dischargeform',
            name='discharge_certificate_created',
            field=models.BooleanField(default=False),
        ),
    ]


