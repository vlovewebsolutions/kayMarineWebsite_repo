from django.core.management.base import BaseCommand
from django.db import transaction
from crm_app.models import DischargeForm, VesselPlan, LandfillReceipt


class Command(BaseCommand):
    help = 'Clear all data from the database for manual testing'

    def handle(self, *args, **options):
        self.stdout.write('🗑️  Clearing all data from database...')
        
        with transaction.atomic():
            # Clear all related data first (due to foreign key constraints)
            self.stdout.write('Clearing LandfillReceipt records...')
            LandfillReceipt.objects.all().delete()
            
            self.stdout.write('Clearing VesselPlan records...')
            VesselPlan.objects.all().delete()
            
            self.stdout.write('Clearing DischargeForm records...')
            DischargeForm.objects.all().delete()
            
        # Verify everything is cleared
        discharge_count = DischargeForm.objects.count()
        vessel_plan_count = VesselPlan.objects.count()
        receipt_count = LandfillReceipt.objects.count()
        
        self.stdout.write(f'\n✅ Database cleared successfully!')
        self.stdout.write(f'📊 Records remaining:')
        self.stdout.write(f'   - DischargeForm: {discharge_count}')
        self.stdout.write(f'   - VesselPlan: {vessel_plan_count}')
        self.stdout.write(f'   - LandfillReceipt: {receipt_count}')
        
        if discharge_count == 0 and vessel_plan_count == 0 and receipt_count == 0:
            self.stdout.write('\n🎉 SUCCESS: All data has been cleared!')
            self.stdout.write('🚀 You can now test all functionality manually:')
            self.stdout.write('   - Create new orders')
            self.stdout.write('   - Test boat user scheduling')
            self.stdout.write('   - Test Add More and Purchase Service buttons')
            self.stdout.write('   - Test Last 24h and Next 24h tabs')
            self.stdout.write('   - Test KPI functionality')
        else:
            self.stdout.write('\n❌ ERROR: Some data still remains!')
