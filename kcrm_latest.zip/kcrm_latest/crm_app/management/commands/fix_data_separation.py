from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from crm_app.models import DischargeForm


class Command(BaseCommand):
    help = 'Fix data by properly separating Last 24h and Next 24h orders'

    def handle(self, *args, **options):
        self.stdout.write('Fixing data separation...')
        
        # Clear all timestamps first
        DischargeForm.objects.all().update(
            actual_offload_at=None,
            scheduled_offload_at=None
        )
        
        now = timezone.now()
        orders = list(DischargeForm.objects.all())
        
        # LAST 24H ORDERS: Only set actual_offload_at (completed orders)
        last_24h_orders = orders[:3]
        for i, order in enumerate(last_24h_orders):
            hours_ago = [2, 8, 18][i]
            order.actual_offload_at = now - timedelta(hours=hours_ago)
            order.scheduled_offload_at = None  # Don't set scheduled for completed orders
            order.save()
            self.stdout.write(f'✅ {order.ship_name}: COMPLETED {hours_ago}h ago (actual only)')
        
        # NEXT 24H ORDERS: Only set scheduled_offload_at (upcoming orders)
        next_24h_orders = orders[3:6]
        for i, order in enumerate(next_24h_orders):
            hours_from_now = [4, 12, 20][i]
            order.scheduled_offload_at = now + timedelta(hours=hours_from_now)
            order.actual_offload_at = None  # Don't set actual for upcoming orders
            order.save()
            self.stdout.write(f'✅ {order.ship_name}: SCHEDULED in {hours_from_now}h (scheduled only)')
        
        # REMAINING ORDERS: No timestamps (historical)
        remaining_orders = orders[6:]
        for order in remaining_orders:
            order.actual_offload_at = None
            order.scheduled_offload_at = None
            order.save()
            self.stdout.write(f'✅ {order.ship_name}: HISTORICAL (no timestamps)')
        
        self.stdout.write('\n🔍 Verification:')
        
        # Check Last 24h
        last_24h_count = DischargeForm.objects.filter(
            actual_offload_at__gte=now - timedelta(hours=24),
            actual_offload_at__lte=now
        ).count()
        
        # Check Next 24h  
        next_24h_count = DischargeForm.objects.filter(
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        ).count()
        
        # Check for overlaps (should be 0)
        overlaps = DischargeForm.objects.filter(
            actual_offload_at__gte=now - timedelta(hours=24),
            actual_offload_at__lte=now,
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        ).count()
        
        self.stdout.write(f'📊 Last 24h orders: {last_24h_count}')
        self.stdout.write(f'📊 Next 24h orders: {next_24h_count}')
        self.stdout.write(f'📊 Overlapping orders: {overlaps}')
        
        if overlaps == 0:
            self.stdout.write('🎉 SUCCESS: No overlapping orders!')
        else:
            self.stdout.write(f'❌ ERROR: Still {overlaps} overlapping orders')
