import { UIComponents } from '../utils/ui';
import { apiBase } from '../config';
import { PDFGenerator } from './PDFGenerator';

export function openBoatChecklistModal(order: any) {
	const contingencyItems = [
		'Any spillages subject to biosecurity control from the vehicle must be reported immediately to 1800 020 504 and Supervisor.',
		'Any spillage inside the vehicle must be reported and cleaned under direction of an Accredited Person at the receiving AA site.',
		'Clean with recommended disinfectants and enter the name of the AA accredited person.',
	];

	const content = `
		<div class="space-y-6 text-sm">
			<h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Vessel Checklist</h2>
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
				<label>Ship Name: <input type="text" id="v_ship_name" value="${order.ship_name || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Flag: <input type="text" id="v_flag" value="${order.flag || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>IMO No: <input type="text" id="v_imo" value="${order.imo_no || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Berth: <input type="text" id="v_berth" value="${order.berth || ''}" class="border rounded px-2 py-1 w-full"></label>
			<label>Port: <input type="text" id="v_port" value="${order.port || ''}" class="border rounded px-2 py-1 w-full"></label>
			<label class="sm:col-span-2">Collection Date & Time: <input type="datetime-local" id="v_collection_time" value="${order.collecting_boat?.collection_time || ''}" class="border rounded px-2 py-1 w-full"></label>
		</div>
			<label>Total Volume: <input type="number" step="0.01" id="v_total" value="${order.total_volume || ''}" class="border rounded px-2 py-1 w-32"></label>
			<label>Master's Name & Signature: <input type="text" id="v_master" value="${order.vessel_checklist_meta?.master_signature || ''}" class="border rounded px-2 py-1 w-full"></label>

			<h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Collecting Boat Checklist</h2>
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
				<label>AA Accredited Person Name & Sign: <input type="text" id="c_aa_person" value="${order.collecting_boat?.accredited_person_1 || ''}" class="border rounded px-2 py-1 w-full" placeholder="Name & signature"></label>
				<label>Collecting Boat Name: <input type="text" id="c_boat" value="${order.collecting_boat?.boat_name || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>AA Accredited Person Name & Sign (2): <input type="text" id="c_aa_person2" value="${order.collecting_boat?.accredited_person_2 || ''}" class="border rounded px-2 py-1 w-full" placeholder="If second required"></label>
			<label>Truck Reg No: <input type="text" id="c_truck" value="${order.collecting_boat?.truck_reg || ''}" class="border rounded px-2 py-1 w-full"></label>
			<label class="sm:col-span-2">Disposal Date & Time at Landfill: <input type="datetime-local" id="c_disposal" value="${order.collecting_boat?.disposal_time || ''}" class="border rounded px-2 py-1 w-full"></label>
		</div>
			<div class="overflow-x-auto">
				<table class="min-w-full border border-gray-200">
					<thead class="bg-gray-50">
						<tr>
							<th class="px-2 py-1 text-left">No.</th>
							<th class="px-2 py-1 text-left">Checklist Item</th>
							<th class="px-2 py-1 text-left">Yes</th>
							<th class="px-2 py-1 text-left">No</th>
						</tr>
					</thead>
					<tbody>
						${(() => {
							const items = [
								{ label: 'Form 44 submitted', key: 'form44_submitted', isBoolean: true, value: order.form44_submitted },
								{ label: 'Clearance taken from Bio Security (Form 44)', key: 'bio_security_clearance' },
								{ label: 'Clearance taken from Customs (Form 44)', key: 'customs_clearance' },
								{ label: 'Verbal clearance taken on phone for Form 44', key: 'verbal_clearance' },
								{ label: 'Checklist for Accredited Person Completed', key: 'accredited_person_checklist' },
								{ label: 'Checklist for Driver Completed', key: 'driver_checklist' },
								{ label: 'Bio security inspector booked to witness disposal', key: 'bio_witness', isBoolean: true, value: order.bio_witness },
								{ label: 'Landfill booked for disposal', key: 'landfill_booked', isBoolean: true, value: order.landfill_booked }
							];
							return items.map((item, i) => {
								let checkedYes = false;
								let checkedNo = true;
								
								if (item.isBoolean) {
									checkedYes = item.value === true;
									checkedNo = item.value === false || item.value === null || item.value === undefined;
								} else {
									const savedValue = order.collecting_checklist?.[item.key] || '';
									checkedYes = savedValue === 'yes';
									checkedNo = savedValue === 'no' || (!savedValue);
								}
								
								return `
								<tr>
									<td class="px-2 py-1">${i + 1}</td>
									<td class="px-2 py-1">${item.label}</td>
									<td class="px-2 py-1"><input type="radio" name="chk_${item.key}" value="yes" ${checkedYes ? 'checked' : ''}></td>
									<td class="px-2 py-1"><input type="radio" name="chk_${item.key}" value="no" ${checkedNo ? 'checked' : ''}></td>
								</tr>`;
							}).join('');
						})()}
					</tbody>
				</table>
			</div>
			<div class="space-y-3">
				<h3 class="font-semibold">Send to Landfill within 48hrs</h3>
				<table class="min-w-full border border-gray-200">
					<thead class="bg-gray-50">
						<tr>
							<th class="px-2 py-1 text-left">No.</th>
							<th class="px-2 py-1 text-left">Item</th>
							<th class="px-2 py-1 text-left">Yes</th>
							<th class="px-2 py-1 text-left">No</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="px-2 py-1">1</td>
							<td class="px-2 py-1">Garbage staying in AA storage</td>
							<td class="px-2 py-1"><input type="radio" name="aa_storage" value="yes" ${order.aa_storage ? 'checked' : ''}></td>
							<td class="px-2 py-1"><input type="radio" name="aa_storage" value="no" ${order.aa_storage ? '' : 'checked'}></td>
						</tr>
						<tr id="aa_storage_times" class="${order.aa_storage ? '' : 'hidden'}">
							<td></td>
							<td class="px-2 py-1 text-right">In/Out Date & Time</td>
							<td colspan="2" class="px-2 py-1">
								<div class="flex flex-wrap gap-3 items-center">
									<input id="aa_in" type="datetime-local" value="${order.aa_storage_in_at ? new Date(order.aa_storage_in_at).toISOString().slice(0, 16) : ''}" class="border rounded px-2 py-1 w-full min-w-[220px]" placeholder="In at" />
									<input id="aa_out" type="datetime-local" value="${order.aa_storage_out_at ? new Date(order.aa_storage_out_at).toISOString().slice(0, 16) : ''}" class="border rounded px-2 py-1 w-full min-w-[220px]" placeholder="Out at" />
								</div>
							</td>
						</tr>
						<tr>
							<td class="px-2 py-1">2</td>
							<td class="px-2 py-1">Garbage staying less than 48 hrs</td>
							<td class="px-2 py-1">
								<input
									type="radio"
									name="staying_less_than_48"
									value="yes"
									${order.staying_less_than_48 === 'yes' ? 'checked' : ''}
								>
							</td>

							<td class="px-2 py-1">
								<input
									type="radio"
									name="staying_less_than_48"
									value="no"
									${order.staying_less_than_48 !== 'yes' ? 'checked' : ''}
								>
							</td>
						</tr>
						<tr>
							<td class="px-2 py-1">3</td>
							<td class="px-2 py-1">
								Garbage staying more than 48 hrs

								<div id="bio_permission_msg" class="text-red-600 text-xs mt-1 hidden">
									Take prior permission from Bio security department
								</div>
							</td>

							<td class="px-2 py-1">
								<input
									type="radio"
									name="staying_more_than_48"
									value="yes"
									${order.staying_more_than_48 === 'yes' ? 'checked' : ''}
								>
							</td>

							<td class="px-2 py-1">
								<input
									type="radio"
									name="staying_more_than_48"
									value="no"
									${order.staying_more_than_48 !== 'yes' ? 'checked' : ''}
								>
							</td>
						</tr>
						<tr>
							<td class="px-2 py-1">4</td>
							<td class="px-2 py-1">
								If garbage staying at storage for more than 48hrs, Permission taken from Bio security.

								<div class="mt-2">
									<div class="flex items-center gap-2">
										<input 
											type="text"
											id="reason_storage"
											value="${order.reason_storage ?? ''}"
											placeholder="Reason for storage"
											class="border rounded px-2 py-1 w-full"
											${order.reason_storage ? 'disabled' : ''}
										/>

										${order.reason_storage ? `
										<button 
											type="button"
											id="edit_reason_storage"
											class="px-2 py-1 text-xs bg-gray-200 rounded hover:bg-gray-300"
										>
											Edit
										</button>
										` : ''}

									</div>
								</div>
							</td>

							<td class="px-2 py-1">
								<input
									type="radio"
									name="perm_48"
									value="yes"
									${order.perm_48 === 'yes' ? 'checked' : ''}
								>
							</td>

							<td class="px-2 py-1">
								<input
									type="radio"
									name="perm_48"
									value="no"
									${order.perm_48 !== 'yes' ? 'checked' : ''}
								>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="p-3 rounded border bg-gray-50">
				<p class="font-medium mb-2">Contingency Plan</p>
				<ol class="list-decimal pl-5 space-y-1 text-gray-700">
					${contingencyItems.map((item) => `<li>${item}</li>`).join('')}
				</ol>
			</div>
		</div>
	`;

	const collectChecklistPayload = () => {
		const checklist: Record<string, string> = {};
		const checklistKeys = ['bio_security_clearance', 'customs_clearance', 'verbal_clearance', 'accredited_person_checklist', 'driver_checklist'];
		for (const key of checklistKeys) {
			const sel = document.querySelector(`input[name="chk_${key}"]:checked`) as HTMLInputElement | null;
			checklist[key] = sel?.value || '';
		}

		// Additional section values
		const aaYes = (document.querySelector('input[name="aa_storage"][value="yes"]') as HTMLInputElement | null)?.checked || false;
		const aaIn = (document.getElementById('aa_in') as HTMLInputElement | null)?.value || '';
		const aaOut = (document.getElementById('aa_out') as HTMLInputElement | null)?.value || '';

		// Boolean fields that are stored directly on the model, not in collecting_checklist
		const form44Submitted = (document.querySelector('input[name="chk_form44_submitted"]:checked') as HTMLInputElement | null)?.value === 'yes';
		const bioWitness = (document.querySelector('input[name="chk_bio_witness"]:checked') as HTMLInputElement | null)?.value === 'yes';
		const landfillBooked = (document.querySelector('input[name="chk_landfill_booked"]:checked') as HTMLInputElement | null)?.value === 'yes';

		const stayingLessThan48 =
			(document.querySelector('input[name="staying_less_than_48"]:checked') as HTMLInputElement | null)?.value || '';

		const stayingMoreThan48 =
			(document.querySelector('input[name="staying_more_than_48"]:checked') as HTMLInputElement | null)?.value || '';

		const permission48 =
			(document.querySelector('input[name="perm_48"]:checked') as HTMLInputElement | null)?.value || '';
		return {
			vessel_checklist_meta: {
				ship_name: (document.getElementById('v_ship_name') as HTMLInputElement | null)?.value || '',
				flag: (document.getElementById('v_flag') as HTMLInputElement | null)?.value || '',
				imo_no: (document.getElementById('v_imo') as HTMLInputElement | null)?.value || '',
				berth: (document.getElementById('v_berth') as HTMLInputElement | null)?.value || '',
				port: (document.getElementById('v_port') as HTMLInputElement | null)?.value || '',
				total_volume: parseFloat((document.getElementById('v_total') as HTMLInputElement | null)?.value || '0') || 0,
				master_signature: (document.getElementById('v_master') as HTMLInputElement | null)?.value || ''
			},
			collecting_boat: {
				accredited_person_1: (document.getElementById('c_aa_person') as HTMLInputElement | null)?.value || '',
				boat_name: (document.getElementById('c_boat') as HTMLInputElement | null)?.value || '',
				accredited_person_2: (document.getElementById('c_aa_person2') as HTMLInputElement | null)?.value || '',
				truck_reg: (document.getElementById('c_truck') as HTMLInputElement | null)?.value || '',
				disposal_time: (document.getElementById('c_disposal') as HTMLInputElement | null)?.value || '',
				collection_time: (document.getElementById('v_collection_time') as HTMLInputElement | null)?.value || ''
			},
			collecting_checklist: checklist,
			aa_storage: aaYes,
			aa_storage_in_at: aaIn || null,
			aa_storage_out_at: aaOut || null,
			reason_storage: (document.getElementById('reason_storage') as HTMLInputElement | null)?.value || '',
			staying_less_than_48: stayingLessThan48,
			staying_more_than_48: stayingMoreThan48,
			perm_48: permission48,
			form44_submitted: form44Submitted,
			bio_witness: bioWitness,
			landfill_booked: landfillBooked,
			contingency_plan: contingencyItems.join('\n')
		};
	};

	UIComponents.openModal(
		`Checklist - ${order.ship_name || ''}`,
		content,
		async () => {
			const payload = collectChecklistPayload();
			try {
				const res = await fetch(`${apiBase}/discharge-forms/${order.id}/`, {
					method: 'PATCH',
					headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('access')}` },
					body: JSON.stringify(payload)
				});

				if (!res.ok) {
					throw new Error(`HTTP ${res.status}`);
				}

				UIComponents.showAlert('Checklist updated successfully!', 'success');
			} catch (error) {
				console.error('Failed to save checklist:', error);
				UIComponents.showAlert('Failed to update checklist', 'error');
				throw error; // Re-throw to prevent auto-close
			}
		},
		'large',
		[
			{
				id: 'downloadBoatChecklistPdf',
				label: 'Download PDF',
				classes: 'px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700',
				onClick: async () => {
					const modalBodyEl = document.getElementById('modalBody') as HTMLElement | null;
					if (!modalBodyEl) throw new Error('Modal body not found');
					await PDFGenerator.downloadBoatChecklistFromModal(modalBodyEl, order?.ship_name || '');
					UIComponents.showAlert('Checklist PDF downloaded successfully!', 'success');
				}
			}
		]
	);

	const reasonInputEl = document.getElementById('reason_storage') as HTMLInputElement | null;

	if (reasonInputEl && order.reason_storage) {
		reasonInputEl.value = order.reason_storage;
		reasonInputEl.disabled = true;
	};

	const editBtn = document.getElementById('edit_reason_storage');

	editBtn?.addEventListener('click', () => {
		if (!reasonInputEl) return;

		reasonInputEl.disabled = false;
		reasonInputEl.focus();
	});

	// After modal render: wire AA storage toggle to show/hide times row
	const aaYesEl = document.querySelector('input[name="aa_storage"][value="yes"]') as HTMLInputElement | null;
	const aaNoEl = document.querySelector('input[name="aa_storage"][value="no"]') as HTMLInputElement | null;
	const timesRow = document.getElementById('aa_storage_times');
	const updateTimesVisibility = () => {
		if (!timesRow) return;
		const yes = !!aaYesEl?.checked;
		timesRow.classList.toggle('hidden', !yes);
	};
	aaYesEl?.addEventListener('change', updateTimesVisibility);
	aaNoEl?.addEventListener('change', updateTimesVisibility);
	updateTimesVisibility();
	// ------------------------------
	// Point 3 → controls Point 4 logic
	// ------------------------------

	const stayingMoreYes = document.querySelector(
		'input[name="staying_more_than_48"][value="yes"]'
	) as HTMLInputElement | null;

	const stayingMoreNo = document.querySelector(
		'input[name="staying_more_than_48"][value="no"]'
	) as HTMLInputElement | null;

	const permYes = document.querySelector(
		'input[name="perm_48"][value="yes"]'
	) as HTMLInputElement | null;

	const permNo = document.querySelector(
		'input[name="perm_48"][value="no"]'
	) as HTMLInputElement | null;

	const reasonInput = document.getElementById(
		'reason_storage'
	) as HTMLInputElement | null;

	const permissionMsg = document.getElementById(
		'bio_permission_msg'
	);

	const updatePermissionDependency = (manualChange = true) => {

		if (!stayingMoreYes || !stayingMoreNo) return;

		const isMoreThan48 = stayingMoreYes.checked;

		// ✅ Show message ONLY when Point 3 = YES
		if (permissionMsg) {
			permissionMsg.classList.toggle('hidden', !isMoreThan48);
		}

		if (!isMoreThan48) {

			// auto-select Point 4 = NO
			if (permNo) permNo.checked = true;

			// disable radios
			if (permYes) permYes.disabled = true;
			if (permNo) permNo.disabled = true;

			// disable input box
			if (reasonInput) {

				// clear only when user manually changes Point-3
				if (manualChange) {
					reasonInput.value = '';
				}

				reasonInput.disabled = true;
			}

		} else {

			// enable radios again
			if (permYes) permYes.disabled = false;
			if (permNo) permNo.disabled = false;

			// enable input again
			if (reasonInput) {
				reasonInput.disabled = false;
			}
		}
	};


	// listen changes on Point 3 radios
	stayingMoreYes?.addEventListener('change', () => updatePermissionDependency(true));
	stayingMoreNo?.addEventListener('change', () => updatePermissionDependency(true));

	// run once on modal open
	updatePermissionDependency(false);
}



