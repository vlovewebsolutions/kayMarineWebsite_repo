function renderBoatUserDashboard() {
  app.innerHTML = `
    <div class="min-h-dvh bg-gray-50">
      <header class="bg-white shadow-lg border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-20">
            <div class="flex items-center space-x-3">
              <img src="${import.meta.env.BASE_URL}logo.png" class="h-12 w-12 rounded-full border-2 border-blue-100" />
              <div>
                <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                <p class="text-sm text-gray-500">Boat Company View</p>
              </div>
            </div>
            <div class="flex items-center space-x-2">
              <button id="switchToAdminInterface" class="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors hidden" title="Switch to Admin Interface">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
                </svg>
                <span>Admin Interface</span>
              </button>
              <button id="logout" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">Logout</button>
            </div>
          </div>
        </div>
      </header>

      <div class="max-w-7xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow">
          <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6">
              <button id="boatOrdersTab" class="py-4 px-1 border-b-2 border-blue-500 font-medium text-blue-600">Orders</button>
              <button id="receiptsTab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Landfill Receipts</button>
            </nav>
          </div>
          <div id="boatOrdersView" class="p-6">
            <div class="mb-4">
              <div class="flex gap-2 flex-wrap">
                <button id="boatFilterAll" onclick="filterBoatOrders('all')" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">All Orders</button>
                <button id="boatFilterCompleted" onclick="filterBoatOrders('completed')" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Completed Jobs</button>
                <button id="boatFilterIncomplete" onclick="filterBoatOrders('incomplete')" class="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700">Incomplete Jobs</button>
              </div>
            </div>
            <div id="boatOrdersTable" class="overflow-x-auto"></div>
          </div>
          <div id="receiptsView" class="p-6 hidden">
            <div class="space-y-6">
              <!-- Upload Section -->
              <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Upload New Receipt</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <input id="receipt_date" type="date" class="border rounded px-3 py-2 w-full focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Upload Receipt</label>
                    <input id="receipt_file" type="file" class="border rounded px-3 py-2 w-full focus:ring-2 focus:ring-blue-500 focus:border-blue-500" accept="image/*,application/pdf">
              </div>
                  <div class="flex items-end">
                    <button id="uploadReceiptBtn" class="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">
                      📤 Upload Receipt
                    </button>
              </div>
                </div>
              </div>
              
              <!-- Filter Section -->
              <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center space-x-4">
                  <label class="flex items-center space-x-2 cursor-pointer">
                    <input type="checkbox" id="showAllReceipts" class="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                    <span class="text-sm font-medium text-gray-700">Show All Receipts</span>
                  </label>
                  <span class="text-xs text-gray-500">(Uncheck to filter by date)</span>
                </div>
              </div>
              
              <!-- Receipts List Section -->
              <div id="receiptsList" class="min-h-96"></div>
            </div>
          </div>
        </div>
      </div>
    </div>`;

  document.getElementById('logout')!.addEventListener('click', logout);
  
  // Interface switching button for boat dashboard
  const switchToAdminBtn = document.getElementById('switchToAdminInterface');
  if (switchToAdminBtn) {
    // Show button only if user is kayadmin
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      try {
        const user = JSON.parse(userStr);
        if (user.username === 'kayadmin') {
          switchToAdminBtn.classList.remove('hidden');
        }
      } catch (e) {
        console.error('Error parsing user data:', e);
      }
    }
    switchToAdminBtn.addEventListener('click', () => {
      setInterfacePreference('admin');
      render();
    });
  }
  
  loadBoatOrders();
  // Tabs
  document.getElementById('boatOrdersTab')!.addEventListener('click', () => switchBoatTab('orders'));
  document.getElementById('receiptsTab')!.addEventListener('click', () => switchBoatTab('receipts'));
  // Init receipts tab
  initReceiptsTab();
  // Wire up Additional button in boat view if present later
  const addBtn = document.getElementById('additionalDetails');
  if (addBtn) addBtn.addEventListener('click', openAdditionalDetailsModal);
}

async function loadBoatOrders() {
  const table = document.getElementById('boatOrdersTable')!;
  UIComponents.showLoadingSpinner(table, 'Loading orders...');
  try {
    const orders = await listOrders();
    // Store orders globally for filtering
    (window as any).allBoatOrders = orders;
    
    // Sort: jobs with ETB first (desc by ETB), then without ETB (desc by ETA)
    orders.sort(compareOrdersByEtbEta);
    
    // Render with filter buttons area
    table.innerHTML = `
      <div id="filteredBoatOrdersTable">
        ${renderBoatOrdersTable(orders)}
      </div>
    `;
    
    // Set default active button (All Orders)
    updateBoatFilterButtons('all');
  } catch (e: any) {
    table.innerHTML = `<div class="text-center text-red-600">Failed to load orders</div>`;
  }
}

// Filter orders by job status for Boat interface
(window as any).filterBoatOrders = function(status: string) {
  const allOrders = (window as any).allBoatOrders;
  if (!allOrders) return;
  
  let filteredOrders = allOrders;
  if (status === 'completed') {
    filteredOrders = allOrders.filter((order: any) => order.job_status === 'completed');
  } else if (status === 'incomplete') {
    filteredOrders = allOrders.filter((order: any) => order.job_status !== 'completed');
  }
  
  // Sort: jobs with ETB first (desc by ETB), then without ETB (desc by ETA)
  filteredOrders.sort(compareOrdersByEtbEta);
  
  const filteredTable = document.getElementById('filteredBoatOrdersTable');
  if (filteredTable) {
    filteredTable.innerHTML = renderBoatOrdersTable(filteredOrders);
  }
  
  // Update button styles
  updateBoatFilterButtons(status);
};

function updateBoatFilterButtons(activeStatus: string) {
  const buttons = ['boatFilterAll', 'boatFilterCompleted', 'boatFilterIncomplete'];
  buttons.forEach(buttonId => {
    const button = document.getElementById(buttonId);
    if (button) {
      // Remove all active styles
      button.classList.remove('bg-blue-600', 'bg-green-600', 'bg-orange-600', 'bg-gray-400', 'ring-2', 'ring-offset-2', 'ring-blue-500');
      
      if (buttonId === `boatFilter${activeStatus.charAt(0).toUpperCase() + activeStatus.slice(1)}` || (activeStatus === 'all' && buttonId === 'boatFilterAll')) {
        // Add active style
        if (activeStatus === 'all') {
          button.classList.add('bg-blue-600', 'ring-2', 'ring-offset-2', 'ring-blue-500');
        } else if (activeStatus === 'completed') {
          button.classList.add('bg-green-600', 'ring-2', 'ring-offset-2', 'ring-green-500');
        } else if (activeStatus === 'incomplete') {
          button.classList.add('bg-orange-600', 'ring-2', 'ring-offset-2', 'ring-orange-500');
        }
      } else {
        // Add inactive style
        button.classList.add('bg-gray-400');
      }
    }
  });
}

(window as any).boatOrderView = async (orderId: number) => {
  try {
    const freshOrder = await getOrder(orderId);

    console.log("Fresh API order:", freshOrder.reason_storage);

    openBoatChecklistModal(freshOrder);

  } catch (e: any) {
    UIComponents.showAlert('Failed to load order', 'error');
  }
};
import './index.css'
// dates used via components
import { compareOrdersByEtbEta } from './utils/sort'
import { formatDateTimeNoTZ } from './utils/dates'
import { UIComponents } from './utils/ui'
import { getOrder, listOrders, patchOrder, deleteOrderReq, uploadLandfillReceipt, getLandfillReceipts } from './services/orders'
import { openBoatChecklistModal } from './components/BoatChecklistModal'
import { renderAdminOrdersTable, renderBoatOrdersTable, setColumnVisibility } from './components/OrdersTable'
import { PDFGenerator } from './components/PDFGenerator'
import { generateDischargeCertificate } from './components/CertificateGenerator'
import { FormHandler } from './components/FormHandler'
import { areAllOperationsComplete, computeStageColor, colorToBadge, dot, selectOption, detailRow } from './utils/orderHelpers'
import { apiBase } from './config';

const app = document.querySelector<HTMLDivElement>('#app')!;
function switchBoatTab(tab: 'orders' | 'receipts') {
  const ordersView = document.getElementById('boatOrdersView')!;
  const receiptsView = document.getElementById('receiptsView')!;
  const ordersTab = document.getElementById('boatOrdersTab')!;
  const receiptsTab = document.getElementById('receiptsTab')!;
  if (tab === 'orders') {
    ordersView.classList.remove('hidden');
    receiptsView.classList.add('hidden');
    ordersTab.classList.add('border-blue-500', 'text-blue-600');
    ordersTab.classList.remove('border-transparent', 'text-gray-500');
    receiptsTab.classList.add('border-transparent', 'text-gray-500');
    receiptsTab.classList.remove('border-blue-500', 'text-blue-600');
  } else {
    receiptsView.classList.remove('hidden');
    ordersView.classList.add('hidden');
    receiptsTab.classList.add('border-blue-500', 'text-blue-600');
    receiptsTab.classList.remove('border-transparent', 'text-gray-500');
    ordersTab.classList.add('border-transparent', 'text-gray-500');
    ordersTab.classList.remove('border-blue-500', 'text-blue-600');
  }
}

async function initReceiptsTab() {
  try {
    const dateInput = document.getElementById('receipt_date') as HTMLInputElement;
    const showAllCheckbox = document.getElementById('showAllReceipts') as HTMLInputElement;
    const listDiv = document.getElementById('receiptsList')!;
    
    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
    
    // Handle show all checkbox change
    showAllCheckbox.addEventListener('change', () => {
      dateInput.disabled = showAllCheckbox.checked;
      if (showAllCheckbox.checked) {
        dateInput.classList.add('bg-gray-100', 'cursor-not-allowed');
      } else {
        dateInput.classList.remove('bg-gray-100', 'cursor-not-allowed');
      }
      refreshList();
    });
    
    const refreshList = async () => {
      const showAll = showAllCheckbox.checked;
      const selectedDate = dateInput.value;
      
      if (!showAll && !selectedDate) { 
        listDiv.innerHTML = '<p class="text-sm text-gray-500">Please select a date to view receipts or check "Show All Receipts".</p>'; 
        return; 
      }
      
      try {
        // Fetch all landfill receipts (both independent and order-related)
        const allLandfillReceipts = showAll 
          ? await getLandfillReceipts() // Fetch all receipts
          : await getLandfillReceipts(selectedDate); // Fetch receipts for selected date
        
        // Collect all receipts
        const allReceipts: any[] = [];
        
        if (allLandfillReceipts && allLandfillReceipts.length > 0) {
          allLandfillReceipts.forEach((receipt: any, index: number) => {
            if (receipt.discharge_form) {
              // Receipt linked to an order - discharge_form could be an ID or object
              const orderId = typeof receipt.discharge_form === 'object' 
                ? receipt.discharge_form.id 
                : receipt.discharge_form;
              allReceipts.push({
                ...receipt,
                orderId: orderId,
                shipName: typeof receipt.discharge_form === 'object' 
                  ? (receipt.discharge_form.ship_name || 'Unknown')
                  : 'Unknown',
                berth: typeof receipt.discharge_form === 'object' 
                  ? (receipt.discharge_form.berth || 'N/A')
                  : 'N/A',
                port: typeof receipt.discharge_form === 'object' 
                  ? (receipt.discharge_form.port || 'N/A')
                  : 'N/A',
                totalVolume: typeof receipt.discharge_form === 'object' 
                  ? (receipt.discharge_form.total_volume || 'N/A')
                  : 'N/A',
                receiptNumber: index + 1,
                type: 'order',
                orderDate: typeof receipt.discharge_form === 'object' 
                  ? (receipt.discharge_form.date || receipt.date)
                  : receipt.date
              });
            } else {
              // Independent receipt (no order)
              allReceipts.push({
                ...receipt,
                orderId: null,
                shipName: 'Independent Work',
                berth: 'N/A',
                port: 'N/A',
                totalVolume: 'N/A',
                receiptNumber: index + 1,
                type: 'independent'
              });
            }
          });
        }
        
        if (allReceipts.length === 0) {
          const dateText = showAll ? 'all dates' : new Date(selectedDate).toLocaleDateString();
          listDiv.innerHTML = `
            <div class="text-center py-8">
              <div class="text-gray-400 text-4xl mb-2">📄</div>
              <h3 class="text-lg font-medium text-gray-900 mb-1">No Receipts Found</h3>
              <p class="text-gray-500">No landfill receipts have been uploaded${showAll ? '' : ` for ${dateText}`}.</p>
            </div>
          `;
          return;
        }
      
        // Sort receipts by uploaded_at descending (newest first)
        allReceipts.sort((a, b) => {
          const dateA = new Date(a.uploaded_at).getTime();
          const dateB = new Date(b.uploaded_at).getTime();
          return dateB - dateA;
        });
      
        // Create table with all receipts
        const dateText = showAll ? 'All Receipts' : `Landfill Receipts for ${new Date(selectedDate).toLocaleDateString()}`;
        const receiptsTable = `
          <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
              <h3 class="text-lg font-medium text-gray-900">
                ${dateText}
              </h3>
              <p class="text-sm text-gray-500 mt-1">${allReceipts.length} receipt${allReceipts.length !== 1 ? 's' : ''} found</p>
            </div>
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Receipt #</th>
                    ${showAll ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>' : ''}
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Uploaded At</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  ${allReceipts.map((receipt: any, index: number) => `
                    <tr class="hover:bg-gray-50">
                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        #${index + 1}
                      </td>
                      ${showAll ? `
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${receipt.type === 'independent' ? new Date(receipt.date).toLocaleDateString() : new Date(receipt.orderDate || receipt.date).toLocaleDateString()}
                      </td>
                      ` : ''}
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${new Date(receipt.uploaded_at).toLocaleString()}
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div class="flex space-x-2">
                          <button onclick="downloadReceipt('${receipt.file}', '${receipt.type === 'independent' ? 'Independent' : receipt.shipName}_${receipt.type === 'independent' ? 'Receipt' : 'Job' + receipt.orderId}_Receipt${receipt.receiptNumber}')" 
                                  class="text-blue-600 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-3 py-1 rounded-md text-xs font-medium transition-colors">
                            📥 Download
                          </button>
                          <button onclick="viewReceipt('${receipt.file}')" 
                                  class="text-green-600 hover:text-green-900 bg-green-50 hover:bg-green-100 px-3 py-1 rounded-md text-xs font-medium transition-colors">
                            👁️ View
                          </button>
                        </div>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        `;
        
        listDiv.innerHTML = receiptsTable;
      } catch (error) {
        console.error('Error fetching receipts:', error);
        const dateText = showAllCheckbox.checked ? 'all receipts' : `for ${new Date(selectedDate).toLocaleDateString()}`;
        listDiv.innerHTML = `
          <div class="text-center py-8">
            <div class="text-red-400 text-4xl mb-2">⚠️</div>
            <h3 class="text-lg font-medium text-gray-900 mb-1">Error Loading Receipts</h3>
            <p class="text-gray-500">Failed to load receipts ${dateText}.</p>
          </div>
        `;
      }
    };
    
    dateInput.onchange = () => {
      if (!showAllCheckbox.checked) {
        refreshList();
      }
    };
    showAllCheckbox.addEventListener('change', refreshList);
    await refreshList();
    
    document.getElementById('uploadReceiptBtn')!.addEventListener('click', async () => {
      const fileEl = document.getElementById('receipt_file') as HTMLInputElement;
      const file = fileEl.files && fileEl.files[0];
      if (!file) { 
        UIComponents.showAlert('Please choose a file to upload', 'error'); 
        return; 
      }
      
      const selectedDate = dateInput.value;
      if (!selectedDate) {
        UIComponents.showAlert('Please select a date first', 'error');
        return;
      }
      
      try {
        // Upload receipt independently without order association
        await uploadLandfillReceipt(selectedDate, file);
        UIComponents.showAlert('Receipt uploaded successfully', 'success');
        
        // Refresh the list to show the new receipt
        await refreshList();
        fileEl.value = '';
      } catch (e: any) {
        UIComponents.showAlert('Failed to upload receipt', 'error');
      }
    });
  } catch (e: any) {
    console.error(e);
  }
}

// Global functions for receipt actions
(window as any).downloadReceipt = function(fileUrl: string, fileName: string) {
  try {
    // Create a temporary link element to trigger download
    const link = document.createElement('a');
    link.href = fileUrl;
    link.download = fileName;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    UIComponents.showAlert('Receipt download started', 'success');
  } catch (error) {
    console.error('Download failed:', error);
    UIComponents.showAlert('Failed to download receipt', 'error');
  }
};

(window as any).viewReceipt = function(fileUrl: string) {
  try {
    // Open receipt in new tab for viewing
    window.open(fileUrl, '_blank');
  } catch (error) {
    console.error('View failed:', error);
    UIComponents.showAlert('Failed to open receipt', 'error');
  }
};

(window as any).toggleIncidentUpload = function(orderId: number) {
  const checkbox = document.getElementById('incident_occurred') as HTMLInputElement;
  const uploadSection = document.getElementById(`incidentUploadSection_${orderId}`);
  if (checkbox && uploadSection) {
    if (checkbox.checked) {
      uploadSection.classList.remove('hidden');
    } else {
      uploadSection.classList.add('hidden');
      // Clear file input when hiding
      const fileInput = document.getElementById(`incident_file_${orderId}`) as HTMLInputElement;
      if (fileInput) {
        fileInput.value = '';
        const fileNameDisplay = document.getElementById(`incident_file_name_${orderId}`);
        if (fileNameDisplay) {
          fileNameDisplay.textContent = 'Click to choose file or drag and drop';
        }
      }
    }
  }
};

(window as any).updateIncidentFileName = function(orderId: number) {
  const fileInput = document.getElementById(`incident_file_${orderId}`) as HTMLInputElement;
  const fileNameDisplay = document.getElementById(`incident_file_name_${orderId}`);
  if (fileInput && fileNameDisplay && fileInput.files && fileInput.files.length > 0) {
    const fileName = fileInput.files[0].name;
    const fileSize = (fileInput.files[0].size / 1024 / 1024).toFixed(2); // Size in MB
    fileNameDisplay.textContent = `${fileName} (${fileSize} MB)`;
    fileNameDisplay.classList.remove('text-gray-500');
    fileNameDisplay.classList.add('text-gray-900', 'font-medium');
  }
};

(window as any).uploadIncidentDocument = async function(orderId: number) {
  const fileInput = document.getElementById(`incident_file_${orderId}`) as HTMLInputElement;
  const file = fileInput?.files?.[0];
  
  if (!file) {
    UIComponents.showAlert('Please select a file to upload', 'error');
    return;
  }
  
  try {
    const { uploadIncidentDocument, getOrder } = await import('./services/orders');
    await uploadIncidentDocument(orderId, file);
    
    // Refresh the order to get updated incident documents
    const order = await getOrder(orderId);
    
    // Update the incident documents display
    await refreshIncidentDocuments(orderId, order);
    
    // Reset file input and display
    const fileNameDisplay = document.getElementById(`incident_file_name_${orderId}`);
    if (fileInput) fileInput.value = '';
    if (fileNameDisplay) {
      fileNameDisplay.textContent = 'Click to choose file or drag and drop';
      fileNameDisplay.classList.remove('text-gray-900', 'font-medium');
      fileNameDisplay.classList.add('text-gray-500');
    }
    
    UIComponents.showAlert('Incident document uploaded successfully', 'success');
  } catch (error: any) {
    console.error('Upload failed:', error);
    UIComponents.showAlert('Failed to upload incident document', 'error');
  }
};

async function refreshIncidentDocuments(orderId: number, order: any) {
  const docsContainer = document.getElementById(`incidentDocuments_${orderId}`);
  if (docsContainer && order.incident_documents) {
    docsContainer.innerHTML = order.incident_documents.length > 0 
      ? order.incident_documents.map((doc: any) => `
          <div class="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200 hover:border-red-300 hover:shadow-sm transition-all">
            <div class="flex items-center gap-3 flex-1 min-w-0">
              <div class="flex-shrink-0 w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
              </div>
              <div class="flex-1 min-w-0">
                <a href="${doc.file}" target="_blank" class="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline truncate block">
                  ${doc.file.split('/').pop()}
                </a>
                <p class="text-xs text-gray-500 mt-0.5">
                  Uploaded by ${doc.uploaded_by_username || 'Admin'} • ${new Date(doc.uploaded_at).toLocaleString()}
                </p>
              </div>
            </div>
            <div class="flex items-center gap-2 ml-3">
              <a href="${doc.file}" target="_blank" class="px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors flex items-center gap-1 whitespace-nowrap">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                </svg>
                View
              </a>
              <button onclick="deleteIncidentDocument(${orderId}, ${doc.id})" class="px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors flex items-center gap-1 whitespace-nowrap" title="Delete document">
                <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                </svg>
                Delete
              </button>
            </div>
          </div>
        `).join('')
      : `
        <div class="p-4 bg-gray-50 rounded-lg border border-dashed border-gray-300 text-center">
          <svg class="w-8 h-8 text-gray-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
          </svg>
          <p class="text-sm text-gray-500">No documents uploaded yet</p>
          <p class="text-xs text-gray-400 mt-1">Upload a document to track this incident</p>
        </div>
      `;
    
    // Update the document count in the header
    const docCount = order.incident_documents?.length || 0;
    const headerElement = docsContainer?.previousElementSibling?.querySelector('h5');
    if (headerElement) {
      headerElement.innerHTML = `
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
        </svg>
        Uploaded Documents (${docCount})
      `;
    }
  }
}

(window as any).deleteIncidentDocument = async function(orderId: number, documentId: number) {
  if (!confirm('Are you sure you want to delete this incident document? This action cannot be undone.')) {
    return;
  }
  
  try {
    const { deleteIncidentDocument, getOrder } = await import('./services/orders');
    await deleteIncidentDocument(documentId);
    
    // Refresh the order to get updated incident documents
    const order = await getOrder(orderId);
    
    // Update the incident documents display
    await refreshIncidentDocuments(orderId, order);
    
    UIComponents.showAlert('Incident document deleted successfully', 'success');
  } catch (error: any) {
    console.error('Delete failed:', error);
    UIComponents.showAlert('Failed to delete incident document', 'error');
  }
};

// Component-based approach for DRY practice
// Moved to utils/ui.ts

// moved to components/BoatChecklistModal.ts
/* function openBoatChecklistModal(order: any) {
  const vesselRows = [
    'Cat A. Plastic','Cat B. Food Waste','Cat C. Domestic Waste','Cat D. Cooking Oil (N/A)',
    'Cat E. Incinerator Ashes','Cat F. Operational Waste','Cat. G Animal carcass(es)','Cat. H Fishing gear',
    'Cat. I E-waste (No Batteries)','Cat. J Cargo residues (non-Harmful to the Marine Environment)'
  ].map((label, idx) => `
    <tr>
      <td>${idx + 1}</td>
      <td>${label}</td>
      <td><input type="number" step="0.01" id="v_qty_${idx}" class="border rounded px-2 py-1 w-full"></td>
      <td><input type="text" id="v_org_${idx}" class="border rounded px-2 py-1 w-full"></td>
    </tr>
  `).join('');

  const content = `
    <div class="space-y-6 text-sm">
      <h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Vessel Checklist</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label>Ship Name: <input type="text" id="v_ship_name" value="${order.ship_name || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Flag: <input type="text" id="v_flag" value="${order.flag || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>IMO No: <input type="text" id="v_imo" value="${order.imo_no || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Berth: <input type="text" id="v_berth" value="${order.berth || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Port: <input type="text" id="v_port" value="${order.port || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Date: <input type="date" id="v_date" value="${formatDateInput(order.date)}" class="border rounded px-2 py-1 w-full"></label>
        <label>Time: <input type="time" id="v_time" value="${formatTimeInput(order.time)}" class="border rounded px-2 py-1 w-full"></label>
        </div>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-2 py-1 text-left">No.</th>
              <th class="px-2 py-1 text-left">Garbage Category</th>
              <th class="px-2 py-1 text-left">Quantity (m³)</th>
              <th class="px-2 py-1 text-left">Origin</th>
            </tr>
          </thead>
          <tbody>
            ${vesselRows}
          </tbody>
        </table>
        </div>
      <label>Total Volume: <input type="number" step="0.01" id="v_total" value="${order.total_volume || ''}" class="border rounded px-2 py-1 w-32"></label>
      <label>Master's Name & Signature: <input type="text" id="v_master" class="border rounded px-2 py-1 w-full"></label>

      <h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Collecting Boat Checklist</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label>Collecting Boat Name: <input type="text" id="c_boat" class="border rounded px-2 py-1 w-full"></label>
        <label>Truck Reg No: <input type="text" id="c_truck" class="border rounded px-2 py-1 w-full"></label>
        <label class="sm:col-span-2">Disposal Date & Time: <input type="datetime-local" id="c_disposal" class="border rounded px-2 py-1 w-full"></label>
        </div>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-2 py-1 text-left">No.</th>
              <th class="px-2 py-1 text-left">Checklist Item</th>
              <th class="px-2 py-1 text-left">Yes</th>
              <th class="px-2 py-1 text-left">No</th>
            </tr>
          </thead>
          <tbody>
            ${[ 
              'Clearance taken from Bio Security (Form 44)',
              'Clearance taken from Customs (Form 44)',
              'Verbal clearance taken on phone for Form 44',
              'Checklist for Accredited Person Completed',
              'Checklist for Driver Completed'
            ].map((item, i) => `
              <tr>
                <td class="px-2 py-1">${i + 1}</td>
                <td class="px-2 py-1">${item}</td>
                <td class="px-2 py-1"><input type="radio" name="chk_${i}" value="yes"></td>
                <td class="px-2 py-1"><input type="radio" name="chk_${i}" value="no"></td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <label>Contingency Plan: <textarea id="c_contingency" rows="3" class="border rounded px-2 py-1 w-full"></textarea></label>
      </div>
    `;

  UIComponents.openModal(`Checklist - ${order.ship_name || ''}`, content, async () => {
    // Collect a minimal placeholder payload
    const checklist: Record<string, string> = {};
    for (let i = 0; i < 5; i++) {
      const sel = document.querySelector(`input[name="chk_${i}"]:checked`) as HTMLInputElement | null;
      checklist[`item_${i + 1}`] = sel?.value || '';
    }
    const payload = {
      vessel_checklist_meta: {
        ship_name: (document.getElementById('v_ship_name') as HTMLInputElement | null)?.value || '',
        flag: (document.getElementById('v_flag') as HTMLInputElement | null)?.value || '',
        imo_no: (document.getElementById('v_imo') as HTMLInputElement | null)?.value || '',
        berth: (document.getElementById('v_berth') as HTMLInputElement | null)?.value || '',
        port: (document.getElementById('v_port') as HTMLInputElement | null)?.value || '',
        date: (document.getElementById('v_date') as HTMLInputElement | null)?.value || '',
        time: (document.getElementById('v_time') as HTMLInputElement | null)?.value || '',
        total_volume: parseFloat((document.getElementById('v_total') as HTMLInputElement | null)?.value || '0') || 0,
        master_signature: (document.getElementById('v_master') as HTMLInputElement | null)?.value || ''
      },
      vessel_checklist_rows: Array.from({ length: 10 }).map((_, idx) => ({
        no: idx + 1,
        quantity_m3: parseFloat((document.getElementById(`v_qty_${idx}`) as HTMLInputElement | null)?.value || '0') || 0,
        origin: (document.getElementById(`v_org_${idx}`) as HTMLInputElement | null)?.value || ''
      })),
      collecting_boat: {
        boat_name: (document.getElementById('c_boat') as HTMLInputElement | null)?.value || '',
        truck_reg: (document.getElementById('c_truck') as HTMLInputElement | null)?.value || '',
        disposal_time: (document.getElementById('c_disposal') as HTMLInputElement | null)?.value || ''
      },
      collecting_checklist: checklist,
      contingency_plan: (document.getElementById('c_contingency') as HTMLTextAreaElement | null)?.value || ''
    };
    // Placeholder PATCH; adjust endpoint/keys as needed later
    await patchOrder(order.id, payload);
  });
} */

// PDFGenerator moved to components/PDFGenerator.ts

// FormHandler moved to components/FormHandler.ts

function render() {
  const access = localStorage.getItem('access');
  console.log('Access token exists:', !!access);
  console.log('Access token value:', access ? access.substring(0, 20) + '...' : 'null');
  if (access) {
    // Add a small delay to ensure tokens are properly stored
    setTimeout(async () => {
    // Get user info first
    const user = await getCurrentUser();
    if (!user) {
      renderLoginForm();
      return;
    }
    
    const isAdmin = user.is_staff || user.is_superuser;
    const kayAdmin = user.username === 'kayadmin';
    const interfacePref = getInterfacePreference();
    
    console.log('User is admin:', isAdmin, 'Is kayadmin:', kayAdmin);
    
    // If user is kayadmin, respect their interface preference
    // Otherwise, show admin if isAdmin, boat if not
    if (kayAdmin) {
      if (interfacePref === 'boat') {
        renderBoatUserDashboard();
      } else {
        renderAdminDashboard();
      }
    } else {
      // Regular users: show admin if isAdmin, boat if not
      if (isAdmin) {
        renderAdminDashboard();
      } else {
        renderBoatUserDashboard();
      }
    }
    }, 100);
  } else {
    renderLoginForm();
  }
}

function openAdditionalDetailsModal() {
  const placeholder = `
    <div class="space-y-4">
      <p class="text-sm text-gray-600">Additional details form will appear here.</p>
      <p class="text-sm text-gray-500">This modal is for future use. The vessel plan table is now available in the collapsible Additional Details section.</p>
    </div>`;

  UIComponents.openModal('Additional Details', placeholder, () => {
    console.log('Additional details modal opened');
  });
}

async function getCurrentUser(): Promise<any> {
  try {
    const access = localStorage.getItem('access');
    if (!access) return null;
    
    const res = await fetch(`${apiBase}/auth/me/`, {
      headers: { 'Authorization': `Bearer ${access}` }
    });
    
    if (res.ok) {
      const user = await res.json();
      // Store user info in localStorage for quick access
      localStorage.setItem('currentUser', JSON.stringify(user));
      return user;
    }
  } catch (error) {
    console.error('Error getting user:', error);
  }
  return null;
}

async function checkUserRole(): Promise<boolean> {
  const user = await getCurrentUser();
  if (user) {
    return user.is_staff || user.is_superuser;
  }
  return false;
}

function getInterfacePreference(): 'admin' | 'boat' {
  const preference = localStorage.getItem('interfacePreference');
  if (preference === 'boat' || preference === 'admin') {
    return preference;
  }
  return 'admin'; // Default to admin
}

function setInterfacePreference(preference: 'admin' | 'boat') {
  localStorage.setItem('interfacePreference', preference);
}

function renderAdminDashboard() {
    app.innerHTML = `
    <div class="min-h-dvh bg-gray-50">
      <!-- Enhanced Header -->
      <header class="bg-white shadow-md border-b border-gray-200 sticky top-0 z-50 backdrop-blur-sm bg-white/95">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-20">
            <!-- Logo and Brand -->
            <div class="flex items-center space-x-4">
              <div class="flex items-center space-x-3">
                <img src="${import.meta.env.BASE_URL}logo.png" alt="Kay Marine" class="h-14 w-14 object-contain rounded-full shadow-sm border-2 border-blue-100" />
                <div>
                  <h1 class="text-2xl font-bold text-gray-900 tracking-tight">Kay Marine CRM</h1>
                  <p class="text-sm text-gray-600 font-medium">Admin Dashboard</p>
                </div>
              </div>
            </div>
            
            <!-- User Info and Actions -->
            <div class="flex items-center space-x-4">
              <div class="hidden sm:block text-right">
                <p class="text-sm font-medium text-gray-900">Welcome, Admin</p>
                <p class="text-xs text-gray-500">System Administrator</p>
              </div>
              <div class="flex items-center space-x-2">
                <button id="switchToBoatInterface" class="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-sm hidden" title="Switch to Boat Interface">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"></path>
                  </svg>
                  <span class="hidden sm:inline">Boat Interface</span>
                </button>
                <button id="refreshOrders" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Refresh Orders">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                  </svg>
                </button>
                <button id="logout" class="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors shadow-sm btn-enhanced">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                  </svg>
                  <span class="hidden sm:inline">Logout</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Main Content -->
      <div class="max-w-7xl mx-auto p-6">

        <!-- Navigation Tabs -->
        <div class="bg-white rounded-xl shadow-sm border border-gray-200 mb-6 overflow-hidden">
          <div class="border-b border-gray-200 bg-gray-50/50">
            <nav class="flex space-x-1 px-2">
              <button id="ordersTab" class="py-4 px-6 border-b-2 border-blue-600 font-semibold text-blue-600 text-sm transition-colors">Orders List</button>
              <button id="createTab" class="py-4 px-6 border-b-2 border-transparent font-medium text-gray-600 hover:text-gray-900 hover:border-gray-300 text-sm transition-colors">Create Order</button>
              <button id="last24Tab" class="py-4 px-6 border-b-2 border-transparent font-medium text-gray-600 hover:text-gray-900 hover:border-gray-300 text-sm transition-colors">Last 24 Hours</button>
              <button id="next24Tab" class="py-4 px-6 border-b-2 border-transparent font-medium text-gray-600 hover:text-gray-900 hover:border-gray-300 text-sm transition-colors">Next 24 Hours</button>
              <button id="kpiTab" class="py-4 px-6 border-b-2 border-transparent font-medium text-gray-600 hover:text-gray-900 hover:border-gray-300 text-sm transition-colors">Reports</button>
            </nav>
          </div>
        </div>

        <!-- KPI View (Hidden by default) -->
        <div id="kpiView" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center mb-4">
              <h2 class="text-xl font-semibold text-gray-900">Key Performance Indicators</h2>
              <button id="refreshKpi" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
            </div>
            <div class="flex flex-wrap items-center gap-4">
              <div class="flex items-center gap-2">
                <label for="kpiStartDate" class="text-sm font-medium text-gray-700">From:</label>
                <input type="date" id="kpiStartDate" class="border rounded px-3 py-2 text-sm">
              </div>
              <div class="flex items-center gap-2">
                <label for="kpiEndDate" class="text-sm font-medium text-gray-700">To:</label>
                <input type="date" id="kpiEndDate" class="border rounded px-3 py-2 text-sm">
              </div>
              <button id="applyKpiDateRange" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 text-sm">Apply Filter</button>
              <button id="clearKpiDateRange" class="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 text-sm">Clear</button>
            </div>
          </div>
          <div class="p-6">
            <div id="kpiContainer" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              <!-- KPI cards and charts will render here -->
            </div>
          </div>
        </div>

        <!-- Orders List View -->
        <div id="ordersView" class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div class="px-6 py-5 border-b border-gray-200 bg-gray-50/30">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900 tracking-tight">Discharge Orders</h2>
              <div class="flex items-center space-x-3">
                <button id="downloadBlankForm" class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <span>Download Blank Form</span>
                </button>
                <button id="refreshOrders" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="ordersTable" class="overflow-x-auto">
              <div class="flex justify-center items-center h-32">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span class="ml-2 text-gray-600">Loading orders...</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Last 24 Hours View (Hidden by default) -->
        <div id="last24View" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Completed in Last 24 Hours</h2>
              <div class="flex items-center space-x-3">
                <button id="refreshLast24" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="last24Table" class="overflow-x-auto"></div>
          </div>
        </div>

        <!-- Next 24 Hours View (Hidden by default) -->
        <div id="next24View" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Scheduled in Next 24 Hours</h2>
              <div class="flex items-center space-x-3">
                <button id="refreshNext24" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="next24Table" class="overflow-x-auto"></div>
          </div>
        </div>

        <!-- Create Order View (Hidden by default) -->
        <div id="createView" class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hidden">
          <div class="px-6 py-5 border-b border-gray-200 bg-gray-50/30">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900 tracking-tight">Create New Discharge Order</h2>
              <div class="flex items-center space-x-3">
                <button id="downloadBlankFormCreate" class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <span>Download Blank</span>
                </button>
              </div>
            </div>
          </div>
          <div class="p-6">
            ${getDischargeFormHTML()}
          </div>
        </div>

        <!-- Service Purchase View removed; now part of Create Order collapsible -->
      </div>
    </div>`;

  // Add event listeners
  const logoutBtn = document.getElementById('logout');
  if (logoutBtn) logoutBtn.addEventListener('click', logout);
  
  // Interface switching buttons
  const switchToBoatBtn = document.getElementById('switchToBoatInterface');
  if (switchToBoatBtn) {
    // Show button only if user is kayadmin
    const userStr = localStorage.getItem('currentUser');
    if (userStr) {
      try {
        const user = JSON.parse(userStr);
        if (user.username === 'kayadmin') {
          switchToBoatBtn.classList.remove('hidden');
        }
      } catch (e) {
        console.error('Error parsing user data:', e);
      }
    }
    switchToBoatBtn.addEventListener('click', () => {
      setInterfacePreference('boat');
      render();
    });
  }
  
  const ordersTab = document.getElementById('ordersTab');
  if (ordersTab) ordersTab.addEventListener('click', () => switchTab('orders'));
  
  const createTab = document.getElementById('createTab');
  if (createTab) createTab.addEventListener('click', () => switchTab('create'));
  
  const last24Tab = document.getElementById('last24Tab');
  if (last24Tab) last24Tab.addEventListener('click', () => switchTab('last24'));
  
  const next24Tab = document.getElementById('next24Tab');
  if (next24Tab) next24Tab.addEventListener('click', () => switchTab('next24'));
  
  const refreshOrdersBtn = document.getElementById('refreshOrders');
  if (refreshOrdersBtn) refreshOrdersBtn.addEventListener('click', loadOrders);
  
  const refreshLast24Btn = document.getElementById('refreshLast24');
  if (refreshLast24Btn) refreshLast24Btn.addEventListener('click', loadLast24);
  
  const refreshNext24Btn = document.getElementById('refreshNext24');
  if (refreshNext24Btn) refreshNext24Btn.addEventListener('click', loadNext24);
  
  const kpiTab = document.getElementById('kpiTab');
  if (kpiTab) kpiTab.addEventListener('click', () => switchTab('kpi'));
  
  const refreshKpiBtn = document.getElementById('refreshKpi');
  if (refreshKpiBtn) refreshKpiBtn.addEventListener('click', loadKpi);
  
  // Date range filter for KPI
  const applyKpiDateRangeBtn = document.getElementById('applyKpiDateRange');
  if (applyKpiDateRangeBtn) {
    applyKpiDateRangeBtn.addEventListener('click', () => {
      loadKpi();
    });
  }
  
  const clearKpiDateRangeBtn = document.getElementById('clearKpiDateRange');
  if (clearKpiDateRangeBtn) {
    clearKpiDateRangeBtn.addEventListener('click', () => {
      const startDateInput = document.getElementById('kpiStartDate') as HTMLInputElement;
      const endDateInput = document.getElementById('kpiEndDate') as HTMLInputElement;
      if (startDateInput) startDateInput.value = '';
      if (endDateInput) endDateInput.value = '';
      loadKpi();
    });
  }
  
  // PDF download event listeners
  const downloadBlankFormBtn = document.getElementById('downloadBlankForm');
  if (downloadBlankFormBtn) {
    downloadBlankFormBtn.addEventListener('click', async () => {
      await PDFGenerator.downloadBlankForm();
    UIComponents.showAlert('Blank discharge form downloaded successfully!', 'success');
  });
  }
  
  const downloadBlankFormCreateBtn = document.getElementById('downloadBlankFormCreate');
  if (downloadBlankFormCreateBtn) {
    downloadBlankFormCreateBtn.addEventListener('click', async () => {
      await PDFGenerator.downloadBlankForm();
    UIComponents.showAlert('Blank discharge form downloaded successfully!', 'success');
  });
  }
  
  const downloadFilledFormBtn = document.getElementById('downloadFilledForm');
  if (downloadFilledFormBtn) {
    downloadFilledFormBtn.addEventListener('click', async () => {
    const formData = FormHandler.collectFormData();
      await PDFGenerator.downloadFilledForm(formData);
    UIComponents.showAlert('Filled discharge form downloaded successfully!', 'success');
  });
  }

  // Wire up collapsibles in admin create view
  const addToggle = document.getElementById('toggleAdditional');
  const addPanel = document.getElementById('additionalPanel');
  const addChevron = document.getElementById('additionalChevron');
  if (addToggle && addPanel && addChevron) {
    addToggle.addEventListener('click', () => {
      const hidden = addPanel.classList.contains('hidden');
      addPanel.classList.toggle('hidden');
      addChevron!.textContent = hidden ? '▲' : '▼';
    });
  }
  const svcToggle = document.getElementById('toggleService');
  const svcPanel = document.getElementById('servicePanel');
  const svcChevron = document.getElementById('serviceChevron');
  if (svcToggle && svcPanel && svcChevron) {
    svcToggle.addEventListener('click', () => {
      const hidden = svcPanel.classList.contains('hidden');
      svcPanel.classList.toggle('hidden');
      svcChevron!.textContent = hidden ? '▲' : '▼';
    });
  }

  // Load orders initially
  loadOrders();
  // Preload KPI silently
  loadKpi();
}

// deprecated legacy view removed

function renderLoginForm() {
  app.innerHTML = `
    <div class="min-h-dvh bg-gradient-to-br from-blue-50 to-gray-100">
      <!-- Enhanced Header -->
      <header class="bg-white shadow-sm border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-center items-center h-16">
            <div class="flex items-center space-x-3">
              <div class="relative">
                <img src="${import.meta.env.BASE_URL}logo.png" alt="Kay Marine" class="h-12 w-12 object-contain rounded-full shadow-md border-2 border-blue-100" />
                <div class="absolute -top-1 -right-1 h-4 w-4 bg-blue-500 rounded-full border-2 border-white"></div>
              </div>
              <div>
                <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                <p class="text-sm text-gray-500 font-medium">Supply and Services</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Login Form -->
      <div class="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
          <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="px-8 py-10">
              <div class="text-center mb-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h2>
                <p class="text-gray-600">Sign in to your account</p>
              </div>
              <form id="loginForm" class="space-y-6">
                <div>
                  <label for="username" class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                  <input id="username" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors" placeholder="Enter your username" required />
                </div>
                <div>
                  <label for="password" class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                  <input id="password" type="password" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors" placeholder="Enter your password" required />
                </div>
                <button class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors" type="submit">
                  Sign In
                </button>
                <p id="error" class="text-red-600 text-sm text-center h-4"></p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  document.getElementById('loginForm')!.addEventListener('submit', login);
}

// Helper function to generate multi-select origin dropdown
function getOriginSelect(id: string, selectedValues: string[] = []): string {
  const options = ['Galley', 'Accommodation', 'ER', 'Bridge', 'Deck', 'Cargo holds'];
  const selectedSet = new Set(selectedValues);
  return `
    <select id="${id}" multiple class="w-full border rounded px-2 py-1 text-sm" style="min-height: 60px;">
      ${options.map(opt => `<option value="${opt}" ${selectedSet.has(opt) ? 'selected' : ''}>${opt}</option>`).join('')}
    </select>
  `;
}

function getDischargeFormHTML(): string {
  return `
          <style>
            .frm {
              font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            }
            .frm h2 {
              font-family: 'Poppins', 'Inter', sans-serif;
              font-size: 1.5rem;
              font-weight: 600;
              color: #111827;
              margin-bottom: 1.5rem;
              letter-spacing: -0.025em;
            }
            .frm table {
              width: 100%;
              border-collapse: separate;
              border-spacing: 0;
              margin-top: 1.5rem;
              border-radius: 0.5rem;
              overflow: hidden;
              box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1);
            }
            .frm th, .frm td {
              border: 1px solid #e5e7eb;
              padding: 0.875rem 1rem;
              text-align: center;
              font-size: 0.875rem;
            }
            .frm th {
              background: linear-gradient(to bottom, #f9fafb, #f3f4f6);
              font-weight: 600;
              font-family: 'Poppins', 'Inter', sans-serif;
              text-transform: uppercase;
              font-size: 0.75rem;
              letter-spacing: 0.05em;
              color: #374151;
              border-bottom: 2px solid #e5e7eb;
            }
            .frm tbody tr {
              transition: background-color 150ms;
            }
            .frm tbody tr:hover {
              background-color: #f9fafb;
            }
            .frm input[type=text],
            .frm input[type=number],
            .frm input[type=date],
            .frm input[type=time],
            .frm input[type=email],
            .frm input[type=datetime-local] {
              width: 100%;
              padding: 0.625rem 0.875rem;
              border: 1.5px solid #e5e7eb;
              border-radius: 0.5rem;
              box-sizing: border-box;
              font-size: 0.875rem;
              transition: all 200ms cubic-bezier(0.4, 0, 0.2, 1);
              background-color: white;
            }
            .frm input[type=text]:focus,
            .frm input[type=number]:focus,
            .frm input[type=date]:focus,
            .frm input[type=time]:focus,
            .frm input[type=email]:focus,
            .frm input[type=datetime-local]:focus {
              outline: none;
              border-color: #3b82f6;
              box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            }
            .frm .total-cell {
              font-weight: 600;
              background: linear-gradient(to bottom, #d1fae5, #a7f3d0);
              color: #065f46;
              font-size: 0.9375rem;
            }
            .frm .form-grid {
              display: grid;
              grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
              gap: 1.25rem;
              margin-top: 1rem;
            }
            .frm .form-field {
              display: flex;
              flex-direction: column;
            }
            .frm .form-field label {
              font-weight: 500;
              color: #374151;
              margin-bottom: 0.5rem;
              font-size: 0.875rem;
              letter-spacing: 0.01em;
            }
            .frm select {
              width: 100%;
              padding: 0.625rem 0.875rem;
              border: 1.5px solid #e5e7eb;
              border-radius: 0.5rem;
              font-size: 0.875rem;
              background-color: white;
              transition: all 200ms cubic-bezier(0.4, 0, 0.2, 1);
            }
            .frm select:focus {
              outline: none;
              border-color: #3b82f6;
              box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            }
            .frm textarea {
              width: 100%;
              padding: 0.625rem 0.875rem;
              border: 1.5px solid #e5e7eb;
              border-radius: 0.5rem;
              font-size: 0.875rem;
              font-family: inherit;
              resize: vertical;
              transition: all 200ms cubic-bezier(0.4, 0, 0.2, 1);
            }
            .frm textarea:focus {
              outline: none;
              border-color: #3b82f6;
              box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
            }
          </style>
          <div class="frm">
            <h2 class="text-xl font-bold mb-2">Vessel Discharge Form</h2>
            <form id="dischargeForm">
              <div class="form-grid">
                <div class="form-field"><label for="ship_name">Ship Name</label><input type="text" name="ship_name" id="ship_name"></div>
                <div class="form-field"><label for="voyage_number">Voyage Number</label><input type="text" name="voyage_number" id="voyage_number"></div>
                <div class="form-field"><label for="berth">Berth</label><input type="text" name="berth" id="berth"></div>
                <div class="form-field"><label for="date">Order Created At</label><input type="date" name="date" id="date"></div>
                <div class="form-field"><label for="time">Time</label><input type="time" name="time" id="time"></div>
          <div class="form-field"><label for="eta">ETA (Estimated Time of Arrival)</label><input type="datetime-local" name="eta" id="eta"></div>
          <div class="form-field"><label for="etb">ETB (Estimated Time of Berth)</label><input type="datetime-local" name="etb" id="etb"></div>
                <div class="form-field"><label for="port">Port</label><input type="text" name="port" id="port" value="Port Hedland"></div>
                <div class="form-field"><label for="flag">Flag</label><input type="text" name="flag" id="flag"></div>
                <div class="form-field"><label for="type">Vessel Type</label><input type="text" name="type" id="type"></div>
                <div class="form-field"><label for="imo">IMO no.</label><input type="text" name="imo" id="imo"></div>
                <div class="form-field"><label for="email">Email</label><input type="email" name="email" id="email"></div>
                <div class="form-field"><label for="dispose_additional_waste">Dispose additional waste (beyond free 1 m³)?</label><input type="checkbox" name="dispose_additional_waste" id="dispose_additional_waste"></div>
                <div class="form-field"><label for="service_purchased">Service Purchased?</label><input type="checkbox" name="service_purchased" id="service_purchased"></div>
                <div class="form-field"><label for="garbage_remaining_on_board">How much garbage remaining on board (m³)</label><input type="number" step="0.01" name="garbage_remaining_on_board" id="garbage_remaining_on_board" placeholder="0.00"></div>
                <div class="form-field"><label for="ship_wants_to_discharge_more">Ship wants to discharge more?</label><input type="checkbox" name="ship_wants_to_discharge_more" id="ship_wants_to_discharge_more"></div>
                <div class="form-field"><label for="along_side">Along Side (Priority Order)</label><input type="checkbox" name="along_side" id="along_side" title="Mark as priority order (shows at top of list)"></div>
                <div class="form-field">
                  ${(() => {
                    const isKayAdmin = (() => {
                      try {
                        const userStr = localStorage.getItem('currentUser');
                        if (userStr) {
                          const user = JSON.parse(userStr);
                          return user.username === 'kayadmin';
                        }
                      } catch (e) {
                        return false;
                      }
                      return false;
                    })();
                    
                    const defaultNote = 'If yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.';
                    
                    if (isKayAdmin) {
                      return `
                        <label for="note" class="text-sm font-medium text-gray-700 mb-1">Note:</label>
                        <textarea id="note" name="note" rows="3" class="w-full border rounded px-3 py-2 text-sm" placeholder="${defaultNote}">${defaultNote}</textarea>
                      `;
                    } else {
                      return `
                        <div class="text-sm text-gray-600 mt-2 p-3 bg-blue-50 border border-blue-200 rounded-md">
                          <strong>Note:</strong> <span id="noteText">${defaultNote}</span>
                        </div>
                      `;
                    }
                  })()}
                </div>
              </div>
            </form>

            <h3 class="mt-4 font-semibold">Vessel Planned to Discharge</h3>
            <table>
              <thead>
                <tr>
                  <th>No.</th>
                  <th>MARPOL Annex V. Garbage</th>
                  <th>Quantity (m³)</th>
                  <th>Origin</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>1</td><td>Cat A. Plastic</td><td><input type="number" step="0.01" class="qty" id="main_cat_a"></td><td>${getOriginSelect('main_origin_a')}</td></tr>
                <tr><td>2</td><td>Cat B. Food Waste</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>3</td><td>Cat C. Domestic Waste</td><td><input type="number" step="0.01" class="qty" id="main_cat_c"></td><td>${getOriginSelect('main_origin_c')}</td></tr>
                <tr><td>4</td><td>Cat D. Cooking Oil</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>5</td><td>Cat E. Incinerator Ashes</td><td><input type="number" step="0.01" class="qty" id="main_cat_e"></td><td>${getOriginSelect('main_origin_e')}</td></tr>
                <tr><td>6</td><td>Cat F. Operational Waste</td><td><input type="number" step="0.01" class="qty" id="main_cat_f"></td><td>${getOriginSelect('main_origin_f')}</td></tr>
                <tr><td>7</td><td>Cat. G Animal carcass(es)</td><td><input type="number" step="0.01" class="qty" id="main_cat_g"></td><td>${getOriginSelect('main_origin_g')}</td></tr>
                <tr><td>8</td><td>Cat. H Fishing gear</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>9</td><td>Cat. I E-waste (No Batteries)</td><td><input type="number" step="0.01" class="qty" id="main_cat_i"></td><td>${getOriginSelect('main_origin_i')}</td></tr>
                <tr><td>10</td><td>Cat. J Cargo residues (non-Harmful to the Marine Environment)</td><td><input type="number" step="0.01" class="qty" id="main_cat_j"></td><td>${getOriginSelect('main_origin_j')}</td></tr>
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="2" class="total-cell">Total Vol:</td>
                  <td class="total-cell" id="totalVol">0</td>
                  <td></td>
                </tr>
              </tfoot>
          </table>

            <div class="mt-6 border rounded-lg">
              <button id="toggleAdditional" class="w-full flex justify-between items-center px-4 py-3 bg-gray-50 hover:bg-gray-100">
                <span class="font-medium">Additional Details</span>
                <span id="additionalChevron">▼</span>
              </button>
              <div id="additionalPanel" class="p-4 hidden">
                <h3 class="mt-6 font-semibold">Vessel Planned to Discharge (Additional)</h3>
                <table>
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>MARPOL Annex V. Garbage</th>
                      <th>Quantity (m³)</th>
                      <th>Origin</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td>1</td><td>Cat A. Plastic</td><td><input type="number" step="0.01" class="qty" id="additional_cat_a"></td><td>${getOriginSelect('additional_origin_a')}</td></tr>
                    <tr><td>2</td><td>Cat B. Food Waste</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>3</td><td>Cat C. Domestic Waste</td><td><input type="number" step="0.01" class="qty" id="additional_cat_c"></td><td>${getOriginSelect('additional_origin_c')}</td></tr>
                    <tr><td>4</td><td>Cat D. Cooking Oil</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>5</td><td>Cat E. Incinerator Ashes</td><td><input type="number" step="0.01" class="qty" id="additional_cat_e"></td><td>${getOriginSelect('additional_origin_e')}</td></tr>
                    <tr><td>6</td><td>Cat F. Operational Waste</td><td><input type="number" step="0.01" class="qty" id="additional_cat_f"></td><td>${getOriginSelect('additional_origin_f')}</td></tr>
                    <tr><td>7</td><td>Cat. G Animal carcass(es)</td><td><input type="number" step="0.01" class="qty" id="additional_cat_g"></td><td>${getOriginSelect('additional_origin_g')}</td></tr>
                    <tr><td>8</td><td>Cat. H Fishing gear</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>9</td><td>Cat. I E-waste (No Batteries)</td><td><input type="number" step="0.01" class="qty" id="additional_cat_i"></td><td>${getOriginSelect('additional_origin_i')}</td></tr>
                    <tr><td>10</td><td>Cat. J Cargo residues (non-Harmful to the Marine Environment)</td><td><input type="number" step="0.01" class="qty" id="additional_cat_j"></td><td>${getOriginSelect('additional_origin_j')}</td></tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colspan="2" class="total-cell">Total Vol:</td>
                      <td class="total-cell" id="additional_totalVol">0</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            <div class="mt-4 border rounded-lg">
              <button id="toggleService" class="w-full flex justify-between items-center px-4 py-3 bg-gray-50 hover:bg-gray-100">
                <span class="font-medium">Service Purchase</span>
                <span id="serviceChevron">▼</span>
              </button>
              <div id="servicePanel" class="p-4 hidden">
                <h3 class="mt-6 font-semibold">Vessel Planned to Discharge (Service Purchase)</h3>
                <table>
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>MARPOL Annex V. Garbage</th>
                      <th>Quantity (m³)</th>
                      <th>Origin</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td>1</td><td>Cat A. Plastic</td><td><input type="number" step="0.01" class="qty" id="service_cat_a"></td><td>${getOriginSelect('service_origin_a')}</td></tr>
                    <tr><td>2</td><td>Cat B. Food Waste</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>3</td><td>Cat C. Domestic Waste</td><td><input type="number" step="0.01" class="qty" id="service_cat_c"></td><td>${getOriginSelect('service_origin_c')}</td></tr>
                    <tr><td>4</td><td>Cat D. Cooking Oil</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>5</td><td>Cat E. Incinerator Ashes</td><td><input type="number" step="0.01" class="qty" id="service_cat_e"></td><td>${getOriginSelect('service_origin_e')}</td></tr>
                    <tr><td>6</td><td>Cat F. Operational Waste</td><td><input type="number" step="0.01" class="qty" id="service_cat_f"></td><td>${getOriginSelect('service_origin_f')}</td></tr>
                    <tr><td>7</td><td>Cat. G Animal carcass(es)</td><td><input type="number" step="0.01" class="qty" id="service_cat_g"></td><td>${getOriginSelect('service_origin_g')}</td></tr>
                    <tr><td>8</td><td>Cat. H Fishing gear</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>9</td><td>Cat. I E-waste (No Batteries)</td><td><input type="number" step="0.01" class="qty" id="service_cat_i"></td><td>${getOriginSelect('service_origin_i')}</td></tr>
                    <tr><td>10</td><td>Cat. J Cargo residues (non-Harmful to the Marine Environment)</td><td><input type="number" step="0.01" class="qty" id="service_cat_j"></td><td>${getOriginSelect('service_origin_j')}</td></tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colspan="2" class="total-cell">Total Vol:</td>
                      <td class="total-cell" id="service_totalVol">0</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

          <div class="mt-4 flex items-center justify-between">
            <button id="newOrderBtn" class="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 hidden">New Order</button>
            <div class="flex items-center justify-end">
            <button id="submitOrder" class="px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700">Submit Discharge Request</button>
            </div>
          </div>
          <p id="msg" class="text-green-700 text-sm h-4 mt-2 text-right"></p>
    </div>`;
}

function switchTab(tab: 'orders' | 'create' | 'last24' | 'next24' | 'kpi') {
  const ordersView = document.getElementById('ordersView')!;
  const createView = document.getElementById('createView')!;
  const kpiView = document.getElementById('kpiView')!;
  const last24View = document.getElementById('last24View')!;
  const next24View = document.getElementById('next24View')!;
  const ordersTab = document.getElementById('ordersTab')!;
  const createTab = document.getElementById('createTab')!;
  const last24Tab = document.getElementById('last24Tab')!;
  const next24Tab = document.getElementById('next24Tab')!;
  const kpiTab = document.getElementById('kpiTab')!;

  // Reset editing state when switching away from create tab
  if (tab !== 'create' && (window as any).editingOrder) {
    (window as any).editingOrder = null;
    createTab.textContent = 'Create Order';
    const titleElement = createView.querySelector('h2')!;
    titleElement.textContent = 'Create New Discharge Order';
    
    // Hide New Order button
    const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
    if (newOrderButton) {
      newOrderButton.classList.add('hidden');
    }
    
    // Reset submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Submit Discharge Request';
    }
  }

  if (tab === 'orders') {
    ordersView.classList.remove('hidden');
    createView.classList.add('hidden');
    last24View.classList.add('hidden');
    next24View.classList.add('hidden');
    kpiView.classList.add('hidden');
    ordersTab.classList.add('border-blue-500', 'text-blue-600');
    ordersTab.classList.remove('border-transparent', 'text-gray-500');
    createTab.classList.add('border-transparent', 'text-gray-500');
    createTab.classList.remove('border-blue-500', 'text-blue-600');
    last24Tab.classList.add('border-transparent', 'text-gray-500');
    last24Tab.classList.remove('border-blue-500', 'text-blue-600');
    next24Tab.classList.add('border-transparent', 'text-gray-500');
    next24Tab.classList.remove('border-blue-500', 'text-blue-600');
    kpiTab.classList.add('border-transparent', 'text-gray-500');
    kpiTab.classList.remove('border-blue-500', 'text-blue-600');
  } else {
    if (tab === 'create') {
      ordersView.classList.add('hidden');
      kpiView.classList.add('hidden');
      last24View.classList.add('hidden');
      next24View.classList.add('hidden');
      createView.classList.remove('hidden');
      createTab.classList.add('border-blue-500', 'text-blue-600');
      createTab.classList.remove('border-transparent', 'text-gray-500');
      ordersTab.classList.add('border-transparent', 'text-gray-500');
      ordersTab.classList.remove('border-blue-500', 'text-blue-600');
      last24Tab.classList.add('border-transparent', 'text-gray-500');
      last24Tab.classList.remove('border-blue-500', 'text-blue-600');
      next24Tab.classList.add('border-transparent', 'text-gray-500');
      next24Tab.classList.remove('border-blue-500', 'text-blue-600');
      kpiTab.classList.add('border-transparent', 'text-gray-500');
      kpiTab.classList.remove('border-blue-500', 'text-blue-600');
      
      // Always clear editing state when switching to create tab (unless we're actually editing)
      // This ensures form is cleared when switching from edit mode to create mode
      if (!(window as any).editingOrder) {
        // Reset tab title and form title if not in edit mode
        createTab.textContent = 'Create Order';
        const titleElement = createView.querySelector('h2');
        if (titleElement) {
          titleElement.textContent = 'Create New Discharge Order';
        }
        
        // Hide New Order button
        const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
        if (newOrderButton) {
          newOrderButton.classList.add('hidden');
        }
        
        // Clear the form to ensure no previous values remain
        FormHandler.clearForm();
        
        // Auto-populate current date and time for new orders
        const dateInput = document.getElementById('date') as HTMLInputElement;
        const timeInput = document.getElementById('time') as HTMLInputElement;
        
        if (dateInput) {
          const now = new Date();
          const currentDate = now.toISOString().split('T')[0]; // Format: YYYY-MM-DD
          dateInput.value = currentDate;
        }
        
        if (timeInput) {
          const now = new Date();
          const currentTime = now.toTimeString().split(' ')[0].substring(0, 5); // Format: HH:MM
          timeInput.value = currentTime;
        }
      }
      
      FormHandler.setupFormHandlers();
    } else {
      if (tab === 'last24') {
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        kpiView.classList.add('hidden');
        next24View.classList.add('hidden');
        last24View.classList.remove('hidden');
        last24Tab.classList.add('border-blue-500', 'text-blue-600');
        last24Tab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        next24Tab.classList.add('border-transparent', 'text-gray-500');
        next24Tab.classList.remove('border-blue-500', 'text-blue-600');
        kpiTab.classList.add('border-transparent', 'text-gray-500');
        kpiTab.classList.remove('border-blue-500', 'text-blue-600');
        loadLast24();
      } else if (tab === 'next24') {
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        kpiView.classList.add('hidden');
        last24View.classList.add('hidden');
        next24View.classList.remove('hidden');
        next24Tab.classList.add('border-blue-500', 'text-blue-600');
        next24Tab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        last24Tab.classList.add('border-transparent', 'text-gray-500');
        last24Tab.classList.remove('border-blue-500', 'text-blue-600');
        kpiTab.classList.add('border-transparent', 'text-gray-500');
        kpiTab.classList.remove('border-blue-500', 'text-blue-600');
        loadNext24();
      } else {
        // KPI
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        last24View.classList.add('hidden');
        next24View.classList.add('hidden');
        kpiView.classList.remove('hidden');
        kpiTab.classList.add('border-blue-500', 'text-blue-600');
        kpiTab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        last24Tab.classList.add('border-transparent', 'text-gray-500');
        last24Tab.classList.remove('border-blue-500', 'text-blue-600');
        next24Tab.classList.add('border-transparent', 'text-gray-500');
        next24Tab.classList.remove('border-blue-500', 'text-blue-600');
        loadKpi();
      }
    }
  }
}

// Token refresh function
async function refreshToken(): Promise<boolean> {
  const refresh = localStorage.getItem('refresh');
  console.log('refreshToken: Refresh token exists:', !!refresh);
  console.log('refreshToken: Refresh token value:', refresh ? refresh.substring(0, 20) + '...' : 'null');
  
  if (!refresh) return false;
  
  try {
    console.log('refreshToken: Attempting token refresh...');
    const res = await fetch(`${apiBase}/auth/refresh/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh })
    });
    
    console.log('refreshToken: Response status:', res.status);
    
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem('access', data.access);
      console.log('refreshToken: Token refreshed successfully');
      return true;
    } else {
      console.log('refreshToken: Token refresh failed with status:', res.status);
    }
  } catch (error) {
    console.error('refreshToken: Token refresh failed with error:', error);
  }
  
  return false;
}

// Enhanced listOrders with token refresh
async function listOrdersWithRefresh() {
  try {
    console.log('listOrdersWithRefresh: Attempting direct API call...');
    return await listOrders();
  } catch (error: any) {
    console.log('listOrdersWithRefresh: API call failed:', error.message);
    if (error.message.includes('401')) {
      console.log('listOrdersWithRefresh: Token expired, attempting refresh...');
      const refreshed = await refreshToken();
      if (refreshed) {
        console.log('listOrdersWithRefresh: Token refreshed, retrying API call...');
        return await listOrders();
      } else {
        console.log('listOrdersWithRefresh: Token refresh failed, redirecting to login...');
        localStorage.removeItem('access');
        localStorage.removeItem('refresh');
        location.reload();
        throw error;
      }
    }
    throw error;
  }
}

async function loadOrders() {
  const ordersTable = document.getElementById('ordersTable')!;
  UIComponents.showLoadingSpinner(ordersTable, 'Loading orders...');

  // Check if user is authenticated
  const access = localStorage.getItem('access');
  console.log('loadOrders: Access token exists:', !!access);
  console.log('loadOrders: Access token value:', access ? access.substring(0, 20) + '...' : 'null');
  
  if (!access) {
    console.log('loadOrders: No access token, showing authentication required message');
    ordersTable.innerHTML = `
      <div class="text-center py-12">
        <div class="text-red-400 text-6xl mb-4">🔒</div>
        <h3 class="text-lg font-medium text-gray-900 mb-2">Authentication Required</h3>
        <p class="text-gray-500">Please log in to view orders.</p>
        <button onclick="location.reload()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Go to Login</button>
      </div>`;
    return;
  }

  try {
    console.log('loadOrders: Attempting to fetch orders...');
    
    // Add timeout to prevent infinite loading
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout after 10 seconds')), 10000);
    });
    
    const ordersPromise = listOrdersWithRefresh();
    let orders = await Promise.race([ordersPromise, timeoutPromise]) as any[];
    
    // Sort orders by priority: Along Side → ETB → Others → Completed (at bottom)
    orders.sort((a: any, b: any) => {
      // Completed orders go to bottom
      const aCompleted = a.job_status === 'completed';
      const bCompleted = b.job_status === 'completed';
      if (aCompleted !== bCompleted) {
        return aCompleted ? 1 : -1; // Completed goes after incomplete
      }
      
      // Within same completion status, prioritize:
      // 1. Along Side orders first
      if (a.along_side !== b.along_side) {
        return a.along_side ? -1 : 1;
      }
      
      // 2. Orders with ETB next (sorted by ETB time)
      const aHasEtb = !!a.etb;
      const bHasEtb = !!b.etb;
      if (aHasEtb !== bHasEtb) {
        return aHasEtb ? -1 : 1;
      }
      if (aHasEtb && bHasEtb) {
        return new Date(a.etb).getTime() - new Date(b.etb).getTime();
      }
      
      // 3. Other orders (by date)
      return new Date(a.date).getTime() - new Date(b.date).getTime();
    });
    if (orders.length === 0) {
      ordersTable.innerHTML = `
        <div class="text-center py-12">
          <div class="text-gray-400 text-6xl mb-4">📋</div>
          <h3 class="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
          <p class="text-gray-500">No discharge orders have been submitted yet.</p>
        </div>`;
      return;
    }

    // Add filter buttons, column selector, and table
    ordersTable.innerHTML = `
      <div class="mb-4 space-y-3">
        <div class="flex gap-2 flex-wrap">
          <button id="filterAll" onclick="filterOrders('all')" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">All Orders</button>
          <button id="filterCompleted" onclick="filterOrders('completed')" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Completed Jobs</button>
          <button id="filterIncomplete" onclick="filterOrders('incomplete')" class="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700">Incomplete Jobs</button>
          <button id="toggleColumnSelector" class="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700">Select Columns</button>
        </div>
        <div id="columnSelector" class="hidden p-4 bg-gray-50 rounded-lg border border-gray-200">
          <p class="text-sm font-medium text-gray-700 mb-3">Show/Hide Columns:</p>
          <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="along_side" checked class="column-toggle">
              <span>Along Side</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="ship_name" checked class="column-toggle">
              <span>Ship Name</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="date" checked class="column-toggle">
              <span>Date</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="berth" checked class="column-toggle">
              <span>Berth</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="port" class="column-toggle">
              <span>Port</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="flag" checked class="column-toggle">
              <span>Flag</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="etb" checked class="column-toggle">
              <span>ETB</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="total_volume" checked class="column-toggle">
              <span>Total Volume</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="scheduled_offload" checked class="column-toggle">
              <span>Scheduled Offload</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="job_status" checked class="column-toggle">
              <span>Job Status</span>
            </label>
            <label class="flex items-center gap-2 text-sm">
              <input type="checkbox" data-column="actions" checked class="column-toggle">
              <span>Actions</span>
            </label>
          </div>
        </div>
      </div>
      <div id="filteredOrdersTable">
        ${renderAdminOrdersTable(orders)}
      </div>
    `;
    
    // Setup column selector toggle
    const toggleBtn = document.getElementById('toggleColumnSelector');
    const selector = document.getElementById('columnSelector');
    if (toggleBtn && selector) {
      toggleBtn.addEventListener('click', () => {
        selector.classList.toggle('hidden');
      });
    }
    
    // Setup column visibility toggles
    const toggles = document.querySelectorAll('.column-toggle');
    toggles.forEach((toggle: any) => {
      toggle.addEventListener('change', () => {
        const col = toggle.getAttribute('data-column');
        setColumnVisibility(col, toggle.checked);
        // Re-render table
        const filteredTable = document.getElementById('filteredOrdersTable');
        if (filteredTable && (window as any).allOrders) {
          filteredTable.innerHTML = renderAdminOrdersTable((window as any).allOrders);
        }
      });
    });
    
    // Store orders globally for filtering
    (window as any).allOrders = orders;
  } catch (error: any) {
    console.error('Error loading orders:', error);
    
    // Check if it's a timeout error
    if (error.message.includes('timeout')) {
      ordersTable.innerHTML = `
        <div class="text-center py-12">
          <div class="text-red-400 text-6xl mb-4">⏱️</div>
          <h3 class="text-lg font-medium text-gray-900 mb-2">Request Timeout</h3>
          <p class="text-gray-500">The request took too long to complete. Please try again.</p>
          <button onclick="loadOrders()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Retry</button>
        </div>`;
      return;
    }
    
    // Check if it's an authentication error
    const isAuthError = error.message.includes('401') || error.message.includes('403');
    const errorMessage = isAuthError 
      ? 'Authentication failed. Please log in again.'
      : 'Failed to load discharge orders. Please try again.';
    
    ordersTable.innerHTML = `
      <div class="text-center py-12">
        <div class="text-red-400 text-6xl mb-4">⚠️</div>
        <h3 class="text-lg font-medium text-gray-900 mb-2">Error loading orders</h3>
        <p class="text-gray-500">${errorMessage}</p>
        ${isAuthError ? '<button onclick="location.reload()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh Page</button>' : ''}
      </div>`;
  }
}

// Filter orders by job status
(window as any).filterOrders = function(status: string) {
  const allOrders = (window as any).allOrders;
  if (!allOrders) return;
  
  let filteredOrders = allOrders;
  if (status === 'completed') {
    filteredOrders = allOrders.filter((order: any) => order.job_status === 'completed');
  } else if (status === 'incomplete') {
    filteredOrders = allOrders.filter((order: any) => order.job_status !== 'completed');
  }
  
  // Maintain sort order: Along Side → ETB → Others → Completed (at bottom)
  filteredOrders.sort((a: any, b: any) => {
    const aCompleted = a.job_status === 'completed';
    const bCompleted = b.job_status === 'completed';
    if (aCompleted !== bCompleted) {
      return aCompleted ? 1 : -1;
    }
    if (a.along_side !== b.along_side) {
      return a.along_side ? -1 : 1;
    }
    const aHasEtb = !!a.etb;
    const bHasEtb = !!b.etb;
    if (aHasEtb !== bHasEtb) {
      return aHasEtb ? -1 : 1;
    }
    if (aHasEtb && bHasEtb) {
      return new Date(a.etb).getTime() - new Date(b.etb).getTime();
    }
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });
  
  const filteredTable = document.getElementById('filteredOrdersTable');
  if (filteredTable) {
    filteredTable.innerHTML = renderAdminOrdersTable(filteredOrders);
  }
  
  // Update button styles
  const buttons = ['filterAll', 'filterCompleted', 'filterIncomplete'];
  buttons.forEach(buttonId => {
    const button = document.getElementById(buttonId);
    if (button) {
      button.classList.remove('bg-blue-600', 'bg-green-600', 'bg-orange-600', 'ring-2', 'ring-offset-2', 'ring-blue-500');
      if (buttonId === `filter${status.charAt(0).toUpperCase() + status.slice(1)}` || (status === 'all' && buttonId === 'filterAll')) {
        if (status === 'all') button.classList.add('bg-blue-600');
        else if (status === 'completed') button.classList.add('bg-green-600');
        else if (status === 'incomplete') button.classList.add('bg-orange-600');
        button.classList.add('ring-2', 'ring-offset-2', 'ring-blue-500');
      } else {
        button.classList.add('bg-gray-400');
      }
    }
  });
};

async function loadLast24() {
  const table = document.getElementById('last24Table')!;
  UIComponents.showLoadingSpinner(table, 'Loading last 24 hours...');
  try {
    const orders = await listOrders();
    const now = new Date();
    const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const completed = orders.filter((o: any) => o.actual_offload_at && new Date(o.actual_offload_at) >= dayAgo && new Date(o.actual_offload_at) <= now);
    completed.sort((a: any, b: any) => new Date(b.actual_offload_at).getTime() - new Date(a.actual_offload_at).getTime());
    table.innerHTML = renderAdminOrdersTable(completed);
  } catch (e: any) {
    table.innerHTML = '<div class="text-center text-red-600">Failed to load</div>';
  }
}

async function loadNext24() {
  const table = document.getElementById('next24Table')!;
  UIComponents.showLoadingSpinner(table, 'Loading next 24 hours...');
  try {
    const orders = await listOrders();
    const now = new Date();
    const next = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const upcoming = orders.filter((o: any) => o.scheduled_offload_at && new Date(o.scheduled_offload_at) >= now && new Date(o.scheduled_offload_at) <= next);
    upcoming.sort((a: any, b: any) => new Date(a.scheduled_offload_at).getTime() - new Date(b.scheduled_offload_at).getTime());
    table.innerHTML = renderAdminOrdersTable(upcoming);
  } catch (e: any) {
    table.innerHTML = '<div class="text-center text-red-600">Failed to load</div>';
  }
}
// KPI Page instance
let kpiPageInstance: any = null;

async function loadKpi() {
  // Import KPI component dynamically
  if (!kpiPageInstance) {
    const { KPIPage } = await import('./components/KPIPage');
    kpiPageInstance = new KPIPage();
  }
  
  await kpiPageInstance.load();
}

// Set up navigation callbacks for FormHandler (after functions are defined)
FormHandler.setNavigationCallbacks({
  switchTab,
  loadOrders,
  checkUserRole
});

// Global functions for order actions
(window as any).viewOrderDetails = (orderId: number) => {
  openOrderDetailsModal(orderId);
};

(window as any).sendDischargeCertificate = async (orderId: number) => {
  try {
    // Check if certificate is marked as created
    const checkbox = document.getElementById('discharge_certificate_created') as HTMLInputElement;
    if (!checkbox || !checkbox.checked) {
      UIComponents.showAlert('Please mark the certificate as "Created" before sending', 'error');
      return;
    }
    
    // Fetch the order data
    const order = await getOrder(orderId);
    
    // Generate the discharge certificate
    generateDischargeCertificate(order);
    
    UIComponents.showAlert('Discharge certificate generated successfully!', 'success');
  } catch (error) {
    console.error('Failed to generate discharge certificate:', error);
    UIComponents.showAlert('Failed to generate discharge certificate', 'error');
  }
};

(window as any).toggleSendButton = (orderId: number) => {
  const checkbox = document.getElementById('discharge_certificate_created') as HTMLInputElement;
  const sendButton = document.getElementById(`sendBtn_${orderId}`) as HTMLButtonElement;
  
  if (checkbox && sendButton) {
    if (checkbox.checked) {
      // Enable the button
      sendButton.disabled = false;
      sendButton.className = 'px-3 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors';
    } else {
      // Disable the button
      sendButton.disabled = true;
      sendButton.className = 'px-3 py-1 bg-gray-400 text-white text-sm rounded-md cursor-not-allowed transition-colors';
    }
  }
};

// generateDischargeCertificate and calculateTotalQuantities are imported from CertificateGenerator

function openOrderDetailsModal(orderId: number) {
  // Create modal container
  const overlay = document.createElement('div');
  overlay.id = 'orderModalOverlay';
  overlay.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/50';

  const modal = document.createElement('div');
  modal.className = 'bg-white w-full max-w-3xl max-h-[90vh] rounded-2xl shadow-xl overflow-hidden flex flex-col';
  modal.innerHTML = `
    <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
      <h3 class="text-lg font-semibold">Operations & Details</h3>
      <button id="closeOrderModal" class="text-gray-500 hover:text-gray-700">✕</button>
    </div>
    <div id="orderModalBody" class="p-6 overflow-y-auto">
      <div class="flex justify-center items-center h-32">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <span class="ml-2 text-gray-600">Loading order...</span>
      </div>
    </div>
    <div class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
      <button id="saveOrderStages" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save</button>
      <button id="cancelOrderStages" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Close</button>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const close = () => {
    overlay.remove();
  };
  (document.getElementById('closeOrderModal') as HTMLButtonElement).onclick = close;
  (document.getElementById('cancelOrderStages') as HTMLButtonElement).onclick = close;

  // Load order details
  fetch(`${apiBase}/discharge-forms/${orderId}/`, {
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
  }).then(async (res) => {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const order = await res.json();
    // Preserve current order state for merging partial updates from the modal
    (window as any).currentOrderForStages = order;
    renderOrderStages(order);
    
    // Add event listeners to update job status dropdown when operations change
    setupOperationChangeListeners();
  }).catch((err) => {
    console.error(err);
    const body = document.getElementById('orderModalBody')!;
    body.innerHTML = `<p class="text-red-600">Failed to load order.</p>`;
  });

  (document.getElementById('saveOrderStages') as HTMLButtonElement).onclick = async () => {
    try {
      const payload = collectStageForm();
      // Allow saving regardless of completion status
      await patchOrder(orderId, payload);
      UIComponents.showAlert('Order stages updated', 'success');
      close();
      // Refresh list to reflect color later if needed
      loadOrders();
    } catch (e: any) {
      console.error(e);
      UIComponents.showAlert('Failed to update order stages', 'error');
    }
  };
}

function renderOrderStages(order: any) {
  const color = computeStageColor(order);
  const badgeClass = colorToBadge(color);

  const body = document.getElementById('orderModalBody')!;
  body.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between">
  <div>
          <h4 class="text-base font-semibold">${order.ship_name} <span class="text-sm text-gray-500">(IMO: ${order.imo_no || '-'}, ${order.port})</span></h4>
          <p class="text-sm text-gray-500">${new Date(order.date).toLocaleDateString()} • Berth: ${order.berth || '-'}</p>
              </div>
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${badgeClass}">
          ${color.toUpperCase()} STATUS
        </span>
            </div>

      <!-- Details section -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg border">
        ${detailRow('Vessel Type', order.vessel_type)}
        ${detailRow('Flag', order.flag)}
        ${detailRow('Port', order.port)}
        ${detailRow('Date', new Date(order.date).toLocaleDateString())}
        ${detailRow('Time', order.time || '-')}
        ${detailRow('ETA', order.eta ? new Date(order.eta).toLocaleString() : '-')}
        ${detailRow('ETB', formatDateTimeNoTZ(order.etb))}
        ${detailRow('Total Volume (m³)', order.total_volume != null ? String(order.total_volume) : '-')}
        ${detailRow('Scheduled Offload', order.scheduled_offload_at ? new Date(order.scheduled_offload_at).toLocaleString() : '-')}
        ${detailRow('Actual Offload', order.actual_offload_at ? new Date(order.actual_offload_at).toLocaleString() : '-')}
        ${detailRow('Collection Date & Time', order.collecting_boat?.collection_time ? new Date(order.collecting_boat.collection_time).toLocaleString() : '-')}
        ${detailRow('PPA Supplied Vol (m³)', order.ppa_supplied_volume_m3 != null ? String(order.ppa_supplied_volume_m3) : '-')}
        ${detailRow('Used Vol (m³)', order.used_volume_m3 != null ? String(order.used_volume_m3) : '-')}
        ${detailRow('Documentation', order.documentation_complete ? 'Complete' : 'Incomplete')}
        ${detailRow('Incident', order.incident_occurred ? 'Occurred' : 'None')}
        ${detailRow('Customer Rating', order.customer_rating != null ? `${order.customer_rating}/10` : '-')}
        ${detailRow('Created', new Date(order.created_at).toLocaleString())}
        ${detailRow('Updated', new Date(order.updated_at).toLocaleString())}
    </div>

      <div class="grid gap-4">
        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot('blue')}
            <div>
              <p class="font-medium">1) Order created</p>
              <p class="text-xs text-gray-500">Order has been created in the system</p>
  </div>
  </div>
          <span class="text-xs text-green-700 bg-green-100 px-2 py-1 rounded">Done</span>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.form44_submitted ? 'green' : 'gray')}
            <div>
              <p class="font-medium">2) Form 44 submitted</p>
              <p class="text-xs text-gray-500">Permission request for ship waste disposal (AUS)</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="form44_submitted" type="checkbox" ${order.form44_submitted ? 'checked' : ''} class="h-4 w-4">
            <span>${order.form44_submitted ? 'Submitted' : 'submitted'}</span>
          </label>
        </div>

        <!-- Verbal clearance taken on phone for Form 44 -->
        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(((order.collecting_checklist && order.collecting_checklist.verbal_clearance) === 'yes') ? 'green' : 'gray')}
            <div>
              <p class="font-medium">Verbal clearance taken on phone for Form 44</p>
              <p class="text-xs text-gray-500">Select Yes/No (defaults to No)</p>
            </div>
          </div>
          <div class="flex items-center gap-4 text-sm">
            ${(() => {
              const saved = order.collecting_checklist?.verbal_clearance || 'no';
              const yesChecked = saved === 'yes' ? 'checked' : '';
              const noChecked = saved !== 'yes' ? 'checked' : '';
              return `
                <label class=\"inline-flex items-center gap-2\"> 
                  <input type=\"radio\" name=\"op_verbal_clearance\" value=\"yes\" ${yesChecked} /> Yes
                </label>
                <label class=\"inline-flex items-center gap-2\"> 
                  <input type=\"radio\" name=\"op_verbal_clearance\" value=\"no\" ${noChecked} /> No
                </label>`;
            })()}
          </div>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.biosecurity_status === 'approved' ? 'orange' : order.biosecurity_status === 'rejected' ? 'red' : 'gray')}
            <div>
              <p class="font-medium">3) Biosecurity permission</p>
              <p class="text-xs text-gray-500">Set to Approved/Rejected/Pending</p>
            </div>
          </div>
          <select id="biosecurity_status" class="border rounded px-2 py-1 text-sm">
            ${selectOption('pending', order.biosecurity_status)}
            ${selectOption('approved', order.biosecurity_status)}
            ${selectOption('rejected', order.biosecurity_status)}
          </select>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.govt_status === 'approved' ? 'green' : order.govt_status === 'rejected' ? 'red' : 'gray')}
            <div>
              <p class="font-medium">4) Custom permission</p>
              <p class="text-xs text-gray-500">Set to Approved/Rejected/Pending</p>
            </div>
          </div>
          <select id="govt_status" class="border rounded px-2 py-1 text-sm">
            ${selectOption('pending', order.govt_status)}
            ${selectOption('approved', order.govt_status)}
            ${selectOption('rejected', order.govt_status)}
          </select>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.bio_witness ? 'green' : 'gray')}
            <div>
              <p class="font-medium">5) Bio security inspector booked to witness disposal</p>
              <p class="text-xs text-gray-500">Set by operations</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="bio_witness" type="checkbox" ${order.bio_witness ? 'checked' : ''} class="h-4 w-4">
            <span>${order.bio_witness ? 'Booked' : 'booked'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.landfill_booked ? 'green' : 'gray')}
            <div>
              <p class="font-medium">6) Landfill booked for disposal</p>
              <p class="text-xs text-gray-500">Set by operations</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="landfill_booked" type="checkbox" ${order.landfill_booked ? 'checked' : ''} class="h-4 w-4">
            <span>${order.landfill_booked ? 'Booked' : 'booked'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.docs_complete ? 'green' : 'gray')}
            <div>
              <p class="font-medium">7) Docs Complete</p>
              <p class="text-xs text-gray-500">All documentation completed</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="docs_complete" type="checkbox" ${order.docs_complete ? 'checked' : ''} class="h-4 w-4">
            <span>${order.docs_complete ? 'Complete' : 'Complete'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.discharge_certificate_created ? 'green' : 'gray')}
            <div>
              <p class="font-medium">8) Create discharge certificate</p>
              <p class="text-xs text-gray-500">Must be created before completion</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
          <label class="inline-flex items-center gap-2 text-sm">
              <input id="discharge_certificate_created" type="checkbox" ${order.discharge_certificate_created ? 'checked' : ''} class="h-4 w-4" onchange="toggleSendButton(${order.id})">
            <span>${order.discharge_certificate_created ? 'Created' : 'Created'}</span>
          </label>
            <button id="sendBtn_${order.id}" onclick="sendDischargeCertificate(${order.id})" class="px-3 py-1 text-white text-sm rounded-md transition-colors ${order.discharge_certificate_created ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'}" ${order.discharge_certificate_created ? '' : 'disabled'}>
              Send
            </button>
          </div>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.invoice_created ? 'green' : 'gray')}
            <div>
              <p class="font-medium">9) Invoice</p>
              <p class="text-xs text-gray-500">Invoice generated for the discharge order</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="invoice_created" type="checkbox" ${order.invoice_created ? 'checked' : ''} class="h-4 w-4">
            <span>${order.invoice_created ? 'Created' : 'Created'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border ${order.incident_occurred ? 'bg-red-50' : 'bg-gray-50'}">
          <div class="flex items-center gap-3">
            ${dot(order.incident_occurred ? 'red' : 'gray')}
            <div>
              <p class="font-medium">10) Incident</p>
              <p class="text-xs text-gray-500">Track incidents for KPI reporting</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
            <label class="inline-flex items-center gap-2 text-sm">
              <input id="incident_occurred" type="checkbox" ${order.incident_occurred ? 'checked' : ''} class="h-4 w-4" onchange="toggleIncidentUpload(${order.id})">
              <span>${order.incident_occurred ? 'Occurred' : 'Occurred'}</span>
            </label>
          </div>
        </div>
        
        <div id="incidentUploadSection_${order.id}" class="mt-3 p-4 rounded-lg border-2 border-red-200 bg-red-50 ${order.incident_occurred ? '' : 'hidden'}">
          <div class="mb-4">
            <h4 class="text-sm font-semibold text-red-800 mb-1 flex items-center gap-2">
              <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
              </svg>
              Upload Incident Document
            </h4>
            <p class="text-xs text-gray-600">Upload supporting documents for this incident (PDF, DOC, DOCX, JPG, PNG)</p>
          </div>
          
          <div class="bg-white rounded-lg border border-red-200 p-4 mb-4">
            <label for="incident_file_${order.id}" class="block mb-2 text-sm font-medium text-gray-700">
              Select File:
            </label>
            <div class="flex items-center gap-3">
              <label class="flex-1 cursor-pointer">
                <input type="file" id="incident_file_${order.id}" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" class="hidden" onchange="updateIncidentFileName(${order.id})">
                <div class="flex items-center justify-between px-4 py-2.5 border-2 border-dashed border-gray-300 rounded-lg hover:border-red-400 hover:bg-red-50 transition-colors">
                  <span id="incident_file_name_${order.id}" class="text-sm text-gray-500">Click to choose file or drag and drop</span>
                  <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                  </svg>
                </div>
              </label>
              <button onclick="uploadIncidentDocument(${order.id})" class="px-6 py-2.5 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700 transition-colors shadow-sm flex items-center gap-2 whitespace-nowrap">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                </svg>
                Upload
              </button>
            </div>
          </div>
          
          <div class="mt-4">
            <h5 class="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
              </svg>
              Uploaded Documents (${order.incident_documents?.length || 0})
            </h5>
            <div id="incidentDocuments_${order.id}" class="space-y-2">
              ${order.incident_documents && order.incident_documents.length > 0 ? order.incident_documents.map((doc: any) => `
                <div class="flex items-center justify-between p-3 bg-white rounded-lg border border-gray-200 hover:border-red-300 hover:shadow-sm transition-all">
                  <div class="flex items-center gap-3 flex-1 min-w-0">
                    <div class="flex-shrink-0 w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                      <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                      </svg>
                    </div>
                    <div class="flex-1 min-w-0">
                      <a href="${doc.file}" target="_blank" class="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline truncate block">
                        ${doc.file.split('/').pop()}
                      </a>
                      <p class="text-xs text-gray-500 mt-0.5">
                        Uploaded by ${doc.uploaded_by_username || 'Admin'} • ${new Date(doc.uploaded_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div class="flex items-center gap-2 ml-3">
                    <a href="${doc.file}" target="_blank" class="px-3 py-1.5 text-xs font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 transition-colors flex items-center gap-1 whitespace-nowrap">
                      <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path>
                      </svg>
                      View
                    </a>
                    <button onclick="deleteIncidentDocument(${order.id}, ${doc.id})" class="px-3 py-1.5 text-xs font-medium text-white bg-red-600 rounded-md hover:bg-red-700 transition-colors flex items-center gap-1 whitespace-nowrap" title="Delete document">
                      <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                      </svg>
                      Delete
                    </button>
                  </div>
                </div>
              `).join('') : `
                <div class="p-4 bg-gray-50 rounded-lg border border-dashed border-gray-300 text-center">
                  <svg class="w-8 h-8 text-gray-400 mx-auto mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <p class="text-sm text-gray-500">No documents uploaded yet</p>
                  <p class="text-xs text-gray-400 mt-1">Upload a document to track this incident</p>
                </div>
              `}
            </div>
          </div>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border bg-yellow-50">
          <div class="flex items-center gap-3">
            ${dot(order.customer_rating ? 'green' : 'gray')}
            <div>
              <p class="font-medium">11) Customer Rating</p>
              <p class="text-xs text-gray-500">Rate the job quality (Admin only)</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
            <select id="customer_rating" class="border rounded px-3 py-1 text-sm">
              <option value="">Not Rated</option>
              <option value="0" ${order.customer_rating === 0 ? 'selected' : ''}>0</option>
              <option value="1" ${order.customer_rating === 1 ? 'selected' : ''}>1</option>
              <option value="2" ${order.customer_rating === 2 ? 'selected' : ''}>2</option>
              <option value="3" ${order.customer_rating === 3 ? 'selected' : ''}>3</option>
              <option value="4" ${order.customer_rating === 4 ? 'selected' : ''}>4</option>
              <option value="5" ${order.customer_rating === 5 ? 'selected' : ''}>5</option>
              <option value="6" ${order.customer_rating === 6 ? 'selected' : ''}>6</option>
              <option value="7" ${order.customer_rating === 7 ? 'selected' : ''}>7</option>
              <option value="8" ${order.customer_rating === 8 ? 'selected' : ''}>8</option>
              <option value="9" ${order.customer_rating === 9 ? 'selected' : ''}>9</option>
              <option value="10" ${order.customer_rating === 10 ? 'selected' : ''}>10</option>
            </select>
          </div>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border bg-blue-50">
          <div class="flex items-center gap-3">
            ${dot(order.job_status === 'completed' ? 'green' : 'orange')}
            <div>
              <p class="font-medium">12) Job Done</p>
              <p class="text-xs text-gray-500">Mark job as completed when all operations are done</p>
              <p class="text-xs text-red-500 mt-1" id="jobStatusWarning" style="display: none;">⚠️ All operations must be completed before marking job as done</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
            <button id="jobDoneBtn" onclick="markJobDone(${order.id})" class="px-4 py-2 text-sm font-medium rounded-md transition-colors ${areAllOperationsComplete(order) ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-gray-300 text-gray-600 cursor-not-allowed'}" ${areAllOperationsComplete(order) ? '' : 'disabled'}>
              ${order.job_status === 'completed' ? '✓ Job Done' : 'Mark Job Done'}
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Setup listeners to update Job Done button when operations change
  setTimeout(() => {
    setupOperationChangeListeners();
  }, 100);
}

// areAllOperationsComplete is imported from utils/orderHelpers.ts

// Mark job as done - replaces the dropdown
(window as any).markJobDone = async function(orderId: number) {
  // Check if all operations are complete
  const form44 = (document.getElementById('form44_submitted') as HTMLInputElement)?.checked || false;
  const bio = (document.getElementById('biosecurity_status') as HTMLSelectElement)?.value || 'pending';
  const govt = (document.getElementById('govt_status') as HTMLSelectElement)?.value || 'pending';
  const bio_witness = (document.getElementById('bio_witness') as HTMLInputElement)?.checked || false;
  const landfill_booked = (document.getElementById('landfill_booked') as HTMLInputElement)?.checked || false;
  const docs_complete = (document.getElementById('docs_complete') as HTMLInputElement)?.checked || false;
  const discharge_certificate_created = (document.getElementById('discharge_certificate_created') as HTMLInputElement)?.checked || false;
  const invoice_created = (document.getElementById('invoice_created') as HTMLInputElement)?.checked || false;
  
  const allComplete = (
    form44 === true &&
    bio === 'approved' &&
    govt === 'approved' &&
    bio_witness === true &&
    landfill_booked === true &&
    docs_complete === true &&
    discharge_certificate_created === true &&
    invoice_created === true
  );
  
  if (!allComplete) {
    const warningElement = document.getElementById('jobStatusWarning');
    if (warningElement) {
      warningElement.style.display = 'block';
      setTimeout(() => {
        warningElement.style.display = 'none';
      }, 5000);
    }
    UIComponents.showAlert('Cannot mark job as completed. All 9 operations must be finished first.', 'error');
    return;
  }
  
  // Mark as completed
  const payload: any = collectStageForm();
  payload.job_status = 'completed';
  
  try {
    const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
      method: 'PATCH',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('access')}`
      },
      body: JSON.stringify(payload)
    });
    
    const responseData = await res.json().catch(() => ({}));
    
    if (res.ok) {
      UIComponents.showAlert('Job marked as completed!', 'success');
      // Update button state
      const jobDoneBtn = document.getElementById('jobDoneBtn') as HTMLButtonElement;
      if (jobDoneBtn) {
        jobDoneBtn.textContent = '✓ Job Done';
        jobDoneBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
        jobDoneBtn.classList.add('bg-green-700');
      }
      // Refresh the order list to show updated status
      loadOrders();
    } else {
      const errorMessage = responseData.error || responseData.detail || `Failed to update job status (${res.status})`;
      UIComponents.showAlert(errorMessage, 'error');
      console.error('Failed to mark job done:', responseData);
    }
  } catch (error: any) {
    console.error('Error marking job as done:', error);
    UIComponents.showAlert(error.message || 'Error marking job as done', 'error');
  }
};

// Setup event listeners for operation changes to update Job Done button
function setupOperationChangeListeners() {
  const operationElements = [
    'form44_submitted',
    'biosecurity_status', 
    'govt_status',
    'bio_witness',
    'landfill_booked',
    'docs_complete',
    'discharge_certificate_created',
    'invoice_created'
  ];
  
  operationElements.forEach(elementId => {
    const element = document.getElementById(elementId);
    if (element) {
      element.addEventListener('change', () => {
        updateJobDoneButton();
      });
    }
  });
}

// Update Job Done button based on current operation states
function updateJobDoneButton() {
  const jobDoneBtn = document.getElementById('jobDoneBtn') as HTMLButtonElement;
  if (!jobDoneBtn) return;
  
  // Check if all operations are complete
  const form44 = (document.getElementById('form44_submitted') as HTMLInputElement)?.checked || false;
  const bio = (document.getElementById('biosecurity_status') as HTMLSelectElement)?.value || 'pending';
  const govt = (document.getElementById('govt_status') as HTMLSelectElement)?.value || 'pending';
  const bio_witness = (document.getElementById('bio_witness') as HTMLInputElement)?.checked || false;
  const landfill_booked = (document.getElementById('landfill_booked') as HTMLInputElement)?.checked || false;
  const docs_complete = (document.getElementById('docs_complete') as HTMLInputElement)?.checked || false;
  const discharge_certificate_created = (document.getElementById('discharge_certificate_created') as HTMLInputElement)?.checked || false;
  const invoice_created = (document.getElementById('invoice_created') as HTMLInputElement)?.checked || false;
  
  const allComplete = (
    form44 === true &&
    bio === 'approved' &&
    govt === 'approved' &&
    bio_witness === true &&
    landfill_booked === true &&
    docs_complete === true &&
    discharge_certificate_created === true &&
    invoice_created === true
  );
  
  // Update button state
  if (allComplete) {
    jobDoneBtn.disabled = false;
    jobDoneBtn.classList.remove('bg-gray-300', 'text-gray-600', 'cursor-not-allowed');
    jobDoneBtn.classList.add('bg-green-600', 'text-white', 'hover:bg-green-700');
  } else {
    jobDoneBtn.disabled = true;
    jobDoneBtn.classList.remove('bg-green-600', 'text-white', 'hover:bg-green-700');
    jobDoneBtn.classList.add('bg-gray-300', 'text-gray-600', 'cursor-not-allowed');
  }
}

function collectStageForm() {
  const form44 = (document.getElementById('form44_submitted') as HTMLInputElement)?.checked || false;
  const bio = (document.getElementById('biosecurity_status') as HTMLSelectElement)?.value || 'pending';
  const govt = (document.getElementById('govt_status') as HTMLSelectElement)?.value || 'pending';
  const bio_witness = (document.getElementById('bio_witness') as HTMLInputElement)?.checked || false;
  const landfill_booked = (document.getElementById('landfill_booked') as HTMLInputElement)?.checked || false;
  const docs_complete = (document.getElementById('docs_complete') as HTMLInputElement)?.checked || false;
  const discharge_certificate_created = (document.getElementById('discharge_certificate_created') as HTMLInputElement)?.checked || false;
  const invoice_created = (document.getElementById('invoice_created') as HTMLInputElement)?.checked || false;
  const incident_occurred = (document.getElementById('incident_occurred') as HTMLInputElement)?.checked || false;
  const customer_rating = (document.getElementById('customer_rating') as HTMLSelectElement)?.value || null;
  const verbal_clearance = ((document.querySelector('input[name="op_verbal_clearance"]:checked') as HTMLInputElement) || { value: 'no' }).value;
  const existingChecklist = ((window as any).currentOrderForStages?.collecting_checklist) || {};
  
  // If biosecurity_status is approved, automatically set bio_security_clearance to 'yes'
  const collecting_checklist = { ...existingChecklist, verbal_clearance } as Record<string, string>;
  if (bio === 'approved') {
    collecting_checklist.bio_security_clearance = 'yes';
  }
  
  return {
    form44_submitted: form44,
    biosecurity_status: bio,
    govt_status: govt,
    bio_witness,
    landfill_booked,
    docs_complete,
    discharge_certificate_created,
    invoice_created,
    incident_occurred,
    customer_rating: customer_rating ? parseInt(customer_rating) : null,
    collecting_checklist,
  };
}

// computeStageColor, colorToBadge, dot, selectOption, and detailRow are imported from utils/orderHelpers.ts

(window as any).deleteOrder = async (orderId: number) => {
  if (confirm('Are you sure you want to delete this order?')) {
    try {
      await deleteOrderReq(orderId);
        UIComponents.showAlert('Order deleted successfully!', 'success');
      loadOrders();
    } catch (error) {
      console.error('Error deleting order:', error);
      UIComponents.showAlert('Failed to delete order', 'error');
    }
  }
};

(window as any).setSchedule = async (orderId: number) => {
  try {
    const dEl = document.getElementById(`sched_date_${orderId}`) as HTMLInputElement | null;
    const tEl = document.getElementById(`sched_time_${orderId}`) as HTMLInputElement | null;
    const date = dEl?.value || '';
    const time = tEl?.value || '';
    if (!date || !time) {
      UIComponents.showAlert('Please select both date and time for schedule.', 'error');
      return;
    }
    const iso = new Date(`${date}T${time}`);
    if (isNaN(iso.getTime())) {
      UIComponents.showAlert('Invalid schedule date/time.', 'error');
      return;
    }
    await patchOrder(orderId, { scheduled_offload_at: iso.toISOString() });
    UIComponents.showAlert('Schedule updated', 'success');
    // Refresh boat orders table if present; otherwise try admin list
    if (document.getElementById('boatOrdersTable')) {
      loadBoatOrders();
    } else if (document.getElementById('ordersTable')) {
      loadOrders();
    }
    } catch (e: any) {
    console.error(e);
    UIComponents.showAlert('Failed to update schedule', 'error');
  }
};

(window as any).editOrder = async (orderId: number) => {
  try {
    // Fetch the order data
    const order = await getOrder(orderId);
    
    // Store the order data for editing
    (window as any).editingOrder = order;
    
    // Switch to create tab
    switchTab('create');
    
    // Update the tab title to indicate editing mode
    const createTab = document.getElementById('createTab')!;
    createTab.textContent = 'Edit Order';
    
    // Update the form title
    const createView = document.getElementById('createView')!;
    const titleElement = createView.querySelector('h2')!;
    titleElement.textContent = `Edit Discharge Order - ${order.ship_name}`;
    
    // Show New Order button
    const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
    if (newOrderButton) {
      newOrderButton.classList.remove('hidden');
    }
    
    // Update submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Update Discharge Order';
    }
    
  } catch (e: any) {
    console.error('Failed to load order for editing:', e);
    UIComponents.showAlert('Failed to load order for editing', 'error');
  }
};

// moved to components/EditOrderModal.ts

async function login(ev: Event) {
  ev.preventDefault();
  const username = (document.getElementById('username') as HTMLInputElement).value;
  const password = (document.getElementById('password') as HTMLInputElement).value;
  const res = await fetch(`${apiBase}/auth/login/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) {
    (document.getElementById('error') as HTMLParagraphElement).textContent = 'Invalid credentials';
    return;
  }
  const data = await res.json();
  localStorage.setItem('access', data.access);
  localStorage.setItem('refresh', data.refresh);
  render();
}

async function logout() {
  const refresh = localStorage.getItem('refresh');
  try {
    await fetch(`${apiBase}/auth/logout/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('access')}` },
      body: JSON.stringify({ refresh })
    });
  } finally {
    localStorage.removeItem('access');
    localStorage.removeItem('refresh');
    render();
  }
}

render();

// legacy constants removed

// deprecated legacy helpers removed

// deprecated legacy helpers removed

// legacy helpers removed

// legacy helpers removed

// deprecated legacy submission removed

render();
