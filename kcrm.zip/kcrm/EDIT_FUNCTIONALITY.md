# Edit Order Functionality

## Overview
The Edit button in the Orders List now redirects users to the Create Order tab with pre-populated form fields instead of opening a modal dialog.

## How It Works

### 1. Edit Button Click
- When a user clicks the "Edit" button in the Orders List table
- The system fetches the complete order data from the API
- Stores the order data in `window.editingOrder` for reference
- Redirects to the Create Order tab

### 2. Form Population
- The Create Order tab detects editing mode
- All form fields are automatically populated with existing order data:
  - Ship details (name, berth, port, flag, vessel type, IMO number)
  - Date and time fields
  - ETA and ETB fields
  - Checkboxes for additional waste disposal and service purchase
  - Vessel plan quantities for all waste categories
  - Total volume calculation

### 3. Visual Indicators
- Tab title changes from "Create Order" to "Edit Order"
- Form title shows "Edit Discharge Order - [Ship Name]"
- Submit button text changes to "Update Discharge Order"

### 4. Form Submission
- In edit mode: Updates existing order via PATCH API
- In create mode: Creates new order via POST API
- Success message shows appropriate text for the operation
- Automatically redirects back to Orders List after successful operation

### 5. State Management
- Editing state is cleared when switching away from Create Order tab
- Form is reset when returning to create mode
- All UI elements return to their original state

## Benefits
- **Unified Interface**: Same form for both creating and editing
- **Better UX**: Full-screen editing instead of cramped modal
- **Consistent Experience**: Same validation and submission flow
- **Easier Maintenance**: Single form to maintain instead of separate modal

## Technical Implementation
- Modified `editOrder()` function to fetch data and redirect
- Added `populateFormFields()` method to fill form with existing data
- Enhanced `handleFormSubmission()` to handle both create and update operations
- Updated `switchTab()` to manage editing state
- Added `clearForm()` method for form reset functionality
