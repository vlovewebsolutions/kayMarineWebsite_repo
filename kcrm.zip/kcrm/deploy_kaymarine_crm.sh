# Deployment Script for Kay Marine CRM

#!/bin/bash

# Kay Marine CRM Deployment Script
# Run this script on your Hostinger VPS

echo "🚀 Starting Kay Marine CRM Deployment..."

# Variables - UPDATE THESE PATHS
PROJECT_DIR="/path/to/your/kaymarine_crm"
VENV_PATH="/path/to/your/venv"
DOMAIN="kaymarine.your-domain.com"
DB_NAME="kaymarine_crm"
DB_USER="your_db_user"
DB_PASSWORD="your_db_password"

# Create project directory
echo "📁 Creating project directory..."
mkdir -p $PROJECT_DIR
cd $PROJECT_DIR

# Clone or upload your project files
echo "📥 Uploading project files..."
# If using git:
# git clone https://github.com/yourusername/kaymarine_crm.git .
# Or upload files via FTP/SFTP

# Create virtual environment
echo "🐍 Creating virtual environment..."
python3 -m venv $VENV_PATH
source $VENV_PATH/bin/activate

# Install dependencies
echo "📦 Installing dependencies..."
pip install --upgrade pip
pip install django djangorestframework django-cors-headers
pip install psycopg2-binary gunicorn
pip install pillow python-decouple

# Install frontend dependencies
echo "🎨 Installing frontend dependencies..."
cd frontend
npm install
npm run build
cd ..

# Create production settings
echo "⚙️ Configuring production settings..."
# Copy settings_production.py to server/settings_production.py

# Create database
echo "🗄️ Creating database..."
sudo -u postgres createdb $DB_NAME
sudo -u postgres psql -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;"

# Run migrations
echo "🔄 Running migrations..."
python manage.py migrate --settings=server.settings_production

# Create superuser
echo "👤 Creating superuser..."
python manage.py createsuperuser --settings=server.settings_production

# Collect static files
echo "📁 Collecting static files..."
python manage.py collectstatic --noinput --settings=server.settings_production

# Create log directory
echo "📝 Creating log directory..."
sudo mkdir -p /var/log/kaymarine_crm
sudo chown www-data:www-data /var/log/kaymarine_crm

# Copy configuration files
echo "📋 Copying configuration files..."
sudo cp kaymarine_crm_gunicorn.conf.py /etc/gunicorn/
sudo cp kaymarine_crm_supervisor.conf /etc/supervisor/conf.d/kaymarine_crm.conf
sudo cp kaymarine_crm_nginx.conf /etc/nginx/sites-available/kaymarine_crm

# Enable nginx site
echo "🌐 Enabling nginx site..."
sudo ln -sf /etc/nginx/sites-available/kaymarine_crm /etc/nginx/sites-enabled/

# Test nginx configuration
echo "🔍 Testing nginx configuration..."
sudo nginx -t

# Reload services
echo "🔄 Reloading services..."
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start kaymarine_crm
sudo systemctl reload nginx

echo "✅ Deployment completed!"
echo "🌐 Your app should be available at: https://$DOMAIN"
echo "🔧 Admin panel: https://$DOMAIN/admin/"
echo "📊 API endpoint: https://$DOMAIN/api/"

# Show status
echo "📊 Service status:"
sudo supervisorctl status kaymarine_crm
