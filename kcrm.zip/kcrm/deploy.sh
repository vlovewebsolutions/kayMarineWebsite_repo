#!/bin/bash

# Kay Marine CRM Deployment Script
# Run this script on your VPS server to deploy the application

set -e  # Exit on error

echo "=================================="
echo "Kay Marine CRM - Deployment"
echo "=================================="

# Check if running as root or with sudo
if [ "$EUID" -eq 0 ]; then 
   echo "Please run as regular user (vinit)"
   exit 1
fi

# Set variables
PROJECT_DIR="/home/vinit/kaymarine_crm"
VENV_DIR="$PROJECT_DIR/venv"
BACKEND_DIR="$PROJECT_DIR"
FRONTEND_DIR="$PROJECT_DIR/frontend"

# Navigate to project directory
cd "$PROJECT_DIR" || exit

echo "Step 1: Activating virtual environment..."
if [ ! -d "$VENV_DIR" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate

echo "Step 2: Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo "Step 3: Running database migrations..."
python manage.py migrate

echo "Step 4: Collecting static files..."
python manage.py collectstatic --noinput

echo "Step 5: Building frontend..."
cd "$FRONTEND_DIR"
npm install
npm run build
cd "$PROJECT_DIR"

echo "Step 6: Setting permissions..."
chmod -R 755 "$PROJECT_DIR"
chown -R vinit:vinit "$PROJECT_DIR"

echo "Step 7: Configuring Supervisor..."
sudo mkdir -p /var/log/kaymarine_crm
sudo chown vinit:vinit /var/log/kaymarine_crm

echo "Step 8: Reloading services..."
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl restart kaymarine_crm

echo "Step 9: Reloading Nginx..."
sudo nginx -t
sudo systemctl reload nginx

echo ""
echo "=================================="
echo "Deployment completed successfully!"
echo "=================================="
echo ""
echo "Access your app at: https://kaymarine.com.au/crm/"
echo ""
echo "Check service status:"
echo "  sudo supervisorctl status kaymarine_crm"
echo ""
echo "View logs:"
echo "  sudo tail -f /var/log/kaymarine_crm/supervisor.log"
echo ""


