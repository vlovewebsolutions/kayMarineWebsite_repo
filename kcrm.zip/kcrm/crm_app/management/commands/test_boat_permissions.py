from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.test import RequestFactory
from django.contrib.auth import get_user_model
from crm_app.views import BoatUserSchedulePermission
from crm_app.models import DischargeForm
from django.utils import timezone
from datetime import timedelta


class Command(BaseCommand):
    help = 'Test boat user permissions for scheduling'

    def handle(self, *args, **options):
        # Get boat user
        try:
            boat_user = User.objects.get(username='boatuser')
            self.stdout.write(f'Found boat user: {boat_user.username} (is_staff: {boat_user.is_staff})')
        except User.DoesNotExist:
            self.stdout.write('❌ Boat user not found!')
            return

        # Get an order to test with
        order = DischargeForm.objects.first()
        if not order:
            self.stdout.write('❌ No orders found to test with!')
            return

        self.stdout.write(f'Testing with order: {order.ship_name} (ID: {order.id})')

        # Create a mock request factory
        factory = RequestFactory()
        
        # Test PATCH request for scheduling
        request_data = {'scheduled_offload_at': (timezone.now() + timedelta(hours=2)).isoformat()}
        request = factory.patch(f'/api/discharge-forms/{order.id}/', data=request_data, content_type='application/json')
        request.user = boat_user
        
        # Manually set the data attribute since RequestFactory doesn't do it automatically
        request.data = request_data
        
        # Test the permission
        permission = BoatUserSchedulePermission()
        
        # Test has_permission
        has_permission = permission.has_permission(request, None)
        self.stdout.write(f'SUCCESS: has_permission: {has_permission}')
        
        # Test has_object_permission
        has_object_permission = permission.has_object_permission(request, None, order)
        self.stdout.write(f'SUCCESS: has_object_permission: {has_object_permission}')
        
        # Test with admin user for comparison
        admin_user = User.objects.get(username='admin')
        request.user = admin_user
        admin_has_permission = permission.has_permission(request, None)
        admin_has_object_permission = permission.has_object_permission(request, None, order)
        self.stdout.write(f'SUCCESS: Admin has_permission: {admin_has_permission}')
        self.stdout.write(f'SUCCESS: Admin has_object_permission: {admin_has_object_permission}')
        
        # Test with forbidden fields
        request.user = boat_user
        forbidden_request_data = {'ship_name': 'Hacked Ship'}
        request = factory.patch(f'/api/discharge-forms/{order.id}/', data=forbidden_request_data, content_type='application/json')
        request.user = boat_user
        request.data = forbidden_request_data  # Manually set the data attribute
        forbidden_permission = permission.has_object_permission(request, None, order)
        self.stdout.write(f'SUCCESS: Forbidden field permission: {forbidden_permission} (should be False)')
        
        if has_permission and has_object_permission and not forbidden_permission:
            self.stdout.write('SUCCESS: Boat user permissions are working correctly!')
        else:
            self.stdout.write('ERROR: Permission logic needs adjustment')
