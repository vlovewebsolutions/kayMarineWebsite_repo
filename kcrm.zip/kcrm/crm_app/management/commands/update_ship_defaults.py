from django.core.management.base import BaseCommand
from crm_app.models import ShipDetails


class Command(BaseCommand):
    help = 'Update ShipDetails records with better default values'

    def handle(self, *args, **options):
        # Find all ShipDetails records that need updating
        ships_to_update = ShipDetails.objects.filter(
            ship_name__startswith='Ship_'
        )
        
        count = ships_to_update.count()
        self.stdout.write(f'Found {count} ShipDetails records with default names')
        
        if count == 0:
            self.stdout.write('No records need updating.')
            return
        
        updated_count = 0
        for ship in ships_to_update:
            # Update with better default values
            ship.ship_name = f"Vessel_{ship.id}"
            if not ship.port:
                ship.port = "Port Hedland"
            ship.save()
            updated_count += 1
            
            self.stdout.write(f'Updated ShipDetails {ship.id} - ship_name: {ship.ship_name}')
        
        self.stdout.write(
            self.style.SUCCESS(f'Successfully updated {updated_count} ShipDetails records')
        )
