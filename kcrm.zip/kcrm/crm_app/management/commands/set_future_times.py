from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from crm_app.models import DischargeForm


class Command(BaseCommand):
    help = 'Set proper future timestamps for Next 24h orders'

    def handle(self, *args, **options):
        self.stdout.write('Setting proper future timestamps...')
        
        now = timezone.now()
        self.stdout.write(f'Current time: {now}')
        
        # Get orders that should be in Next 24h
        next24_orders = DischargeForm.objects.filter(
            ship_name__in=['SS Atlantic Breeze', 'MV Indian Ocean', 'MV Last24 Ship 1']
        )
        
        # Set clear future timestamps (2, 6, and 12 hours from now)
        future_times = [
            now + timedelta(hours=2),   # 2 hours from now
            now + timedelta(hours=6),   # 6 hours from now  
            now + timedelta(hours=12),  # 12 hours from now
        ]
        
        for i, order in enumerate(next24_orders):
            order.scheduled_offload_at = future_times[i]
            order.actual_offload_at = None  # Ensure no actual time
            order.save()
            
            hours_from_now = [2, 6, 12][i]
            self.stdout.write(f'✅ {order.ship_name}: Scheduled in {hours_from_now}h ({order.scheduled_offload_at})')
        
        # Verify the data
        self.stdout.write(f'\n🔍 Verification:')
        for order in next24_orders:
            is_future = order.scheduled_offload_at > now
            self.stdout.write(f'{order.ship_name}: {order.scheduled_offload_at} (Future: {is_future})')
        
        # Check Next 24h count
        next_24h_count = DischargeForm.objects.filter(
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        ).count()
        
        self.stdout.write(f'\n📊 Next 24h orders count: {next_24h_count}')
        
        if next_24h_count == 3:
            self.stdout.write('🎉 SUCCESS: All 3 orders are properly scheduled for next 24h!')
        else:
            self.stdout.write(f'❌ ERROR: Expected 3, got {next_24h_count}')
