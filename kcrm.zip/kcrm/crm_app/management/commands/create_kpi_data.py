from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import datetime, timedelta
from crm_app.models import DischargeForm, VesselPlan, VesselPlanType
from decimal import Decimal


class Command(BaseCommand):
    help = 'Create additional sample data for KPI, Last 24h, and Next 24h testing'

    def handle(self, *args, **options):
        self.stdout.write('Creating additional test data for KPI testing...')

        now = timezone.now()
        
        # Create orders for Last 24 Hours (completed orders)
        self.stdout.write('Creating Last 24 Hours orders...')
        
        # Order completed 2 hours ago
        order_l24_1 = DischargeForm.objects.create(
            ship_name='MV Last24 Ship 1',
            berth='Berth 6',
            date=(now - timedelta(hours=2)).date(),
            port='Port Hedland',
            flag='Bahamas',
            vessel_type='Bulk Carrier',
            imo_no='IMO1111111',
            time=(now - timedelta(hours=2)).time(),
            eta=now - timedelta(hours=26),
            etb=now - timedelta(hours=25),
            biosecurity_status='approved',
            govt_status='approved',
            form44_submitted=True,
            documentation_complete=True,
            incident_occurred=False,
            customer_rating=5,
            total_amount=Decimal('1800.00'),
            bio_witness=True,
            landfill_booked=True,
            discharge_certificate_created=True,
            aa_storage=False,
            actual_offload_at=now - timedelta(hours=2),
            scheduled_offload_at=now - timedelta(hours=3),
            ppa_supplied_volume_m3=Decimal('8.5'),
            used_volume_m3=Decimal('8.2')
        )

        VesselPlan.objects.create(
            discharge_form=order_l24_1,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('2.1'),
            cat_c_domestic_waste=Decimal('1.5'),
            cat_e_incinerator_ashes=Decimal('0.4'),
            cat_f_operational_waste=Decimal('1.0'),
            cat_g_cargo_residue=Decimal('0.8'),
            cat_i_fishing_gear=Decimal('0.3'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=False
        )

        # Order completed 8 hours ago
        order_l24_2 = DischargeForm.objects.create(
            ship_name='MV Last24 Ship 2',
            berth='Berth 7',
            date=(now - timedelta(hours=8)).date(),
            port='Port Hedland',
            flag='Cyprus',
            vessel_type='Container Ship',
            imo_no='IMO2222222',
            time=(now - timedelta(hours=8)).time(),
            eta=now - timedelta(hours=32),
            etb=now - timedelta(hours=31),
            biosecurity_status='approved',
            govt_status='approved',
            form44_submitted=True,
            documentation_complete=True,
            incident_occurred=False,
            customer_rating=4,
            total_amount=Decimal('2200.00'),
            bio_witness=True,
            landfill_booked=True,
            discharge_certificate_created=True,
            aa_storage=True,
            actual_offload_at=now - timedelta(hours=8),
            scheduled_offload_at=now - timedelta(hours=9),
            ppa_supplied_volume_m3=Decimal('12.3'),
            used_volume_m3=Decimal('11.8')
        )

        VesselPlan.objects.create(
            discharge_form=order_l24_2,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('3.5'),
            cat_c_domestic_waste=Decimal('2.2'),
            cat_e_incinerator_ashes=Decimal('0.6'),
            cat_f_operational_waste=Decimal('1.8'),
            cat_g_cargo_residue=Decimal('1.2'),
            cat_i_fishing_gear=Decimal('0.5'),
            cat_j_other_e_waste=Decimal('0.2'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order_l24_2,
            plan_type=VesselPlanType.ADDITIONAL,
            cat_a_plastic=Decimal('1.2'),
            cat_c_domestic_waste=Decimal('0.8'),
            cat_e_incinerator_ashes=Decimal('0.2'),
            cat_f_operational_waste=Decimal('0.5'),
            cat_g_cargo_residue=Decimal('0.3'),
            cat_i_fishing_gear=Decimal('0.1'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        # Order completed 18 hours ago
        order_l24_3 = DischargeForm.objects.create(
            ship_name='MV Last24 Ship 3',
            berth='Berth 8',
            date=(now - timedelta(hours=18)).date(),
            port='Port Hedland',
            flag='Greece',
            vessel_type='Tanker',
            imo_no='IMO3333333',
            time=(now - timedelta(hours=18)).time(),
            eta=now - timedelta(hours=42),
            etb=now - timedelta(hours=41),
            biosecurity_status='approved',
            govt_status='approved',
            form44_submitted=True,
            documentation_complete=True,
            incident_occurred=True,
            customer_rating=3,
            total_amount=Decimal('3500.00'),
            bio_witness=True,
            landfill_booked=True,
            discharge_certificate_created=True,
            aa_storage=False,
            actual_offload_at=now - timedelta(hours=18),
            scheduled_offload_at=now - timedelta(hours=19),
            ppa_supplied_volume_m3=Decimal('15.7'),
            used_volume_m3=Decimal('15.1')
        )

        VesselPlan.objects.create(
            discharge_form=order_l24_3,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('4.2'),
            cat_c_domestic_waste=Decimal('2.8'),
            cat_e_incinerator_ashes=Decimal('0.8'),
            cat_f_operational_waste=Decimal('2.1'),
            cat_g_cargo_residue=Decimal('1.5'),
            cat_i_fishing_gear=Decimal('0.6'),
            cat_j_other_e_waste=Decimal('0.3'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order_l24_3,
            plan_type=VesselPlanType.SERVICE_PURCHASE,
            cat_a_plastic=Decimal('1.8'),
            cat_c_domestic_waste=Decimal('1.2'),
            cat_e_incinerator_ashes=Decimal('0.3'),
            cat_f_operational_waste=Decimal('0.8'),
            cat_g_cargo_residue=Decimal('0.6'),
            cat_i_fishing_gear=Decimal('0.2'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        # Create orders for Next 24 Hours (scheduled orders)
        self.stdout.write('Creating Next 24 Hours orders...')
        
        # Order scheduled in 4 hours
        order_n24_1 = DischargeForm.objects.create(
            ship_name='MV Next24 Ship 1',
            berth='Berth 9',
            date=(now + timedelta(hours=4)).date(),
            port='Port Hedland',
            flag='Norway',
            vessel_type='General Cargo',
            imo_no='IMO4444444',
            time=(now + timedelta(hours=4)).time(),
            eta=now + timedelta(hours=2),
            etb=now + timedelta(hours=3),
            biosecurity_status='approved',
            govt_status='pending',
            form44_submitted=True,
            documentation_complete=False,
            incident_occurred=False,
            customer_rating=None,
            total_amount=Decimal('2800.00'),
            bio_witness=False,
            landfill_booked=False,
            discharge_certificate_created=False,
            aa_storage=False,
            scheduled_offload_at=now + timedelta(hours=4)
        )

        VesselPlan.objects.create(
            discharge_form=order_n24_1,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('3.8'),
            cat_c_domestic_waste=Decimal('2.5'),
            cat_e_incinerator_ashes=Decimal('0.7'),
            cat_f_operational_waste=Decimal('1.9'),
            cat_g_cargo_residue=Decimal('1.3'),
            cat_i_fishing_gear=Decimal('0.5'),
            cat_j_other_e_waste=Decimal('0.3'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order_n24_1,
            plan_type=VesselPlanType.ADDITIONAL,
            cat_a_plastic=Decimal('1.5'),
            cat_c_domestic_waste=Decimal('1.0'),
            cat_e_incinerator_ashes=Decimal('0.3'),
            cat_f_operational_waste=Decimal('0.7'),
            cat_g_cargo_residue=Decimal('0.5'),
            cat_i_fishing_gear=Decimal('0.2'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        # Order scheduled in 12 hours
        order_n24_2 = DischargeForm.objects.create(
            ship_name='MV Next24 Ship 2',
            berth='Berth 10',
            date=(now + timedelta(hours=12)).date(),
            port='Port Hedland',
            flag='Denmark',
            vessel_type='Bulk Carrier',
            imo_no='IMO5555555',
            time=(now + timedelta(hours=12)).time(),
            eta=now + timedelta(hours=10),
            etb=now + timedelta(hours=11),
            biosecurity_status='pending',
            govt_status='pending',
            form44_submitted=False,
            documentation_complete=False,
            incident_occurred=False,
            customer_rating=None,
            total_amount=Decimal('4200.00'),
            bio_witness=False,
            landfill_booked=False,
            discharge_certificate_created=False,
            aa_storage=False,
            scheduled_offload_at=now + timedelta(hours=12)
        )

        VesselPlan.objects.create(
            discharge_form=order_n24_2,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('5.2'),
            cat_c_domestic_waste=Decimal('3.5'),
            cat_e_incinerator_ashes=Decimal('1.0'),
            cat_f_operational_waste=Decimal('2.5'),
            cat_g_cargo_residue=Decimal('1.8'),
            cat_i_fishing_gear=Decimal('0.7'),
            cat_j_other_e_waste=Decimal('0.4'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order_n24_2,
            plan_type=VesselPlanType.SERVICE_PURCHASE,
            cat_a_plastic=Decimal('2.1'),
            cat_c_domestic_waste=Decimal('1.4'),
            cat_e_incinerator_ashes=Decimal('0.4'),
            cat_f_operational_waste=Decimal('1.0'),
            cat_g_cargo_residue=Decimal('0.7'),
            cat_i_fishing_gear=Decimal('0.3'),
            cat_j_other_e_waste=Decimal('0.2'),
            dispose_additional_waste=True
        )

        # Order scheduled in 20 hours
        order_n24_3 = DischargeForm.objects.create(
            ship_name='MV Next24 Ship 3',
            berth='Berth 11',
            date=(now + timedelta(hours=20)).date(),
            port='Port Hedland',
            flag='Netherlands',
            vessel_type='Container Ship',
            imo_no='IMO6666666',
            time=(now + timedelta(hours=20)).time(),
            eta=now + timedelta(hours=18),
            etb=now + timedelta(hours=19),
            biosecurity_status='approved',
            govt_status='approved',
            form44_submitted=True,
            documentation_complete=True,
            incident_occurred=False,
            customer_rating=None,
            total_amount=Decimal('3100.00'),
            bio_witness=False,
            landfill_booked=False,
            discharge_certificate_created=False,
            aa_storage=True,
            scheduled_offload_at=now + timedelta(hours=20)
        )

        VesselPlan.objects.create(
            discharge_form=order_n24_3,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('4.5'),
            cat_c_domestic_waste=Decimal('3.0'),
            cat_e_incinerator_ashes=Decimal('0.8'),
            cat_f_operational_waste=Decimal('2.2'),
            cat_g_cargo_residue=Decimal('1.6'),
            cat_i_fishing_gear=Decimal('0.6'),
            cat_j_other_e_waste=Decimal('0.3'),
            dispose_additional_waste=False
        )

        # Create some older orders for KPI testing (beyond 24 hours)
        self.stdout.write('Creating older orders for KPI testing...')
        
        # Order from 3 days ago
        order_old_1 = DischargeForm.objects.create(
            ship_name='MV Old Ship 1',
            berth='Berth 12',
            date=(now - timedelta(days=3)).date(),
            port='Port Hedland',
            flag='Italy',
            vessel_type='Tanker',
            imo_no='IMO7777777',
            time=(now - timedelta(days=3)).time(),
            eta=now - timedelta(days=3, hours=2),
            etb=now - timedelta(days=3, hours=1),
            biosecurity_status='approved',
            govt_status='approved',
            form44_submitted=True,
            documentation_complete=True,
            incident_occurred=False,
            customer_rating=4,
            total_amount=Decimal('2600.00'),
            bio_witness=True,
            landfill_booked=True,
            discharge_certificate_created=True,
            aa_storage=False,
            actual_offload_at=now - timedelta(days=3),
            scheduled_offload_at=now - timedelta(days=3, hours=1),
            ppa_supplied_volume_m3=Decimal('11.2'),
            used_volume_m3=Decimal('10.8')
        )

        VesselPlan.objects.create(
            discharge_form=order_old_1,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('3.2'),
            cat_c_domestic_waste=Decimal('2.1'),
            cat_e_incinerator_ashes=Decimal('0.6'),
            cat_f_operational_waste=Decimal('1.7'),
            cat_g_cargo_residue=Decimal('1.2'),
            cat_i_fishing_gear=Decimal('0.4'),
            cat_j_other_e_waste=Decimal('0.2'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order_old_1,
            plan_type=VesselPlanType.ADDITIONAL,
            cat_a_plastic=Decimal('1.8'),
            cat_c_domestic_waste=Decimal('1.2'),
            cat_e_incinerator_ashes=Decimal('0.3'),
            cat_f_operational_waste=Decimal('0.8'),
            cat_g_cargo_residue=Decimal('0.6'),
            cat_i_fishing_gear=Decimal('0.2'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        # Order from 1 week ago
        order_old_2 = DischargeForm.objects.create(
            ship_name='MV Old Ship 2',
            berth='Berth 13',
            date=(now - timedelta(days=7)).date(),
            port='Port Hedland',
            flag='Spain',
            vessel_type='General Cargo',
            imo_no='IMO8888888',
            time=(now - timedelta(days=7)).time(),
            eta=now - timedelta(days=7, hours=2),
            etb=now - timedelta(days=7, hours=1),
            biosecurity_status='approved',
            govt_status='approved',
            form44_submitted=True,
            documentation_complete=True,
            incident_occurred=False,
            customer_rating=5,
            total_amount=Decimal('1900.00'),
            bio_witness=True,
            landfill_booked=True,
            discharge_certificate_created=True,
            aa_storage=True,
            actual_offload_at=now - timedelta(days=7),
            scheduled_offload_at=now - timedelta(days=7, hours=1),
            ppa_supplied_volume_m3=Decimal('8.9'),
            used_volume_m3=Decimal('8.5')
        )

        VesselPlan.objects.create(
            discharge_form=order_old_2,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('2.8'),
            cat_c_domestic_waste=Decimal('1.9'),
            cat_e_incinerator_ashes=Decimal('0.5'),
            cat_f_operational_waste=Decimal('1.4'),
            cat_g_cargo_residue=Decimal('1.0'),
            cat_i_fishing_gear=Decimal('0.3'),
            cat_j_other_e_waste=Decimal('0.2'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order_old_2,
            plan_type=VesselPlanType.SERVICE_PURCHASE,
            cat_a_plastic=Decimal('1.2'),
            cat_c_domestic_waste=Decimal('0.8'),
            cat_e_incinerator_ashes=Decimal('0.2'),
            cat_f_operational_waste=Decimal('0.6'),
            cat_g_cargo_residue=Decimal('0.4'),
            cat_i_fishing_gear=Decimal('0.1'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        self.stdout.write(
            self.style.SUCCESS('Successfully created additional test data!')
        )
        
        # Display summary
        total_orders = DischargeForm.objects.count()
        total_plans = VesselPlan.objects.count()
        
        # Count orders by time period
        last_24h = DischargeForm.objects.filter(
            actual_offload_at__gte=now - timedelta(hours=24),
            actual_offload_at__lte=now
        ).count()
        
        next_24h = DischargeForm.objects.filter(
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        ).count()
        
        self.stdout.write(f'\nSummary:')
        self.stdout.write(f'- Total Orders: {total_orders}')
        self.stdout.write(f'- Total Vessel Plans: {total_plans}')
        self.stdout.write(f'- Last 24 Hours Orders: {last_24h}')
        self.stdout.write(f'- Next 24 Hours Orders: {next_24h}')
        
        # Show some examples
        self.stdout.write(f'\nLast 24 Hours Examples:')
        for order in DischargeForm.objects.filter(
            actual_offload_at__gte=now - timedelta(hours=24),
            actual_offload_at__lte=now
        ):
            self.stdout.write(f'- {order.ship_name}: {order.total_volume}m³ (Completed {order.actual_offload_at.strftime("%H:%M")})')
        
        self.stdout.write(f'\nNext 24 Hours Examples:')
        for order in DischargeForm.objects.filter(
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        ):
            self.stdout.write(f'- {order.ship_name}: {order.total_volume}m³ (Scheduled {order.scheduled_offload_at.strftime("%H:%M")})')
