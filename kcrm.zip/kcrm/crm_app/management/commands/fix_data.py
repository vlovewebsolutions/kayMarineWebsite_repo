from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from crm_app.models import DischargeForm


class Command(BaseCommand):
    help = 'Fix data by clearing overlapping timestamps'

    def handle(self, *args, **options):
        self.stdout.write('Fixing overlapping timestamp data...')
        
        # Clear all actual_offload_at and scheduled_offload_at to start fresh
        DischargeForm.objects.all().update(
            actual_offload_at=None,
            scheduled_offload_at=None
        )
        
        self.stdout.write('Cleared all timestamps. Creating proper test data...')
        
        now = timezone.now()
        
        # Get all orders
        orders = list(DischargeForm.objects.all())
        
        # Set Last 24h orders (completed orders)
        last_24h_orders = orders[:3]  # First 3 orders
        for i, order in enumerate(last_24h_orders):
            hours_ago = [2, 8, 18][i]  # Different completion times
            order.actual_offload_at = now - timedelta(hours=hours_ago)
            order.scheduled_offload_at = now - timedelta(hours=hours_ago + 1)  # Was scheduled 1 hour before completion
            order.save()
            self.stdout.write(f'Set {order.ship_name} as completed {hours_ago}h ago')
        
        # Set Next 24h orders (scheduled orders)
        next_24h_orders = orders[3:6]  # Next 3 orders
        for i, order in enumerate(next_24h_orders):
            hours_from_now = [4, 12, 20][i]  # Different scheduled times
            order.scheduled_offload_at = now + timedelta(hours=hours_from_now)
            order.actual_offload_at = None  # Not completed yet
            order.save()
            self.stdout.write(f'Set {order.ship_name} as scheduled in {hours_from_now}h')
        
        # Set remaining orders as older orders (no timestamps)
        remaining_orders = orders[6:]
        for order in remaining_orders:
            order.actual_offload_at = None
            order.scheduled_offload_at = None
            order.save()
            self.stdout.write(f'Set {order.ship_name} as historical order')
        
        self.stdout.write('✅ Data fixed successfully!')
        
        # Verify the fix
        last_24h_count = DischargeForm.objects.filter(
            actual_offload_at__gte=now - timedelta(hours=24),
            actual_offload_at__lte=now
        ).count()
        
        next_24h_count = DischargeForm.objects.filter(
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        ).count()
        
        self.stdout.write(f'\nVerification:')
        self.stdout.write(f'- Last 24h orders: {last_24h_count}')
        self.stdout.write(f'- Next 24h orders: {next_24h_count}')
        
        # Check for overlaps
        overlapping = DischargeForm.objects.filter(
            actual_offload_at__gte=now - timedelta(hours=24),
            actual_offload_at__lte=now,
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        ).count()
        
        if overlapping == 0:
            self.stdout.write('✅ No overlapping orders found!')
        else:
            self.stdout.write(f'⚠️  Still {overlapping} overlapping orders')
