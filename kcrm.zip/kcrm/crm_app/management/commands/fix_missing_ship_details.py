from django.core.management.base import BaseCommand
from crm_app.models import DischargeForm, ShipDetails


class Command(BaseCommand):
    help = 'Fix DischargeForm records that are missing ship_details'

    def handle(self, *args, **options):
        # Find all DischargeForm records without ship_details
        forms_without_ship = DischargeForm.objects.filter(ship_details__isnull=True)
        
        count = forms_without_ship.count()
        self.stdout.write(f'Found {count} DischargeForm records without ship_details')
        
        if count == 0:
            self.stdout.write('No records need fixing.')
            return
        
        fixed_count = 0
        for form in forms_without_ship:
            # Create a ShipDetails record for this form
            ship_details = ShipDetails.objects.create(
                ship_name=f"Ship_{form.id}",  # Default name
                port="Port Hedland",
                # Other fields will be null/blank
            )
            form.ship_details = ship_details
            form.save()
            fixed_count += 1
            
            self.stdout.write(f'Fixed DischargeForm {form.id} - created ShipDetails {ship_details.id}')
        
        self.stdout.write(
            self.style.SUCCESS(f'Successfully fixed {fixed_count} DischargeForm records')
        )
