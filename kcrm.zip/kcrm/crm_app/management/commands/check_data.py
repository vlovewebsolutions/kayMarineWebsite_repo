from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from crm_app.models import DischargeForm


class Command(BaseCommand):
    help = 'Check data for overlapping Last 24h and Next 24h orders'

    def handle(self, *args, **options):
        now = timezone.now()
        self.stdout.write(f'Current time: {now}')
        
        # Check Last 24h orders
        last_24h_orders = DischargeForm.objects.filter(
            actual_offload_at__gte=now - timedelta(hours=24),
            actual_offload_at__lte=now
        )
        
        self.stdout.write(f'\nLast 24h orders ({last_24h_orders.count()}):')
        for order in last_24h_orders:
            self.stdout.write(f'  {order.ship_name}: actual_offload_at={order.actual_offload_at}')
        
        # Check Next 24h orders
        next_24h_orders = DischargeForm.objects.filter(
            scheduled_offload_at__gte=now,
            scheduled_offload_at__lte=now + timedelta(hours=24)
        )
        
        self.stdout.write(f'\nNext 24h orders ({next_24h_orders.count()}):')
        for order in next_24h_orders:
            self.stdout.write(f'  {order.ship_name}: scheduled_offload_at={order.scheduled_offload_at}')
        
        # Check for overlapping orders
        overlapping = []
        for last_order in last_24h_orders:
            for next_order in next_24h_orders:
                if last_order.id == next_order.id:
                    overlapping.append(last_order)
        
        if overlapping:
            self.stdout.write(f'\n⚠️  OVERLAPPING ORDERS FOUND ({len(overlapping)}):')
            for order in overlapping:
                self.stdout.write(f'  {order.ship_name}: actual={order.actual_offload_at}, scheduled={order.scheduled_offload_at}')
        else:
            self.stdout.write(f'\n✅ No overlapping orders found')
