from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import datetime, timedelta
from crm_app.models import DischargeForm, VesselPlan, VesselPlanType
from decimal import Decimal
import random


class Command(BaseCommand):
    help = 'Create sample discharge orders with vessel plans for testing'

    def add_arguments(self, parser):
        parser.add_argument(
            '--count',
            type=int,
            default=10,
            help='Number of discharge orders to create (default: 10)',
        )
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Clear existing data before creating new data',
        )

    def handle(self, *args, **options):
        count = options['count']
        clear_existing = options['clear']

        if clear_existing:
            self.stdout.write('Clearing existing data...')
            DischargeForm.objects.all().delete()
            self.stdout.write(self.style.SUCCESS('Existing data cleared'))

        # Sample vessel data
        vessels = [
            {
                'ship_name': 'MV Ocean Explorer',
                'berth': 'Berth 1',
                'port': 'Port Hedland',
                'flag': 'Panama',
                'vessel_type': 'Bulk Carrier',
                'imo_no': 'IMO1234567'
            },
            {
                'ship_name': 'SS Maritime Star',
                'berth': 'Berth 2',
                'port': 'Port Hedland',
                'flag': 'Liberia',
                'vessel_type': 'Container Ship',
                'imo_no': 'IMO2345678'
            },
            {
                'ship_name': 'MV Pacific Wave',
                'berth': 'Berth 3',
                'port': 'Port Hedland',
                'flag': 'Marshall Islands',
                'vessel_type': 'Tanker',
                'imo_no': 'IMO3456789'
            },
            {
                'ship_name': 'SS Atlantic Breeze',
                'berth': 'Berth 4',
                'port': 'Port Hedland',
                'flag': 'Singapore',
                'vessel_type': 'General Cargo',
                'imo_no': 'IMO4567890'
            },
            {
                'ship_name': 'MV Indian Ocean',
                'berth': 'Berth 5',
                'port': 'Port Hedland',
                'flag': 'Malta',
                'vessel_type': 'Bulk Carrier',
                'imo_no': 'IMO5678901'
            }
        ]

        # Sample waste quantities for different plan types
        normal_quantities = [
            {'cat_a_plastic': Decimal('2.5'), 'cat_c_domestic_waste': Decimal('1.8'), 'cat_e_incinerator_ashes': Decimal('0.5'), 'cat_f_operational_waste': Decimal('1.2'), 'cat_g_cargo_residue': Decimal('0.8'), 'cat_i_fishing_gear': Decimal('0.3'), 'cat_j_other_e_waste': Decimal('0.2')},
            {'cat_a_plastic': Decimal('3.2'), 'cat_c_domestic_waste': Decimal('2.1'), 'cat_e_incinerator_ashes': Decimal('0.7'), 'cat_f_operational_waste': Decimal('1.5'), 'cat_g_cargo_residue': Decimal('1.0'), 'cat_i_fishing_gear': Decimal('0.4'), 'cat_j_other_e_waste': Decimal('0.3')},
            {'cat_a_plastic': Decimal('1.8'), 'cat_c_domestic_waste': Decimal('1.5'), 'cat_e_incinerator_ashes': Decimal('0.3'), 'cat_f_operational_waste': Decimal('0.9'), 'cat_g_cargo_residue': Decimal('0.6'), 'cat_i_fishing_gear': Decimal('0.2'), 'cat_j_other_e_waste': Decimal('0.1')},
            {'cat_a_plastic': Decimal('4.1'), 'cat_c_domestic_waste': Decimal('2.8'), 'cat_e_incinerator_ashes': Decimal('0.9'), 'cat_f_operational_waste': Decimal('1.8'), 'cat_g_cargo_residue': Decimal('1.3'), 'cat_i_fishing_gear': Decimal('0.6'), 'cat_j_other_e_waste': Decimal('0.4')},
            {'cat_a_plastic': Decimal('2.9'), 'cat_c_domestic_waste': Decimal('2.0'), 'cat_e_incinerator_ashes': Decimal('0.6'), 'cat_f_operational_waste': Decimal('1.3'), 'cat_g_cargo_residue': Decimal('0.9'), 'cat_i_fishing_gear': Decimal('0.3'), 'cat_j_other_e_waste': Decimal('0.2')}
        ]

        additional_quantities = [
            {'cat_a_plastic': Decimal('1.2'), 'cat_c_domestic_waste': Decimal('0.8'), 'cat_e_incinerator_ashes': Decimal('0.2'), 'cat_f_operational_waste': Decimal('0.5'), 'cat_g_cargo_residue': Decimal('0.3'), 'cat_i_fishing_gear': Decimal('0.1'), 'cat_j_other_e_waste': Decimal('0.1')},
            {'cat_a_plastic': Decimal('1.8'), 'cat_c_domestic_waste': Decimal('1.2'), 'cat_e_incinerator_ashes': Decimal('0.3'), 'cat_f_operational_waste': Decimal('0.7'), 'cat_g_cargo_residue': Decimal('0.5'), 'cat_i_fishing_gear': Decimal('0.2'), 'cat_j_other_e_waste': Decimal('0.1')},
            {'cat_a_plastic': Decimal('0.9'), 'cat_c_domestic_waste': Decimal('0.6'), 'cat_e_incinerator_ashes': Decimal('0.1'), 'cat_f_operational_waste': Decimal('0.4'), 'cat_g_cargo_residue': Decimal('0.3'), 'cat_i_fishing_gear': Decimal('0.1'), 'cat_j_other_e_waste': Decimal('0.0')},
            {'cat_a_plastic': Decimal('2.1'), 'cat_c_domestic_waste': Decimal('1.4'), 'cat_e_incinerator_ashes': Decimal('0.4'), 'cat_f_operational_waste': Decimal('0.8'), 'cat_g_cargo_residue': Decimal('0.6'), 'cat_i_fishing_gear': Decimal('0.3'), 'cat_j_other_e_waste': Decimal('0.2')},
            {'cat_a_plastic': Decimal('1.5'), 'cat_c_domestic_waste': Decimal('1.0'), 'cat_e_incinerator_ashes': Decimal('0.3'), 'cat_f_operational_waste': Decimal('0.6'), 'cat_g_cargo_residue': Decimal('0.4'), 'cat_i_fishing_gear': Decimal('0.2'), 'cat_j_other_e_waste': Decimal('0.1')}
        ]

        service_quantities = [
            {'cat_a_plastic': Decimal('0.8'), 'cat_c_domestic_waste': Decimal('0.5'), 'cat_e_incinerator_ashes': Decimal('0.1'), 'cat_f_operational_waste': Decimal('0.3'), 'cat_g_cargo_residue': Decimal('0.2'), 'cat_i_fishing_gear': Decimal('0.1'), 'cat_j_other_e_waste': Decimal('0.0')},
            {'cat_a_plastic': Decimal('1.2'), 'cat_c_domestic_waste': Decimal('0.8'), 'cat_e_incinerator_ashes': Decimal('0.2'), 'cat_f_operational_waste': Decimal('0.5'), 'cat_g_cargo_residue': Decimal('0.3'), 'cat_i_fishing_gear': Decimal('0.1'), 'cat_j_other_e_waste': Decimal('0.1')},
            {'cat_a_plastic': Decimal('0.6'), 'cat_c_domestic_waste': Decimal('0.4'), 'cat_e_incinerator_ashes': Decimal('0.1'), 'cat_f_operational_waste': Decimal('0.2'), 'cat_g_cargo_residue': Decimal('0.2'), 'cat_i_fishing_gear': Decimal('0.0'), 'cat_j_other_e_waste': Decimal('0.0')},
            {'cat_a_plastic': Decimal('1.5'), 'cat_c_domestic_waste': Decimal('1.0'), 'cat_e_incinerator_ashes': Decimal('0.3'), 'cat_f_operational_waste': Decimal('0.6'), 'cat_g_cargo_residue': Decimal('0.4'), 'cat_i_fishing_gear': Decimal('0.2'), 'cat_j_other_e_waste': Decimal('0.1')},
            {'cat_a_plastic': Decimal('1.0'), 'cat_c_domestic_waste': Decimal('0.7'), 'cat_e_incinerator_ashes': Decimal('0.2'), 'cat_f_operational_waste': Decimal('0.4'), 'cat_g_cargo_residue': Decimal('0.3'), 'cat_i_fishing_gear': Decimal('0.1'), 'cat_j_other_e_waste': Decimal('0.1')}
        ]

        self.stdout.write(f'Creating {count} discharge orders with vessel plans...')

        for i in range(count):
            # Select random vessel data
            vessel_data = random.choice(vessels)
            vessel_index = vessels.index(vessel_data)
            
            # Create dates (some in past, some in future)
            base_date = timezone.now().date()
            if i < count // 2:
                # Past orders
                order_date = base_date - timedelta(days=random.randint(1, 30))
            else:
                # Future orders
                order_date = base_date + timedelta(days=random.randint(1, 30))

            # Create discharge form
            discharge_form = DischargeForm.objects.create(
                ship_name=vessel_data['ship_name'],
                berth=vessel_data['berth'],
                date=order_date,
                port=vessel_data['port'],
                flag=vessel_data['flag'],
                vessel_type=vessel_data['vessel_type'],
                imo_no=vessel_data['imo_no'],
                time=timezone.now().time(),
                eta=timezone.now() + timedelta(hours=random.randint(1, 48)),
                etb=timezone.now() + timedelta(hours=random.randint(2, 72)),
                biosecurity_status=random.choice(['pending', 'approved', 'rejected']),
                govt_status=random.choice(['pending', 'approved', 'rejected']),
                form44_submitted=random.choice([True, False]),
                documentation_complete=random.choice([True, False]),
                incident_occurred=random.choice([True, False]),
                customer_rating=random.randint(1, 5) if random.choice([True, False]) else None,
                total_amount=Decimal(str(random.uniform(500, 5000))).quantize(Decimal('0.01')),
                bio_witness=random.choice([True, False]),
                landfill_booked=random.choice([True, False]),
                discharge_certificate_created=random.choice([True, False]),
                aa_storage=random.choice([True, False])
            )

            # Create vessel plans
            plan_types_to_create = [VesselPlanType.NORMAL]
            
            # Randomly add additional and service purchase plans
            if random.choice([True, False]):
                plan_types_to_create.append(VesselPlanType.ADDITIONAL)
            if random.choice([True, False]):
                plan_types_to_create.append(VesselPlanType.SERVICE_PURCHASE)

            for plan_type in plan_types_to_create:
                if plan_type == VesselPlanType.NORMAL:
                    quantities = normal_quantities[vessel_index]
                elif plan_type == VesselPlanType.ADDITIONAL:
                    quantities = additional_quantities[vessel_index]
                else:  # SERVICE_PURCHASE
                    quantities = service_quantities[vessel_index]

                VesselPlan.objects.create(
                    discharge_form=discharge_form,
                    plan_type=plan_type,
                    dispose_additional_waste=plan_type != VesselPlanType.NORMAL,
                    **quantities
                )

            self.stdout.write(f'Created order {i+1}: {discharge_form.ship_name} - {discharge_form.date}')

        self.stdout.write(
            self.style.SUCCESS(
                f'Successfully created {count} discharge orders with vessel plans!'
            )
        )
        
        # Display summary
        total_orders = DischargeForm.objects.count()
        total_plans = VesselPlan.objects.count()
        normal_plans = VesselPlan.objects.filter(plan_type=VesselPlanType.NORMAL).count()
        additional_plans = VesselPlan.objects.filter(plan_type=VesselPlanType.ADDITIONAL).count()
        service_plans = VesselPlan.objects.filter(plan_type=VesselPlanType.SERVICE_PURCHASE).count()
        
        self.stdout.write(f'\nSummary:')
        self.stdout.write(f'- Total Orders: {total_orders}')
        self.stdout.write(f'- Total Vessel Plans: {total_plans}')
        self.stdout.write(f'- Normal Plans: {normal_plans}')
        self.stdout.write(f'- Additional Plans: {additional_plans}')
        self.stdout.write(f'- Service Purchase Plans: {service_plans}')
