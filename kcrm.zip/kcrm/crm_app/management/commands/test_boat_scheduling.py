from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.test import Client
from crm_app.models import DischargeForm
from django.utils import timezone
from datetime import timedelta
import json
from rest_framework_simplejwt.tokens import RefreshToken


class Command(BaseCommand):
    help = 'Test boat user scheduling functionality'

    def handle(self, *args, **options):
        # Get boat user
        try:
            boat_user = User.objects.get(username='boatuser')
            self.stdout.write(f'Found boat user: {boat_user.username}')
        except User.DoesNotExist:
            self.stdout.write('❌ Boat user not found!')
            return

        # Get an order to test with
        order = DischargeForm.objects.first()
        if not order:
            self.stdout.write('❌ No orders found to test with!')
            return

        self.stdout.write(f'Testing with order: {order.ship_name} (ID: {order.id})')

        # Create a test client
        client = Client()

        # Generate JWT token for boat user
        refresh = RefreshToken.for_user(boat_user)
        access_token = str(refresh.access_token)
        
        self.stdout.write('SUCCESS: Generated JWT token for boat user')

        # Test scheduling update
        new_schedule_time = timezone.now() + timedelta(hours=3)
        schedule_data = {
            'scheduled_offload_at': new_schedule_time.isoformat()
        }

        # Make PATCH request to update schedule
        response = client.patch(
            f'/api/discharge-forms/{order.id}/',
            data=json.dumps(schedule_data),
            content_type='application/json',
            HTTP_HOST='localhost',
            HTTP_AUTHORIZATION=f'Bearer {access_token}'
        )

        self.stdout.write(f'PATCH response status: {response.status_code}')
        
        if response.status_code == 200:
            self.stdout.write('SUCCESS: Boat user can update scheduling!')
            
            # Verify the update
            order.refresh_from_db()
            self.stdout.write(f'Updated scheduled_offload_at: {order.scheduled_offload_at}')
        else:
            self.stdout.write('ERROR: FAILED')
            if hasattr(response, 'content'):
                self.stdout.write(f'Response content: {response.content.decode()}')

        # Test forbidden field update
        forbidden_data = {
            'ship_name': 'Hacked Ship Name'
        }

        response = client.patch(
            f'/api/discharge-forms/{order.id}/',
            data=json.dumps(forbidden_data),
            content_type='application/json',
            HTTP_HOST='localhost',
            HTTP_AUTHORIZATION=f'Bearer {access_token}'
        )

        self.stdout.write(f'Forbidden field PATCH status: {response.status_code}')
        
        if response.status_code == 400:  # Bad request due to serializer validation
            self.stdout.write('SUCCESS: Boat user cannot update forbidden fields!')
        else:
            self.stdout.write(f'WARNING: Unexpected response for forbidden field: {response.status_code}')

        # Test GET request (should work)
        response = client.get(
            f'/api/discharge-forms/{order.id}/', 
            HTTP_HOST='localhost',
            HTTP_AUTHORIZATION=f'Bearer {access_token}'
        )
        self.stdout.write(f'GET response status: {response.status_code}')
        
        if response.status_code == 200:
            self.stdout.write('SUCCESS: Boat user can read order data!')
        else:
            self.stdout.write(f'ERROR: Boat user cannot read order data: {response.status_code}')
