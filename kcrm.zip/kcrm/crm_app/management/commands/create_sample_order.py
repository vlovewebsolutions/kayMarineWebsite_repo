from django.core.management.base import BaseCommand
from crm_app.models import DischargeForm, ShipDetails, VesselPlan
from datetime import date, time, datetime
from decimal import Decimal
from django.utils import timezone


class Command(BaseCommand):
    help = 'Create a sample discharge order with proper data'

    def handle(self, *args, **options):
        # Create ship details
        ship_details = ShipDetails.objects.create(
            ship_name="MV Pacific Star",
            berth="Berth 3",
            port="Port Hedland",
            flag="Panama",
            vessel_type="Bulk Carrier",
            imo_no="IMO1234567",
            eta=timezone.now(),
            etb=timezone.now()
        )
        
        # Create discharge form
        discharge_form = DischargeForm.objects.create(
            ship_details=ship_details,
            date=date.today(),
            time=timezone.now().time(),
            dispose_additional_waste=False,
            service_purchased=False
        )
        
        # Create vessel plan with some volume data
        vessel_plan = VesselPlan.objects.create(
            discharge_form=discharge_form,
            plan_type='free',
            cat_a_plastic=Decimal('0.5'),
            cat_c_domestic_waste=Decimal('1.2'),
            cat_e_incinerator_ashes=Decimal('0.3'),
            cat_f_operational_waste=Decimal('0.8'),
            cat_g_cargo_residue=Decimal('2.1'),
            cat_i_fishing_gear=Decimal('0.0'),
            cat_j_other_e_waste=Decimal('0.4')
        )
        
        self.stdout.write(
            self.style.SUCCESS(f'Created sample order: {discharge_form}')
        )
        self.stdout.write(f'Ship: {ship_details.ship_name}')
        self.stdout.write(f'Port: {ship_details.port}')
        self.stdout.write(f'Berth: {ship_details.berth}')
        self.stdout.write(f'Flag: {ship_details.flag}')
        self.stdout.write(f'Total Volume: {vessel_plan.total_volume} m³')
