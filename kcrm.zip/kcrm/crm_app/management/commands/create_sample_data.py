from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import datetime, timedelta
from crm_app.models import DischargeForm, VesselPlan, VesselPlanType
from decimal import Decimal


class Command(BaseCommand):
    help = 'Create sample discharge orders with vessel plans for testing'

    def handle(self, *args, **options):
        self.stdout.write('Clearing existing data...')
        DischargeForm.objects.all().delete()
        self.stdout.write('Existing data cleared')

        self.stdout.write('Creating sample orders...')

        # Create first order with all three plan types
        order1 = DischargeForm.objects.create(
            ship_name='MV Ocean Explorer',
            berth='Berth 1',
            date=timezone.now().date(),
            port='Port Hedland',
            flag='Panama',
            vessel_type='Bulk Carrier',
            imo_no='IMO1234567',
            time=timezone.now().time(),
            eta=timezone.now() + timedelta(hours=24),
            etb=timezone.now() + timedelta(hours=48),
            biosecurity_status='approved',
            govt_status='pending',
            form44_submitted=True,
            documentation_complete=False,
            incident_occurred=False,
            customer_rating=4,
            total_amount=Decimal('2500.00'),
            bio_witness=True,
            landfill_booked=False,
            discharge_certificate_created=False,
            aa_storage=False
        )

        # Create vessel plans for order1
        VesselPlan.objects.create(
            discharge_form=order1,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('2.5'),
            cat_c_domestic_waste=Decimal('1.8'),
            cat_e_incinerator_ashes=Decimal('0.5'),
            cat_f_operational_waste=Decimal('1.2'),
            cat_g_cargo_residue=Decimal('0.8'),
            cat_i_fishing_gear=Decimal('0.3'),
            cat_j_other_e_waste=Decimal('0.2'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order1,
            plan_type=VesselPlanType.ADDITIONAL,
            cat_a_plastic=Decimal('1.2'),
            cat_c_domestic_waste=Decimal('0.8'),
            cat_e_incinerator_ashes=Decimal('0.2'),
            cat_f_operational_waste=Decimal('0.5'),
            cat_g_cargo_residue=Decimal('0.3'),
            cat_i_fishing_gear=Decimal('0.1'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        VesselPlan.objects.create(
            discharge_form=order1,
            plan_type=VesselPlanType.SERVICE_PURCHASE,
            cat_a_plastic=Decimal('0.8'),
            cat_c_domestic_waste=Decimal('0.5'),
            cat_e_incinerator_ashes=Decimal('0.1'),
            cat_f_operational_waste=Decimal('0.3'),
            cat_g_cargo_residue=Decimal('0.2'),
            cat_i_fishing_gear=Decimal('0.1'),
            cat_j_other_e_waste=Decimal('0.0'),
            dispose_additional_waste=True
        )

        # Create second order with only normal plan
        order2 = DischargeForm.objects.create(
            ship_name='SS Maritime Star',
            berth='Berth 2',
            date=timezone.now().date() - timedelta(days=5),
            port='Port Hedland',
            flag='Liberia',
            vessel_type='Container Ship',
            imo_no='IMO2345678',
            time=timezone.now().time(),
            eta=timezone.now() - timedelta(hours=12),
            etb=timezone.now() - timedelta(hours=6),
            biosecurity_status='approved',
            govt_status='approved',
            form44_submitted=True,
            documentation_complete=True,
            incident_occurred=False,
            customer_rating=5,
            total_amount=Decimal('1800.00'),
            bio_witness=True,
            landfill_booked=True,
            discharge_certificate_created=True,
            aa_storage=True
        )

        VesselPlan.objects.create(
            discharge_form=order2,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('3.2'),
            cat_c_domestic_waste=Decimal('2.1'),
            cat_e_incinerator_ashes=Decimal('0.7'),
            cat_f_operational_waste=Decimal('1.5'),
            cat_g_cargo_residue=Decimal('1.0'),
            cat_i_fishing_gear=Decimal('0.4'),
            cat_j_other_e_waste=Decimal('0.3'),
            dispose_additional_waste=False
        )

        # Create third order with normal + additional plans
        order3 = DischargeForm.objects.create(
            ship_name='MV Pacific Wave',
            berth='Berth 3',
            date=timezone.now().date() + timedelta(days=3),
            port='Port Hedland',
            flag='Marshall Islands',
            vessel_type='Tanker',
            imo_no='IMO3456789',
            time=timezone.now().time(),
            eta=timezone.now() + timedelta(hours=72),
            etb=timezone.now() + timedelta(hours=96),
            biosecurity_status='pending',
            govt_status='pending',
            form44_submitted=False,
            documentation_complete=False,
            incident_occurred=False,
            customer_rating=None,
            total_amount=Decimal('3200.00'),
            bio_witness=False,
            landfill_booked=False,
            discharge_certificate_created=False,
            aa_storage=False
        )

        VesselPlan.objects.create(
            discharge_form=order3,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('1.8'),
            cat_c_domestic_waste=Decimal('1.5'),
            cat_e_incinerator_ashes=Decimal('0.3'),
            cat_f_operational_waste=Decimal('0.9'),
            cat_g_cargo_residue=Decimal('0.6'),
            cat_i_fishing_gear=Decimal('0.2'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order3,
            plan_type=VesselPlanType.ADDITIONAL,
            cat_a_plastic=Decimal('0.9'),
            cat_c_domestic_waste=Decimal('0.6'),
            cat_e_incinerator_ashes=Decimal('0.1'),
            cat_f_operational_waste=Decimal('0.4'),
            cat_g_cargo_residue=Decimal('0.3'),
            cat_i_fishing_gear=Decimal('0.1'),
            cat_j_other_e_waste=Decimal('0.0'),
            dispose_additional_waste=True
        )

        # Create fourth order with normal + service purchase plans
        order4 = DischargeForm.objects.create(
            ship_name='SS Atlantic Breeze',
            berth='Berth 4',
            date=timezone.now().date() + timedelta(days=7),
            port='Port Hedland',
            flag='Singapore',
            vessel_type='General Cargo',
            imo_no='IMO4567890',
            time=timezone.now().time(),
            eta=timezone.now() + timedelta(hours=168),
            etb=timezone.now() + timedelta(hours=192),
            biosecurity_status='approved',
            govt_status='pending',
            form44_submitted=True,
            documentation_complete=False,
            incident_occurred=True,
            customer_rating=2,
            total_amount=Decimal('4200.00'),
            bio_witness=True,
            landfill_booked=False,
            discharge_certificate_created=False,
            aa_storage=True
        )

        VesselPlan.objects.create(
            discharge_form=order4,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('4.1'),
            cat_c_domestic_waste=Decimal('2.8'),
            cat_e_incinerator_ashes=Decimal('0.9'),
            cat_f_operational_waste=Decimal('1.8'),
            cat_g_cargo_residue=Decimal('1.3'),
            cat_i_fishing_gear=Decimal('0.6'),
            cat_j_other_e_waste=Decimal('0.4'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order4,
            plan_type=VesselPlanType.SERVICE_PURCHASE,
            cat_a_plastic=Decimal('1.5'),
            cat_c_domestic_waste=Decimal('1.0'),
            cat_e_incinerator_ashes=Decimal('0.3'),
            cat_f_operational_waste=Decimal('0.6'),
            cat_g_cargo_residue=Decimal('0.4'),
            cat_i_fishing_gear=Decimal('0.2'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        # Create fifth order with all three plan types
        order5 = DischargeForm.objects.create(
            ship_name='MV Indian Ocean',
            berth='Berth 5',
            date=timezone.now().date() - timedelta(days=2),
            port='Port Hedland',
            flag='Malta',
            vessel_type='Bulk Carrier',
            imo_no='IMO5678901',
            time=timezone.now().time(),
            eta=timezone.now() - timedelta(hours=24),
            etb=timezone.now() - timedelta(hours=12),
            biosecurity_status='rejected',
            govt_status='rejected',
            form44_submitted=False,
            documentation_complete=False,
            incident_occurred=True,
            customer_rating=1,
            total_amount=Decimal('5000.00'),
            bio_witness=False,
            landfill_booked=False,
            discharge_certificate_created=False,
            aa_storage=False
        )

        VesselPlan.objects.create(
            discharge_form=order5,
            plan_type=VesselPlanType.NORMAL,
            cat_a_plastic=Decimal('2.9'),
            cat_c_domestic_waste=Decimal('2.0'),
            cat_e_incinerator_ashes=Decimal('0.6'),
            cat_f_operational_waste=Decimal('1.3'),
            cat_g_cargo_residue=Decimal('0.9'),
            cat_i_fishing_gear=Decimal('0.3'),
            cat_j_other_e_waste=Decimal('0.2'),
            dispose_additional_waste=False
        )

        VesselPlan.objects.create(
            discharge_form=order5,
            plan_type=VesselPlanType.ADDITIONAL,
            cat_a_plastic=Decimal('1.5'),
            cat_c_domestic_waste=Decimal('1.0'),
            cat_e_incinerator_ashes=Decimal('0.3'),
            cat_f_operational_waste=Decimal('0.6'),
            cat_g_cargo_residue=Decimal('0.4'),
            cat_i_fishing_gear=Decimal('0.2'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        VesselPlan.objects.create(
            discharge_form=order5,
            plan_type=VesselPlanType.SERVICE_PURCHASE,
            cat_a_plastic=Decimal('1.0'),
            cat_c_domestic_waste=Decimal('0.7'),
            cat_e_incinerator_ashes=Decimal('0.2'),
            cat_f_operational_waste=Decimal('0.4'),
            cat_g_cargo_residue=Decimal('0.3'),
            cat_i_fishing_gear=Decimal('0.1'),
            cat_j_other_e_waste=Decimal('0.1'),
            dispose_additional_waste=True
        )

        self.stdout.write(
            self.style.SUCCESS('Successfully created 5 sample discharge orders!')
        )
        
        # Display summary
        total_orders = DischargeForm.objects.count()
        total_plans = VesselPlan.objects.count()
        
        self.stdout.write(f'\nSummary:')
        self.stdout.write(f'- Total Orders: {total_orders}')
        self.stdout.write(f'- Total Vessel Plans: {total_plans}')
        
        # Show total volumes for each order
        self.stdout.write(f'\nOrder Details:')
        for order in DischargeForm.objects.all():
            self.stdout.write(f'- {order.ship_name}: Total Volume = {order.total_volume}m³')
            for plan in order.vessel_plans.all():
                self.stdout.write(f'  - {plan.get_plan_type_display()}: {plan.total_volume}m³')
