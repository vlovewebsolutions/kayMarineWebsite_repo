from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from crm_app.models import DischargeForm


class Command(BaseCommand):
    help = 'Set very clear future timestamps for testing'

    def handle(self, *args, **options):
        now = timezone.now()
        self.stdout.write(f'Current time: {now}')
        
        # Clear all timestamps first
        DischargeForm.objects.all().update(
            actual_offload_at=None,
            scheduled_offload_at=None
        )
        
        orders = list(DischargeForm.objects.all())
        
        # Set Last 24h orders (completed in the past)
        last_24h_orders = orders[:3]
        for i, order in enumerate(last_24h_orders):
            hours_ago = [2, 8, 18][i]
            order.actual_offload_at = now - timedelta(hours=hours_ago)
            order.save()
            self.stdout.write(f'✅ {order.ship_name}: COMPLETED {hours_ago}h ago')
        
        # Set Next 24h orders (scheduled for tomorrow - very clear future)
        next_24h_orders = orders[3:6]
        for i, order in enumerate(next_24h_orders):
            # Schedule for tomorrow + some hours
            tomorrow = now + timedelta(days=1)
            hours_offset = [2, 6, 12][i]
            order.scheduled_offload_at = tomorrow + timedelta(hours=hours_offset)
            order.save()
            self.stdout.write(f'✅ {order.ship_name}: SCHEDULED for tomorrow + {hours_offset}h')
        
        # Verify
        self.stdout.write(f'\n🔍 Verification:')
        self.stdout.write(f'Last 24h orders: {DischargeForm.objects.filter(actual_offload_at__isnull=False).count()}')
        self.stdout.write(f'Next 24h orders: {DischargeForm.objects.filter(scheduled_offload_at__isnull=False).count()}')
        
        # Show the actual timestamps
        self.stdout.write(f'\n📅 Next 24h orders:')
        for order in DischargeForm.objects.filter(scheduled_offload_at__isnull=False):
            is_future = order.scheduled_offload_at > now
            self.stdout.write(f'  {order.ship_name}: {order.scheduled_offload_at} (Future: {is_future})')
