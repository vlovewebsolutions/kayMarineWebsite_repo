from django.contrib import admin

# Register your models here.
from .models import ShipDetails, DischargeForm, VesselPlan, LandfillReceipt, IndependentReceipt


@admin.register(ShipDetails)
class ShipDetailsAdmin(admin.ModelAdmin):
    list_display = (
        "ship_name",
        "berth",
        "port",
        "flag",
        "vessel_type",
        "imo_no",
        "eta",
        "etb",
        "created_at",
    )
    search_fields = ("ship_name", "imo_no", "berth", "port", "flag")
    list_filter = (
        "port",
        "flag",
        "vessel_type",
        "created_at",
    )


@admin.register(DischargeForm)
class DischargeFormAdmin(admin.ModelAdmin):
    list_display = (
        "ship_name",
        "date",
        "dispose_additional_waste",
        "service_purchased",
        "ship_wants_to_discharge_more",
        "garbage_remaining_on_board_m3",
        "docs_complete",
        "invoice_created",
        "customer_rating",
        "job_status",
        "form44_submitted",
        "biosecurity_status",
        "govt_status",
        "created_at",
    )
    search_fields = ("ship_details__ship_name", "ship_details__imo_no", "ship_details__berth")
    list_filter = (
        "date",
        "dispose_additional_waste",
        "service_purchased",
        "ship_wants_to_discharge_more",
        "docs_complete",
        "invoice_created",
        "customer_rating",
        "job_status",
        "biosecurity_status",
        "govt_status",
        "form44_submitted",
        "documentation_complete",
        "incident_occurred",
    )
    raw_id_fields = ("ship_details",)


@admin.register(VesselPlan)
class VesselPlanAdmin(admin.ModelAdmin):
    list_display = (
        "discharge_form",
        "plan_type",
        "total_volume",
        "created_at",
    )
    list_filter = (
        "plan_type",
        "created_at",
    )
    raw_id_fields = ("discharge_form",)


@admin.register(LandfillReceipt)
class LandfillReceiptAdmin(admin.ModelAdmin):
    list_display = (
        "discharge_form",
        "uploaded_at",
    )
    list_filter = (
        "uploaded_at",
    )
    raw_id_fields = ("discharge_form",)


@admin.register(IndependentReceipt)
class IndependentReceiptAdmin(admin.ModelAdmin):
    list_display = (
        "date",
        "uploaded_by",
        "uploaded_at",
    )
    list_filter = (
        "date",
        "uploaded_at",
        "uploaded_by",
    )
    search_fields = ("uploaded_by__username", "uploaded_by__email")
    raw_id_fields = ("uploaded_by",)
