from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ShipDetailsViewSet, DischargeFormViewSet, VesselPlanViewSet, LandfillReceiptViewSet, IndependentReceiptViewSet

router = DefaultRouter()
router.register(r'ship-details', ShipDetailsViewSet, basename='ship-details')
router.register(r'discharge-forms', DischargeFormViewSet, basename='discharge-form')
router.register(r'vessel-plans', VesselPlanViewSet, basename='vessel-plan')
router.register(r'landfill-receipts', LandfillReceiptViewSet, basename='landfill-receipt')
router.register(r'independent-receipts', IndependentReceiptViewSet, basename='independent-receipt')

urlpatterns = [
    path('', include(router.urls)),
]


