from django.db import models
from django.contrib.auth import get_user_model


class ShipDetails(models.Model):
    """Model to store ship/vessel information"""
    ship_name = models.CharField(max_length=200)
    berth = models.CharField(max_length=100, blank=True, null=True)
    port = models.CharField(max_length=200, default="Port Hedland")
    flag = models.CharField(max_length=100, blank=True, null=True)
    vessel_type = models.CharField(max_length=100, blank=True, null=True)
    imo_no = models.CharField(max_length=50, blank=True, null=True)
    
    # Schedule
    eta = models.DateTimeField(blank=True, null=True)
    etb = models.DateTimeField(blank=True, null=True)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.ship_name} - {self.imo_no or 'No IMO'}"


class DischargeForm(models.Model):
    # Reference to ship details
    ship_details = models.ForeignKey(ShipDetails, on_delete=models.CASCADE, related_name='discharge_forms', null=True, blank=True)
    
    # Order details
    date = models.DateField()
    time = models.TimeField(blank=True, null=True)
    
    # Service flags
    dispose_additional_waste = models.BooleanField(default=False)
    service_purchased = models.BooleanField(default=False)
    along_side = models.BooleanField(default=False, help_text="Along Side - Priority orders shown at top of list")

    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Order workflow / stage tracking
    form44_submitted = models.BooleanField(default=False)
    BIOSECURITY_CHOICES = (
        ("pending", "Pending"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
    )
    GOVT_CHOICES = (
        ("pending", "Pending"),
        ("approved", "Approved"),
        ("rejected", "Rejected"),
    )
    biosecurity_status = models.CharField(max_length=10, choices=BIOSECURITY_CHOICES, default="pending")
    govt_status = models.CharField(max_length=10, choices=GOVT_CHOICES, default="pending")

    # KPI-supporting fields
    scheduled_offload_at = models.DateTimeField(blank=True, null=True)
    actual_offload_at = models.DateTimeField(blank=True, null=True)
    ppa_supplied_volume_m3 = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    used_volume_m3 = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    incident_occurred = models.BooleanField(default=False)
    documentation_complete = models.BooleanField(default=False)
    customer_rating = models.PositiveSmallIntegerField(blank=True, null=True)
    total_amount = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    # Whether customer opts to dispose additional chargeable waste beyond free 1 m³
    dispose_additional_waste = models.BooleanField(default=False)

    # Operational confirmations (admin-managed)
    bio_witness = models.BooleanField(default=False)
    landfill_booked = models.BooleanField(default=False)
    docs_complete = models.BooleanField(default=False, help_text="Documentation complete")
    discharge_certificate_created = models.BooleanField(default=False)

    # AA storage details (boat user managed)
    aa_storage = models.BooleanField(default=False)
    aa_storage_in_at = models.DateTimeField(blank=True, null=True)
    aa_storage_out_at = models.DateTimeField(blank=True, null=True)
    
    # Garbage remaining on board
    garbage_remaining_on_board_m3 = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True, help_text="How much garbage remaining on board (cubic meters)")
    
    # Ship wants to discharge more
    ship_wants_to_discharge_more = models.BooleanField(default=False, help_text="Ship wants to discharge more")
    
    # Invoice creation
    invoice_created = models.BooleanField(default=False, help_text="Invoice created for the discharge order")
    
    # Job completion status
    JOB_STATUS_CHOICES = (
        ("incomplete", "Incomplete"),
        ("completed", "Completed"),
    )
    job_status = models.CharField(max_length=12, choices=JOB_STATUS_CHOICES, default="incomplete", help_text="Overall job completion status")
    
    # Checklist data (stored as JSON)
    vessel_checklist_meta = models.JSONField(blank=True, null=True, help_text="Vessel checklist metadata")
    collecting_checklist = models.JSONField(blank=True, null=True, help_text="Collecting boat checklist items")
    collecting_boat = models.JSONField(blank=True, null=True, help_text="Collecting boat details")
    contingency_plan = models.TextField(blank=True, null=True, help_text="Contingency plan details")

    def __str__(self):
        if self.ship_details:
            return f"{self.ship_details.ship_name} - {self.date}"
        return f"Order - {self.date}"

    @property
    def ship_name(self):
        """Convenience property to access ship name"""
        if self.ship_details and self.ship_details.ship_name:
            return self.ship_details.ship_name
        return "Unknown Ship"

    @property
    def stage_color(self) -> str:
        """Return a color keyword based on permission statuses.
        - green: government approved
        - orange: biosecurity approved (but government not yet approved)
        - red: any rejection
        - gray: otherwise (pending)
        """
        if self.govt_status == "approved":
            return "green"
        if self.biosecurity_status == "approved":
            return "orange"
        if self.govt_status == "rejected" or self.biosecurity_status == "rejected":
            return "red"
        return "gray"


class VesselPlan(models.Model):
    """Model to store vessel plan details for different types of waste disposal"""
    
    PLAN_TYPE_CHOICES = [
        ('free', 'Free'),
        ('additional', 'Additional'),
        ('service_purchase', 'Service Purchase'),
    ]
    
    discharge_form = models.ForeignKey(DischargeForm, on_delete=models.CASCADE, related_name='vessel_plans')
    plan_type = models.CharField(max_length=20, choices=PLAN_TYPE_CHOICES, default='free')
    
    # MARPOL Annex V garbage categories (m³)
    cat_a_plastic = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cat_c_domestic_waste = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cat_e_incinerator_ashes = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cat_f_operational_waste = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cat_g_cargo_residue = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cat_i_fishing_gear = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    cat_j_other_e_waste = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    
    # Auto calculated total volume
    total_volume = models.DecimalField(max_digits=12, decimal_places=2, blank=True, null=True)
    
    # Metadata
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together = ('discharge_form', 'plan_type')
        verbose_name = 'Vessel Plan'
        verbose_name_plural = 'Vessel Plans'
    
    def save(self, *args, **kwargs):
        """Automatically calculate total volume before saving."""
        qty_fields = [
            self.cat_a_plastic,
            self.cat_c_domestic_waste,
            self.cat_e_incinerator_ashes,
            self.cat_f_operational_waste,
            self.cat_g_cargo_residue,
            self.cat_i_fishing_gear,
            self.cat_j_other_e_waste,
        ]
        self.total_volume = sum([q for q in qty_fields if q is not None])
        super().save(*args, **kwargs)
    
    def __str__(self):
        return f"{self.discharge_form.ship_name} - {self.get_plan_type_display()} Plan"


class LandfillReceipt(models.Model):
    discharge_form = models.ForeignKey(DischargeForm, on_delete=models.CASCADE, related_name='receipts')
    file = models.FileField(upload_to='receipts/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Receipt for Order #{self.discharge_form_id} at {self.uploaded_at}"


class IndependentReceipt(models.Model):
    """Model to store independent landfill receipts uploaded by boat users"""
    file = models.FileField(upload_to='receipts/')
    date = models.DateField()
    uploaded_by = models.ForeignKey(get_user_model(), on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Independent Receipt - {self.date} - {self.uploaded_by.username}"
