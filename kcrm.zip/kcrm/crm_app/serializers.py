from rest_framework import serializers
from .models import ShipDetails, DischargeForm, VesselPlan, LandfillReceipt, IndependentReceipt, IncidentDocument


class ShipDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShipDetails
        fields = '__all__'


class VesselPlanSerializer(serializers.ModelSerializer):
    class Meta:
        model = VesselPlan
        fields = '__all__'


class DischargeFormSerializer(serializers.ModelSerializer):
    stage_color = serializers.ReadOnlyField()
    ship_name = serializers.ReadOnlyField()
    receipts = serializers.SerializerMethodField()
    incident_documents = serializers.SerializerMethodField()
    vessel_plans = VesselPlanSerializer(many=True, read_only=True)
    ship_details = ShipDetailsSerializer(read_only=True)
    
    # Flatten ship details for backward compatibility
    berth = serializers.SerializerMethodField()
    port = serializers.SerializerMethodField()
    flag = serializers.SerializerMethodField()
    vessel_type = serializers.SerializerMethodField()
    imo_no = serializers.SerializerMethodField()
    eta = serializers.SerializerMethodField()
    etb = serializers.SerializerMethodField()
    
    # Calculate total volume from vessel plans
    total_volume = serializers.SerializerMethodField()

    class Meta:
        model = DischargeForm
        fields = '__all__'

    def get_receipts(self, obj: DischargeForm):
        return LandfillReceiptSerializer(obj.receipts.all(), many=True, context=self.context).data
    
    def get_incident_documents(self, obj: DischargeForm):
        return IncidentDocumentSerializer(obj.incident_documents.all(), many=True, context=self.context).data
    
    def get_berth(self, obj):
        return obj.ship_details.berth if obj.ship_details else None
    
    def get_port(self, obj):
        if obj.ship_details and obj.ship_details.port:
            return obj.ship_details.port
        return "Port Hedland"  # Default port
    
    def get_flag(self, obj):
        return obj.ship_details.flag if obj.ship_details else None
    
    def get_vessel_type(self, obj):
        return obj.ship_details.vessel_type if obj.ship_details else None
    
    def get_imo_no(self, obj):
        return obj.ship_details.imo_no if obj.ship_details else None
    
    def get_eta(self, obj):
        return obj.ship_details.eta if obj.ship_details else None
    
    def get_etb(self, obj):
        return obj.ship_details.etb if obj.ship_details else None
    
    def get_total_volume(self, obj):
        """Calculate total volume from all vessel plans"""
        total = 0
        for plan in obj.vessel_plans.all():
            if plan.total_volume:
                total += float(plan.total_volume)
        return total


class LandfillReceiptSerializer(serializers.ModelSerializer):
    class Meta:
        model = LandfillReceipt
        fields = ['id', 'discharge_form', 'file', 'uploaded_at']


class IndependentReceiptSerializer(serializers.ModelSerializer):
    uploaded_by_username = serializers.CharField(source='uploaded_by.username', read_only=True)
    
    class Meta:
        model = IndependentReceipt
        fields = ['id', 'file', 'date', 'uploaded_by', 'uploaded_by_username', 'uploaded_at']


class IncidentDocumentSerializer(serializers.ModelSerializer):
    uploaded_by_username = serializers.CharField(source='uploaded_by.username', read_only=True)
    
    class Meta:
        model = IncidentDocument
        fields = ['id', 'discharge_form', 'file', 'uploaded_by', 'uploaded_by_username', 'uploaded_at']
