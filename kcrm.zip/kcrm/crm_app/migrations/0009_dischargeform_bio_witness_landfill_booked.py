from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('crm_app', '0008_dischargeform_dispose_additional_waste'),
    ]

    operations = [
        migrations.AddField(
            model_name='dischargeform',
            name='bio_witness',
            field=models.BooleanField(default=False),
        ),
        migrations.AddField(
            model_name='dischargeform',
            name='landfill_booked',
            field=models.BooleanField(default=False),
        ),
    ]


