# Generated migration
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('crm_app', '0028_dischargeform_collecting_boat_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='dischargeform',
            name='email',
            field=models.EmailField(blank=True, help_text='Contact email for the order', null=True),
        ),
    ]

