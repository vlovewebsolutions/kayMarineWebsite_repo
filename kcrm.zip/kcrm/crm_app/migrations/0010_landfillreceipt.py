from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('crm_app', '0009_dischargeform_bio_witness_landfill_booked'),
    ]

    operations = [
        migrations.CreateModel(
            name='LandfillReceipt',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('file', models.FileField(upload_to='receipts/')),
                ('uploaded_at', models.DateTimeField(auto_now_add=True)),
                ('discharge_form', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='receipts', to='crm_app.dischargeform')),
            ],
        ),
    ]


