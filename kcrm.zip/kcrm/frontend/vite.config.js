import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ command, mode }) => {
  const isDev = command === 'serve'
  
  return {
    plugins: [react()],
    base: '/crm/',
    build: {
      outDir: 'dist',
      assetsDir: 'assets',
      sourcemap: false,
      minify: 'terser',
    },
    server: {
      proxy: {
        '/crm/api': {
          target: 'http://localhost:8004', // Backend runs on 8004
          changeOrigin: true,
          secure: false,
          rewrite: (path) => path.replace(/^\/crm/, '')
        }
      }
    },
    define: {
      // Make config.ts use relative path /crm/api in production
      'import.meta.env.PROD': JSON.stringify(!isDev)
    }
  }
})


