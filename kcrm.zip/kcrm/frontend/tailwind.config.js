/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        brandBlue: "#3b4fd1", // primary blue from logo glyphs
        brandNavy: "#0b1e3a", // deep navy stroke
        brandAqua: "#2aaecf", // aqua ship accent
        brandRed: "#cf3131", // tagline red
        brandGray: "#f2f4f7",
      },
    },
  },
  plugins: [],
}



