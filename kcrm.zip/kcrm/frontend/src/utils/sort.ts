import { parseTimeToMs } from './dates';

export function compareOrdersByEtbEta(a: any, b: any): number {
	// Priority 1: Incomplete jobs first
	const aIncomplete = a.job_status === 'incomplete';
	const bIncomplete = b.job_status === 'incomplete';
	if (aIncomplete !== bIncomplete) return aIncomplete ? -1 : 1;
	
	// Priority 2: Along Side orders
	const aAlongSide = !!a.along_side;
	const bAlongSide = !!b.along_side;
	if (aAlongSide !== bAlongSide) return aAlongSide ? -1 : 1;
	
	// Priority 3: ETB (Estimated Time of Berth) - orders with ETB first
	const aHasEtb = !!a.etb;
	const bHasEtb = !!b.etb;
	if (aHasEtb && bHasEtb) {
		const aEtbTime = parseTimeToMs(a.etb);
		const bEtbTime = parseTimeToMs(b.etb);
		return aEtbTime - bEtbTime; // Ascending (earliest first)
	}
	if (aHasEtb !== bHasEtb) return aHasEtb ? -1 : 1;
	
	// Priority 4: ETA (Estimated Time of Arrival) - orders with ETA
	const aHasEta = !!a.eta;
	const bHasEta = !!b.eta;
	if (aHasEta && bHasEta) {
		const aEtaTime = parseTimeToMs(a.eta);
		const bEtaTime = parseTimeToMs(b.eta);
		return aEtaTime - bEtaTime; // Ascending (earliest first)
	}
	if (aHasEta !== bHasEta) return aHasEta ? -1 : 1;
	
	// Priority 5: Scheduled offload date
	const aHasScheduled = !!a.scheduled_offload_at;
	const bHasScheduled = !!b.scheduled_offload_at;
	if (aHasScheduled && bHasScheduled) {
		const aScheduledTime = parseTimeToMs(a.scheduled_offload_at);
		const bScheduledTime = parseTimeToMs(b.scheduled_offload_at);
		return aScheduledTime - bScheduledTime; // Ascending (earliest first)
	}
	if (aHasScheduled !== bHasScheduled) return aHasScheduled ? -1 : 1;
	
	// Fallback: by creation date
	return parseTimeToMs(b.created_at) - parseTimeToMs(a.created_at);
}

