export function parseTimeToMs(value: any): number {
	if (!value) return -Infinity;
	let v: any = value;
	if (typeof v === 'string') {
		v = v.includes('T') ? v : v.replace(' ', 'T');
	}
	const t = new Date(v).getTime();
	return isNaN(t) ? -Infinity : t;
}

export function formatDateInput(value: any): string {
	if (!value) return '';
	const t = parseTimeToMs(value);
	if (!isFinite(t)) return '';
	const d = new Date(t);
	const yyyy = d.getFullYear();
	const mm = String(d.getMonth() + 1).padStart(2, '0');
	const dd = String(d.getDate()).padStart(2, '0');
	return `${yyyy}-${mm}-${dd}`;
}

export function formatTimeInput(value: any): string {
	if (!value) return '';
	const t = parseTimeToMs(value);
	if (!isFinite(t)) return '';
	const d = new Date(t);
	const hh = String(d.getHours()).padStart(2, '0');
	const mi = String(d.getMinutes()).padStart(2, '0');
	return `${hh}:${mi}`;
}

// Format datetime without timezone conversion - displays the same time as stored in database
export function formatDateTimeNoTZ(value: any): string {
	if (!value) return '-';
	// Parse the ISO string directly to avoid timezone conversion
	const dateStr = typeof value === 'string' ? value : value.toString();
	// Handle ISO format: YYYY-MM-DDTHH:MM:SS or YYYY-MM-DDTHH:MM:SS.sssZ or YYYY-MM-DDTHH:MM:SS+HH:MM
	// Extract date and time components directly from the string
	const match = dateStr.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?/);
	if (match) {
		const [, year, month, day, hour, minute, second] = match;
		// Format as: MM/DD/YYYY, HH:MM:SS (same format as toLocaleString but without timezone conversion)
		return `${month}/${day}/${year}, ${hour}:${minute}:${second}`;
	}
	// Fallback to UTC methods if regex doesn't match
	const d = new Date(value);
	if (isNaN(d.getTime())) return '-';
	const yyyy = d.getUTCFullYear();
	const mm = String(d.getUTCMonth() + 1).padStart(2, '0');
	const dd = String(d.getUTCDate()).padStart(2, '0');
	const hh = String(d.getUTCHours()).padStart(2, '0');
	const mi = String(d.getUTCMinutes()).padStart(2, '0');
	const ss = String(d.getUTCSeconds()).padStart(2, '0');
	return `${mm}/${dd}/${yyyy}, ${hh}:${mi}:${ss}`;
}

