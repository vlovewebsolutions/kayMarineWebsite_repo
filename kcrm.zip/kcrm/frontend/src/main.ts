function renderBoatUserDashboard() {
  app.innerHTML = `
    <div class="min-h-dvh bg-gray-50">
      <header class="bg-white shadow-lg border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-20">
            <div class="flex items-center space-x-3">
              <img src="${import.meta.env.BASE_URL}logo.png" class="h-12 w-12 rounded-full border-2 border-blue-100" />
              <div>
                <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                <p class="text-sm text-gray-500">Boat Company View</p>
              </div>
            </div>
            <button id="logout" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">Logout</button>
          </div>
        </div>
      </header>

      <div class="max-w-7xl mx-auto p-6">
        <div class="bg-white rounded-lg shadow">
          <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6">
              <button id="boatOrdersTab" class="py-4 px-1 border-b-2 border-blue-500 font-medium text-blue-600">Orders</button>
              <button id="receiptsTab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Landfill Receipts</button>
            </nav>
          </div>
          <div id="boatOrdersView" class="p-6">
            <div id="boatOrdersTable" class="overflow-x-auto"></div>
          </div>
          <div id="receiptsView" class="p-6 hidden">
            <div class="space-y-6">
              <!-- Upload Section -->
              <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Upload New Receipt</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <input id="receipt_date" type="date" class="border rounded px-3 py-2 w-full focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
              </div>
              <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Upload Receipt</label>
                    <input id="receipt_file" type="file" class="border rounded px-3 py-2 w-full focus:ring-2 focus:ring-blue-500 focus:border-blue-500" accept="image/*,application/pdf">
              </div>
                  <div class="flex items-end">
                    <button id="uploadReceiptBtn" class="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors">
                      📤 Upload Receipt
                    </button>
              </div>
                </div>
              </div>
              
              <!-- Receipts List Section -->
              <div id="receiptsList" class="min-h-96"></div>
            </div>
          </div>
        </div>
      </div>
    </div>`;

  document.getElementById('logout')!.addEventListener('click', logout);
  loadBoatOrders();
  // Tabs
  document.getElementById('boatOrdersTab')!.addEventListener('click', () => switchBoatTab('orders'));
  document.getElementById('receiptsTab')!.addEventListener('click', () => switchBoatTab('receipts'));
  // Init receipts tab
  initReceiptsTab();
  // Wire up Additional button in boat view if present later
  const addBtn = document.getElementById('additionalDetails');
  if (addBtn) addBtn.addEventListener('click', openAdditionalDetailsModal);
}

async function loadBoatOrders() {
  const table = document.getElementById('boatOrdersTable')!;
  UIComponents.showLoadingSpinner(table, 'Loading orders...');
  try {
    const orders = await listOrders();
    // Sort: jobs with ETB first (desc by ETB), then without ETB (desc by ETA)
    orders.sort(compareOrdersByEtbEta);
    table.innerHTML = renderBoatOrdersTable(orders);
  } catch (e: any) {
    table.innerHTML = `<div class="text-center text-red-600">Failed to load orders</div>`;
  }
}

(window as any).boatOrderView = async (orderId: number) => {
  try {
    const order = await getOrder(orderId);
    openBoatChecklistModal(order);
  } catch (e: any) {
    UIComponents.showAlert('Failed to load order', 'error');
  }
}
import './index.css'
// dates used via components
import { compareOrdersByEtbEta } from './utils/sort'
import { UIComponents } from './utils/ui'
import { getOrder, listOrders, patchOrder, deleteOrderReq, uploadIndependentReceipt, getIndependentReceipts } from './services/orders'
import { openBoatChecklistModal } from './components/BoatChecklistModal'
import { renderAdminOrdersTable, renderBoatOrdersTable } from './components/OrdersTable'
import jsPDF from 'jspdf';
import { apiBase } from './config';

const app = document.querySelector<HTMLDivElement>('#app')!;
function switchBoatTab(tab: 'orders' | 'receipts') {
  const ordersView = document.getElementById('boatOrdersView')!;
  const receiptsView = document.getElementById('receiptsView')!;
  const ordersTab = document.getElementById('boatOrdersTab')!;
  const receiptsTab = document.getElementById('receiptsTab')!;
  if (tab === 'orders') {
    ordersView.classList.remove('hidden');
    receiptsView.classList.add('hidden');
    ordersTab.classList.add('border-blue-500', 'text-blue-600');
    ordersTab.classList.remove('border-transparent', 'text-gray-500');
    receiptsTab.classList.add('border-transparent', 'text-gray-500');
    receiptsTab.classList.remove('border-blue-500', 'text-blue-600');
  } else {
    receiptsView.classList.remove('hidden');
    ordersView.classList.add('hidden');
    receiptsTab.classList.add('border-blue-500', 'text-blue-600');
    receiptsTab.classList.remove('border-transparent', 'text-gray-500');
    ordersTab.classList.add('border-transparent', 'text-gray-500');
    ordersTab.classList.remove('border-blue-500', 'text-blue-600');
  }
}

async function initReceiptsTab() {
  try {
    const dateInput = document.getElementById('receipt_date') as HTMLInputElement;
    const listDiv = document.getElementById('receiptsList')!;
    
    // Set default date to today
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
    
    const refreshList = async () => {
      const selectedDate = dateInput.value;
      if (!selectedDate) { 
        listDiv.innerHTML = '<p class="text-sm text-gray-500">Please select a date to view receipts.</p>'; 
        return; 
      }
      
      try {
        // Fetch independent receipts for the selected date
        const independentReceipts = await getIndependentReceipts(selectedDate);
        
        // Also fetch order-related receipts
        const orders = await listOrders();
        const ordersForDate = orders.filter((order: any) => {
          const orderDate = new Date(order.date).toISOString().split('T')[0];
          return orderDate === selectedDate;
        });
        
        // Collect all receipts (both independent and order-related)
        const allReceipts: any[] = [];
        
        // Add independent receipts
        if (independentReceipts && independentReceipts.length > 0) {
          independentReceipts.forEach((receipt: any, index: number) => {
            allReceipts.push({
              ...receipt,
              orderId: 'Independent',
              shipName: 'Independent Work',
              berth: 'N/A',
              port: 'N/A',
              totalVolume: 'N/A',
              receiptNumber: index + 1,
              type: 'independent'
            });
          });
        }
        
        // Add order-related receipts
        ordersForDate.forEach((order: any) => {
          if (order.receipts && order.receipts.length > 0) {
            order.receipts.forEach((receipt: any, index: number) => {
              allReceipts.push({
                ...receipt,
                orderId: order.id,
                shipName: order.ship_name,
                berth: order.berth,
                port: order.port,
                totalVolume: order.total_volume,
                receiptNumber: index + 1,
                type: 'order'
              });
            });
          }
        });
        
        if (allReceipts.length === 0) {
          listDiv.innerHTML = `
            <div class="text-center py-8">
              <div class="text-gray-400 text-4xl mb-2">📄</div>
              <h3 class="text-lg font-medium text-gray-900 mb-1">No Receipts Found</h3>
              <p class="text-gray-500">No landfill receipts have been uploaded for ${new Date(selectedDate).toLocaleDateString()}.</p>
            </div>
          `;
          return;
        }
      
        // Create table with all receipts
        const receiptsTable = `
          <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200">
              <h3 class="text-lg font-medium text-gray-900">
                Landfill Receipts for ${new Date(selectedDate).toLocaleDateString()}
              </h3>
              <p class="text-sm text-gray-500 mt-1">${allReceipts.length} receipt${allReceipts.length !== 1 ? 's' : ''} found</p>
            </div>
            <div class="overflow-x-auto">
              <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                  <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Receipt #</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Uploaded At</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                  ${allReceipts.map((receipt: any) => `
                    <tr class="hover:bg-gray-50">
                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        #${receipt.receiptNumber}
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        ${new Date(receipt.uploaded_at).toLocaleString()}
                      </td>
                      <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div class="flex space-x-2">
                          <button onclick="downloadReceipt('${receipt.file}', '${receipt.type === 'independent' ? 'Independent' : receipt.shipName}_${receipt.type === 'independent' ? 'Receipt' : 'Job' + receipt.orderId}_Receipt${receipt.receiptNumber}')" 
                                  class="text-blue-600 hover:text-blue-900 bg-blue-50 hover:bg-blue-100 px-3 py-1 rounded-md text-xs font-medium transition-colors">
                            📥 Download
                          </button>
                          <button onclick="viewReceipt('${receipt.file}')" 
                                  class="text-green-600 hover:text-green-900 bg-green-50 hover:bg-green-100 px-3 py-1 rounded-md text-xs font-medium transition-colors">
                            👁️ View
                          </button>
                        </div>
                      </td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        `;
        
        listDiv.innerHTML = receiptsTable;
      } catch (error) {
        console.error('Error fetching receipts:', error);
        listDiv.innerHTML = `
          <div class="text-center py-8">
            <div class="text-red-400 text-4xl mb-2">⚠️</div>
            <h3 class="text-lg font-medium text-gray-900 mb-1">Error Loading Receipts</h3>
            <p class="text-gray-500">Failed to load receipts for ${new Date(selectedDate).toLocaleDateString()}.</p>
          </div>
        `;
      }
    };
    
    dateInput.onchange = refreshList;
    await refreshList();
    
    document.getElementById('uploadReceiptBtn')!.addEventListener('click', async () => {
      const fileEl = document.getElementById('receipt_file') as HTMLInputElement;
      const file = fileEl.files && fileEl.files[0];
      if (!file) { 
        UIComponents.showAlert('Please choose a file to upload', 'error'); 
        return; 
      }
      
      const selectedDate = dateInput.value;
      if (!selectedDate) {
        UIComponents.showAlert('Please select a date first', 'error');
        return;
      }
      
      try {
        // Upload receipt independently without order association
        await uploadIndependentReceipt(selectedDate, file);
        UIComponents.showAlert('Receipt uploaded successfully', 'success');
        
        // Refresh the list to show the new receipt
        await refreshList();
        fileEl.value = '';
      } catch (e: any) {
        UIComponents.showAlert('Failed to upload receipt', 'error');
      }
    });
  } catch (e: any) {
    console.error(e);
  }
}

// Global functions for receipt actions
(window as any).downloadReceipt = function(fileUrl: string, fileName: string) {
  try {
    // Create a temporary link element to trigger download
    const link = document.createElement('a');
    link.href = fileUrl;
    link.download = fileName;
    link.target = '_blank';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    UIComponents.showAlert('Receipt download started', 'success');
  } catch (error) {
    console.error('Download failed:', error);
    UIComponents.showAlert('Failed to download receipt', 'error');
  }
};

(window as any).viewReceipt = function(fileUrl: string) {
  try {
    // Open receipt in new tab for viewing
    window.open(fileUrl, '_blank');
  } catch (error) {
    console.error('View failed:', error);
    UIComponents.showAlert('Failed to open receipt', 'error');
  }
};

// Component-based approach for DRY practice
// Moved to utils/ui.ts

// moved to components/BoatChecklistModal.ts
/* function openBoatChecklistModal(order: any) {
  const vesselRows = [
    'Cat A. Plastic','Cat B. Food Waste','Cat C. Domestic Waste','Cat D. Cooking Oil (N/A)',
    'Cat E. Incinerator Ashes','Cat F. Operational Waste','Cat G. Cargo Residue','Cat H. Animal Carcasses',
    'Cat I. Fishing Gear','Cat J. Other (E-Waste)'
  ].map((label, idx) => `
    <tr>
      <td>${idx + 1}</td>
      <td>${label}</td>
      <td><input type="number" step="0.01" id="v_qty_${idx}" class="border rounded px-2 py-1 w-full"></td>
      <td><input type="text" id="v_org_${idx}" class="border rounded px-2 py-1 w-full"></td>
    </tr>
  `).join('');

  const content = `
    <div class="space-y-6 text-sm">
      <h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Vessel Checklist</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label>Ship Name: <input type="text" id="v_ship_name" value="${order.ship_name || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Flag: <input type="text" id="v_flag" value="${order.flag || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>IMO No: <input type="text" id="v_imo" value="${order.imo_no || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Berth: <input type="text" id="v_berth" value="${order.berth || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Port: <input type="text" id="v_port" value="${order.port || ''}" class="border rounded px-2 py-1 w-full"></label>
        <label>Date: <input type="date" id="v_date" value="${formatDateInput(order.date)}" class="border rounded px-2 py-1 w-full"></label>
        <label>Time: <input type="time" id="v_time" value="${formatTimeInput(order.time)}" class="border rounded px-2 py-1 w-full"></label>
        </div>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-2 py-1 text-left">No.</th>
              <th class="px-2 py-1 text-left">Garbage Category</th>
              <th class="px-2 py-1 text-left">Quantity (m³)</th>
              <th class="px-2 py-1 text-left">Origin</th>
            </tr>
          </thead>
          <tbody>
            ${vesselRows}
          </tbody>
        </table>
        </div>
      <label>Total Volume: <input type="number" step="0.01" id="v_total" value="${order.total_volume || ''}" class="border rounded px-2 py-1 w-32"></label>
      <label>Master's Name & Signature: <input type="text" id="v_master" class="border rounded px-2 py-1 w-full"></label>

      <h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Collecting Boat Checklist</h2>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <label>Collecting Boat Name: <input type="text" id="c_boat" class="border rounded px-2 py-1 w-full"></label>
        <label>Truck Reg No: <input type="text" id="c_truck" class="border rounded px-2 py-1 w-full"></label>
        <label class="sm:col-span-2">Disposal Date & Time: <input type="datetime-local" id="c_disposal" class="border rounded px-2 py-1 w-full"></label>
        </div>
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200">
          <thead class="bg-gray-50">
            <tr>
              <th class="px-2 py-1 text-left">No.</th>
              <th class="px-2 py-1 text-left">Checklist Item</th>
              <th class="px-2 py-1 text-left">Yes</th>
              <th class="px-2 py-1 text-left">No</th>
            </tr>
          </thead>
          <tbody>
            ${[ 
              'Clearance taken from Bio Security (Form 44)',
              'Clearance taken from Customs (Form 44)',
              'Verbal clearance taken on phone for Form 44',
              'Checklist for Accredited Person Completed',
              'Checklist for Driver Completed'
            ].map((item, i) => `
              <tr>
                <td class="px-2 py-1">${i + 1}</td>
                <td class="px-2 py-1">${item}</td>
                <td class="px-2 py-1"><input type="radio" name="chk_${i}" value="yes"></td>
                <td class="px-2 py-1"><input type="radio" name="chk_${i}" value="no"></td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>
      <label>Contingency Plan: <textarea id="c_contingency" rows="3" class="border rounded px-2 py-1 w-full"></textarea></label>
      </div>
    `;

  UIComponents.openModal(`Checklist - ${order.ship_name || ''}`, content, async () => {
    // Collect a minimal placeholder payload
    const checklist: Record<string, string> = {};
    for (let i = 0; i < 5; i++) {
      const sel = document.querySelector(`input[name="chk_${i}"]:checked`) as HTMLInputElement | null;
      checklist[`item_${i + 1}`] = sel?.value || '';
    }
    const payload = {
      vessel_checklist_meta: {
        ship_name: (document.getElementById('v_ship_name') as HTMLInputElement | null)?.value || '',
        flag: (document.getElementById('v_flag') as HTMLInputElement | null)?.value || '',
        imo_no: (document.getElementById('v_imo') as HTMLInputElement | null)?.value || '',
        berth: (document.getElementById('v_berth') as HTMLInputElement | null)?.value || '',
        port: (document.getElementById('v_port') as HTMLInputElement | null)?.value || '',
        date: (document.getElementById('v_date') as HTMLInputElement | null)?.value || '',
        time: (document.getElementById('v_time') as HTMLInputElement | null)?.value || '',
        total_volume: parseFloat((document.getElementById('v_total') as HTMLInputElement | null)?.value || '0') || 0,
        master_signature: (document.getElementById('v_master') as HTMLInputElement | null)?.value || ''
      },
      vessel_checklist_rows: Array.from({ length: 10 }).map((_, idx) => ({
        no: idx + 1,
        quantity_m3: parseFloat((document.getElementById(`v_qty_${idx}`) as HTMLInputElement | null)?.value || '0') || 0,
        origin: (document.getElementById(`v_org_${idx}`) as HTMLInputElement | null)?.value || ''
      })),
      collecting_boat: {
        boat_name: (document.getElementById('c_boat') as HTMLInputElement | null)?.value || '',
        truck_reg: (document.getElementById('c_truck') as HTMLInputElement | null)?.value || '',
        disposal_time: (document.getElementById('c_disposal') as HTMLInputElement | null)?.value || ''
      },
      collecting_checklist: checklist,
      contingency_plan: (document.getElementById('c_contingency') as HTMLTextAreaElement | null)?.value || ''
    };
    // Placeholder PATCH; adjust endpoint/keys as needed later
    await patchOrder(order.id, payload);
  });
} */

class PDFGenerator {
  // Helper function to load logo image
  static async loadLogoImage(): Promise<string | null> {
    try {
      // Use dynamic base URL that works in both dev and production
      const logoPath = `${import.meta.env.BASE_URL}logo.png`;
      const response = await fetch(logoPath);
      if (!response.ok) {
        console.warn(`Logo not found at ${logoPath}, trying /logo.png`);
        // Fallback to root path
        const fallbackResponse = await fetch('/logo.png');
        if (!fallbackResponse.ok) {
          return null;
        }
        const blob = await fallbackResponse.blob();
        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(blob);
        });
      }
      const blob = await response.blob();
      return new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      });
    } catch (error) {
      console.error('Failed to load logo:', error);
      return null;
    }
  }

  static async generateDischargeFormPDF(formData?: any) {
    const doc = new jsPDF('p', 'mm', 'a4'); // A4 format
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 15; // 15mm margins
    const contentWidth = pageWidth - (margin * 2);
    
    // Colors
    const primaryColor = [37, 99, 235]; // Blue
    const textColor = [0, 0, 0]; // Black text

    // Header Section with Logo and Company Info
    // Load and add logo image
    const logoDataUrl = await PDFGenerator.loadLogoImage();
    if (logoDataUrl) {
      doc.addImage(logoDataUrl, 'PNG', margin, 15, 20, 15);
    } else {
      // Fallback to text logo if image fails
    doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(margin, 15, 20, 15, 'F');
    doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
      doc.text('KM', margin + 7, 22);
    }
    
    doc.setTextColor(textColor[0], textColor[1], textColor[2]);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('Kay marine', margin + 22, 20);
    doc.text('Supply and services', margin + 22, 23);

    // Company Information (right side)
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text('KAY MARINE PTY LTD', pageWidth - margin, 20, { align: 'right' });
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text('A.B.N 44 643 899 414', pageWidth - margin, 24, { align: 'right' });

    let yPosition = 45;

    // Form Title
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('MARPOL Annex V. Garbage Discharge Form', pageWidth / 2, yPosition, { align: 'center' });

    yPosition += 15;

    // Vessel Information Section
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    
    // Two column layout for vessel info
    const leftColX = margin;
    const rightColX = margin + 90;
    
    // Left column
    doc.text('Ship Name:', leftColX, yPosition);
    doc.text(formData?.ship_name || '_________________', leftColX + 25, yPosition);
    
    doc.text('Voyage no.', leftColX, yPosition + 6);
    doc.text(formData?.voyage_no || '_________________', leftColX + 25, yPosition + 6);
    
    doc.text('Flag:', leftColX, yPosition + 12);
    doc.text(formData?.flag || '_________________', leftColX + 25, yPosition + 12);
    
    doc.text('IMO no.:', leftColX, yPosition + 18);
    doc.text(formData?.imo_no || '_________________', leftColX + 25, yPosition + 18);

    // Right column
    doc.text('Berth:', rightColX, yPosition);
    doc.text(formData?.berth || '_________________', rightColX + 15, yPosition);
    
    doc.text('Port:', rightColX, yPosition + 6);
    doc.text(formData?.port || 'Port Hedland', rightColX + 15, yPosition + 6);
    
    doc.text('Type:', rightColX, yPosition + 12);
    doc.text(formData?.vessel_type || '_________________', rightColX + 15, yPosition + 12);
    
    doc.text('Vessel Email:', rightColX, yPosition + 18);
    doc.text(formData?.vessel_email || '_________________', rightColX + 30, yPosition + 18);

    // Date and Time (to the right of Berth and Port)
    doc.text('Date:', rightColX + 60, yPosition);
    doc.text(formData?.date || '____', rightColX + 75, yPosition);
    
    doc.text('Time:', rightColX + 60, yPosition + 6);
    doc.text(formData?.time || '____', rightColX + 75, yPosition + 6);

    yPosition += 25;

    // Allowance Statement
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('Vessel allocated one cubic allowance.', margin, yPosition);

    yPosition += 10;

    // MARPOL Annex V. Garbage Table
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    
    // Table headers
    const colWidths = [12, 85, 45, 35];
    let xPos = margin;
    
    doc.text('No.', xPos, yPosition);
    xPos += colWidths[0];
    doc.text('MARPOL Annex V. Garbage', xPos, yPosition);
    xPos += colWidths[1];
    doc.text('Quantity in Meter cubes', xPos, yPosition);
    xPos += colWidths[2];
    doc.text('Origin', xPos, yPosition);
    
    yPosition += 6;

    // Table rows
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    
    const garbageCategories = [
      { no: '1', category: 'Cat A. Plastic', quantity: formData?.cat_a_plastic || '0', origin: 'Galley' },
      { no: '2', category: 'Cat. B Food Waste', quantity: 'N/A', origin: 'N/A' },
      { no: '3', category: 'Cat. C Domestic Waste', quantity: formData?.cat_c_domestic || '0', origin: '' },
      { no: '4', category: 'Cat. D Cooking Oil (N/A)', quantity: 'N/A', origin: 'N/A' },
      { no: '5', category: 'Cat. E Incinerator Ashes', quantity: formData?.cat_e_incinerator || '0', origin: '' },
      { no: '6', category: 'Cat. F Operational Waste', quantity: formData?.cat_f_operational || '0', origin: '' },
      { no: '7', category: 'Cat. G Cargo residue', quantity: formData?.cat_g_cargo || '0', origin: '' },
      { no: '8', category: 'Cat. H Animal Carcasses', quantity: 'N/A', origin: 'N/A' },
      { no: '9', category: 'Cat. I Fishing Gear', quantity: formData?.cat_i_fishing || '0', origin: '' },
      { no: '10', category: 'Cat. J Other (E-Waste)', quantity: formData?.cat_j_other || '0', origin: '' }
    ];

    garbageCategories.forEach(row => {
      xPos = margin;
      doc.text(row.no, xPos, yPosition);
      xPos += colWidths[0];
      doc.text(row.category, xPos, yPosition);
      xPos += colWidths[1];
      doc.text(row.quantity, xPos, yPosition);
      xPos += colWidths[2];
      doc.text(row.origin, xPos, yPosition);
      yPosition += 5;
    });

    // Total row
    yPosition += 3;
    doc.setFont('helvetica', 'bold');
    doc.text('Total Vol:', margin, yPosition);
    doc.text(formData?.total_volume || '1', margin + colWidths[0] + colWidths[1], yPosition);
    
    yPosition += 15;
    
    // Garbage Discharge Section
    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('VESSEL PLANNED TO DISCHARGE', margin, yPosition);
    
    yPosition += 8;
    
    // Table headers
    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.text('No.', margin, yPosition);
    doc.text('MARPOL Annex V. Garbage', margin + 10, yPosition);
    doc.text('Quantity (m³)', margin + 100, yPosition);
    doc.text('Origin', margin + 130, yPosition);
    
    yPosition += 3;

    // Draw table header line
    doc.setDrawColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.setLineWidth(0.3);
    doc.line(margin, yPosition, pageWidth - margin, yPosition);

    yPosition += 6;
    
    // Signature section - check if we need new page
    if (yPosition > pageHeight - 60) {
      doc.addPage();
      yPosition = 20;
    }

    doc.setFontSize(11);
    doc.setFont('helvetica', 'bold');
    doc.text('SIGNATURES', margin, yPosition);

    yPosition += 8;

    // Signature fields - aligned 3-column layout
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');

    const colWidth = Math.floor(contentWidth / 3);
    const colXs = [margin, margin + colWidth, margin + 2 * colWidth];
    const labels = ['Vessel Master', 'Port Authority', 'Waste Collection Service'];

    const lineLeftPadding = 28; // space reserved for label text
    const lineRightPadding = 8;
    const dateLabelWidth = 18; // 'Date:' width allocation before the line

    // First row of signature blocks
    for (let i = 0; i < labels.length; i++) {
      const x = colXs[i];
      // Label
      doc.text(`${labels[i]}:`, x, yPosition);
      // Signature line (same row)
      doc.setDrawColor(200, 200, 200);
      doc.setLineWidth(0.2);
      const sigLineStart = x + lineLeftPadding;
      const sigLineEnd = x + colWidth - lineRightPadding;
      doc.line(sigLineStart, yPosition - 0.5, sigLineEnd, yPosition - 0.5);

      // Date label and line beneath with consistent spacing
      const dateY = yPosition + 7;
      doc.text('Date:', x, dateY);
      const dateLineStart = x + dateLabelWidth;
      const dateLineEnd = x + colWidth - lineRightPadding;
      doc.line(dateLineStart, dateY - 0.5, dateLineEnd, dateY - 0.5);
    }

    // Advance below signature blocks
    yPosition += 16;
    
    // Signature line
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('Master\'s Name & Signature', pageWidth - margin - 60, yPosition);
    doc.line(pageWidth - margin - 60, yPosition + 2, pageWidth - margin, yPosition + 2);
    
    yPosition += 20;

    // Instructions section
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    
    const instructions = [
      '* Only nonperishables garbage',
      '* Please declare exact volume to be discharged and origin Galley/Accommodation/ER/Bridge etc.',
      '* Please double, all the bags of garbage before dumping them into the supplied bulk bag inside bin..',
      '* How much garbage remaining on board . __________Cubic',
      '* Would you like to discharge more if Port allowance is available? Yes/No',
      '** if yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.'
    ];

    instructions.forEach(instruction => {
      doc.text(instruction, margin, yPosition);
      yPosition += 4;
    });

    // Generate filename
    const timestamp = new Date().toISOString().split('T')[0];
    const fileName = formData ? `Discharge_Form_${formData.ship_name || 'Vessel'}_${timestamp}.pdf` : `Blank_Discharge_Form_${timestamp}.pdf`;

    doc.save(fileName);
  }
  
  static async downloadBlankForm() {
    await PDFGenerator.generateDischargeFormPDF();
  }
  
  static async downloadFilledForm(formData: any) {
    await PDFGenerator.generateDischargeFormPDF(formData);
  }
}

class FormHandler {
  static setupFormHandlers() {
    // Check if we're in editing mode
    const editingOrder = (window as any).editingOrder;
    
    if (editingOrder) {
      // Populate form fields with existing order data
      FormHandler.populateFormFields(editingOrder);
    } else {
      // Clear form first to remove any previous values
      FormHandler.clearForm();
      
      // Auto-populate current date and time for new orders
    const dateInput = document.getElementById('date') as HTMLInputElement;
    const timeInput = document.getElementById('time') as HTMLInputElement;
    
    if (dateInput) {
      const now = new Date();
      const currentDate = now.toISOString().split('T')[0]; // Format: YYYY-MM-DD
      dateInput.value = currentDate;
    }
    
    if (timeInput) {
      const now = new Date();
      const currentTime = now.toTimeString().split(' ')[0].substring(0, 5); // Format: HH:MM
      timeInput.value = currentTime;
      }
    }
    
    // Hook up total calculation for each table separately
    const updateMainTotal = () => {
      let total = 0;
      const mainInputs = document.querySelectorAll<HTMLInputElement>('#main_cat_a, #main_cat_c, #main_cat_e, #main_cat_f, #main_cat_g, #main_cat_i, #main_cat_j');
      mainInputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
      (document.getElementById('totalVol') as HTMLTableCellElement).textContent = total.toFixed(2);
    };
    
    const updateAdditionalTotal = () => {
      let total = 0;
      const additionalInputs = document.querySelectorAll<HTMLInputElement>('#additional_cat_a, #additional_cat_c, #additional_cat_e, #additional_cat_f, #additional_cat_g, #additional_cat_i, #additional_cat_j');
      additionalInputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
      (document.getElementById('additional_totalVol') as HTMLTableCellElement).textContent = total.toFixed(2);
    };
    
    const updateServiceTotal = () => {
      let total = 0;
      const serviceInputs = document.querySelectorAll<HTMLInputElement>('#service_cat_a, #service_cat_c, #service_cat_e, #service_cat_f, #service_cat_g, #service_cat_i, #service_cat_j');
      serviceInputs.forEach(i => { const v = parseFloat(i.value); if (!isNaN(v)) total += v; });
      (document.getElementById('service_totalVol') as HTMLTableCellElement).textContent = total.toFixed(2);
    };
    
    // Add event listeners to main table inputs
    const mainInputs = document.querySelectorAll<HTMLInputElement>('#main_cat_a, #main_cat_c, #main_cat_e, #main_cat_f, #main_cat_g, #main_cat_i, #main_cat_j');
    mainInputs.forEach(i => i.addEventListener('input', updateMainTotal));
    
    // Add event listeners to additional table inputs
    const additionalInputs = document.querySelectorAll<HTMLInputElement>('#additional_cat_a, #additional_cat_c, #additional_cat_e, #additional_cat_f, #additional_cat_g, #additional_cat_i, #additional_cat_j');
    additionalInputs.forEach(i => i.addEventListener('input', updateAdditionalTotal));
    
    // Add event listeners to service table inputs
    const serviceInputs = document.querySelectorAll<HTMLInputElement>('#service_cat_a, #service_cat_c, #service_cat_e, #service_cat_f, #service_cat_g, #service_cat_i, #service_cat_j');
    serviceInputs.forEach(i => i.addEventListener('input', updateServiceTotal));
    
    // Handle dispose additional waste checkbox
    const disposeAdditionalCheckbox = document.getElementById('dispose_additional_waste') as HTMLInputElement;
    if (disposeAdditionalCheckbox) {
      // Function to toggle additional inputs based on checkbox state
      const toggleAdditionalInputs = () => {
        const isChecked = disposeAdditionalCheckbox.checked;
        additionalInputs.forEach(input => {
          input.disabled = !isChecked;
          if (!isChecked) {
            input.value = ''; // Clear values when disabled
            input.classList.add('opacity-50', 'bg-gray-100');
          } else {
            input.classList.remove('opacity-50', 'bg-gray-100');
          }
        });
        // Update additional total when inputs are cleared
        if (!isChecked) {
          updateAdditionalTotal();
        }
      };
      
      // Set initial state
      toggleAdditionalInputs();
      
      // Add event listener for checkbox changes
      disposeAdditionalCheckbox.addEventListener('change', toggleAdditionalInputs);
    }
    
    // Handle service purchased checkbox
    const servicePurchasedCheckbox = document.getElementById('service_purchased') as HTMLInputElement;
    if (servicePurchasedCheckbox) {
      // Function to toggle service inputs based on checkbox state
      const toggleServiceInputs = () => {
        const isChecked = servicePurchasedCheckbox.checked;
        serviceInputs.forEach(input => {
          input.disabled = !isChecked;
          if (!isChecked) {
            input.value = ''; // Clear values when disabled
            input.classList.add('opacity-50', 'bg-gray-100');
          } else {
            input.classList.remove('opacity-50', 'bg-gray-100');
          }
        });
        // Update service total when inputs are cleared
        if (!isChecked) {
          updateServiceTotal();
        }
      };
      
      // Set initial state
      toggleServiceInputs();
      
      // Add event listener for checkbox changes
      servicePurchasedCheckbox.addEventListener('change', toggleServiceInputs);
    }
    
    // Enhanced form submission with redirect
    const submitButton = document.getElementById('submitOrder');
    if (submitButton) {
      submitButton.addEventListener('click', FormHandler.handleFormSubmission);
    }
    
    // Handle New Order button
    const newOrderButton = document.getElementById('newOrderBtn');
    if (newOrderButton) {
      newOrderButton.addEventListener('click', FormHandler.resetToNewOrder);
    }
  }

  static populateFormFields(order: any) {
    // Helper function to safely set input values
    const setValue = (id: string, value: any) => {
      const element = document.getElementById(id) as HTMLInputElement;
      if (element && value !== null && value !== undefined) {
        element.value = value;
      }
    };
    
    // Helper function to format datetime for datetime-local inputs
    const formatDateTime = (value: any) => {
      if (!value) return '';
      const date = new Date(value);
      return date.toISOString().slice(0, 16); // Format: YYYY-MM-DDTHH:MM
    };
    
    // Helper function to format date for date inputs
    const formatDate = (value: any) => {
      if (!value) return '';
      const date = new Date(value);
      return date.toISOString().split('T')[0]; // Format: YYYY-MM-DD
    };
    
    // Helper function to format time for time inputs
    const formatTime = (value: any) => {
      if (!value) return '';
      const date = new Date(value);
      return date.toTimeString().split(' ')[0].substring(0, 5); // Format: HH:MM
    };
    
    // Populate basic form fields
    setValue('ship_name', order.ship_name);
    setValue('berth', order.berth);
    setValue('port', order.port);
    setValue('flag', order.flag);
    setValue('type', order.vessel_type);
    setValue('imo', order.imo_no);
    setValue('email', order.email);
    setValue('date', formatDate(order.date));
    setValue('time', formatTime(order.time));
    setValue('eta', formatDateTime(order.eta));
    setValue('etb', formatDateTime(order.etb));
    setValue('garbage_remaining_on_board', order.garbage_remaining_on_board_m3);
    
    // Set checkboxes
    const disposeCheckbox = document.getElementById('dispose_additional_waste') as HTMLInputElement;
    if (disposeCheckbox) {
      disposeCheckbox.checked = !!order.dispose_additional_waste;
      // Trigger change event to update additional inputs state
      disposeCheckbox.dispatchEvent(new Event('change'));
    }
    
    const serviceCheckbox = document.getElementById('service_purchased') as HTMLInputElement;
    if (serviceCheckbox) {
      serviceCheckbox.checked = !!order.service_purchased;
      // Trigger change event to update service inputs state
      serviceCheckbox.dispatchEvent(new Event('change'));
    }
    
    const shipWantsToDischargeMoreCheckbox = document.getElementById('ship_wants_to_discharge_more') as HTMLInputElement;
    if (shipWantsToDischargeMoreCheckbox) {
      shipWantsToDischargeMoreCheckbox.checked = !!order.ship_wants_to_discharge_more;
    }
    
    // Populate vessel plan data if available
    if (order.vessel_plans && order.vessel_plans.length > 0) {
      // Find vessel plans by type
      const freePlan = order.vessel_plans.find((plan: any) => plan.plan_type === 'free');
      const additionalPlan = order.vessel_plans.find((plan: any) => plan.plan_type === 'additional');
      const servicePlan = order.vessel_plans.find((plan: any) => plan.plan_type === 'service_purchase');
      
      // Populate main table (free plan)
      if (freePlan) {
        setValue('main_cat_a', freePlan.cat_a_plastic);
        setValue('main_cat_c', freePlan.cat_c_domestic_waste);
        setValue('main_cat_e', freePlan.cat_e_incinerator_ashes);
        setValue('main_cat_f', freePlan.cat_f_operational_waste);
        setValue('main_cat_g', freePlan.cat_g_cargo_residue);
        setValue('main_cat_i', freePlan.cat_i_fishing_gear);
        setValue('main_cat_j', freePlan.cat_j_other_e_waste);
        
        // Update main total volume display
        const totalVolElement = document.getElementById('totalVol');
        if (totalVolElement && freePlan.total_volume) {
          totalVolElement.textContent = freePlan.total_volume.toString();
        }
      }
      
      // Populate additional table
      if (additionalPlan) {
        setValue('additional_cat_a', additionalPlan.cat_a_plastic);
        setValue('additional_cat_c', additionalPlan.cat_c_domestic_waste);
        setValue('additional_cat_e', additionalPlan.cat_e_incinerator_ashes);
        setValue('additional_cat_f', additionalPlan.cat_f_operational_waste);
        setValue('additional_cat_g', additionalPlan.cat_g_cargo_residue);
        setValue('additional_cat_i', additionalPlan.cat_i_fishing_gear);
        setValue('additional_cat_j', additionalPlan.cat_j_other_e_waste);
        
        // Update additional total volume display
        const additionalTotalVolElement = document.getElementById('additional_totalVol');
        if (additionalTotalVolElement && additionalPlan.total_volume) {
          additionalTotalVolElement.textContent = additionalPlan.total_volume.toString();
        }
      }
      
      // Populate service table
      if (servicePlan) {
        setValue('service_cat_a', servicePlan.cat_a_plastic);
        setValue('service_cat_c', servicePlan.cat_c_domestic_waste);
        setValue('service_cat_e', servicePlan.cat_e_incinerator_ashes);
        setValue('service_cat_f', servicePlan.cat_f_operational_waste);
        setValue('service_cat_g', servicePlan.cat_g_cargo_residue);
        setValue('service_cat_i', servicePlan.cat_i_fishing_gear);
        setValue('service_cat_j', servicePlan.cat_j_other_e_waste);
        
        // Update service total volume display
        const serviceTotalVolElement = document.getElementById('service_totalVol');
        if (serviceTotalVolElement && servicePlan.total_volume) {
          serviceTotalVolElement.textContent = servicePlan.total_volume.toString();
        }
      }
    }
    
    // Update submit button text for editing mode
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Update Discharge Order';
    }
  }

  static async handleFormSubmission(ev: Event) {
    ev.preventDefault();
    
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    const editingOrder = (window as any).editingOrder;
    
    try {
      // Show loading state
      submitButton.disabled = true;
      const loadingText = editingOrder ? 'Updating...' : 'Submitting...';
      submitButton.innerHTML = `
        <svg class="animate-spin -ml-1 mr-3 h-5 w-5 text-white inline" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        ${loadingText}
      `;

      // Collect form data
      const formData = FormHandler.collectFormData();
      
      if (editingOrder) {
        // Update existing order
        await patchOrder(editingOrder.id, formData);
        UIComponents.showAlert('Order updated successfully!', 'success');
        
        // Clear editing state
        (window as any).editingOrder = null;
        
        // Reset tab title
        const createTab = document.getElementById('createTab')!;
        createTab.textContent = 'Create Order';
        
        // Reset form title
        const createView = document.getElementById('createView')!;
        const titleElement = createView.querySelector('h2')!;
        titleElement.textContent = 'Create New Discharge Order';
        
        // Redirect to orders list after 1.5 seconds
        setTimeout(() => {
          switchTab('orders');
          loadOrders();
        }, 1500);
      } else {
        // Create new order
      const success = await FormHandler.submitToAPI(formData);
      
      if (success) {
        UIComponents.showAlert('Discharge order submitted successfully!', 'success');
          
          // Clear form after successful submission
          FormHandler.clearForm();
        
        // Redirect to orders list after 1.5 seconds
        setTimeout(() => {
          // Check if user is admin and redirect accordingly
          checkUserRole().then(isAdmin => {
            if (isAdmin) {
              switchTab('orders');
              loadOrders();
            } else {
              // For regular users, just show success message
              UIComponents.showAlert('Your order has been submitted for review.', 'success');
            }
          });
        }, 1500);
        }
      }
    } catch (error) {
      console.error('Form submission error:', error);
      const errorMessage = editingOrder ? 'Failed to update order. Please try again.' : 'Failed to submit order. Please try again.';
      UIComponents.showAlert(errorMessage, 'error');
    } finally {
      // Reset button state
      submitButton.disabled = false;
      const buttonText = editingOrder ? 'Update Discharge Order' : 'Submit Discharge Request';
      submitButton.textContent = buttonText;
    }
  }

  static clearForm() {
    // Clear all form inputs
    const inputs = document.querySelectorAll('#dischargeForm input, #dischargeForm textarea');
    inputs.forEach((input: any) => {
      if (input.type === 'checkbox') {
        input.checked = false;
      } else {
        input.value = '';
      }
    });
    
    // Reset all total volume displays
    const totalVolElement = document.getElementById('totalVol');
    if (totalVolElement) {
      totalVolElement.textContent = '0';
    }
    
    const additionalTotalVolElement = document.getElementById('additional_totalVol');
    if (additionalTotalVolElement) {
      additionalTotalVolElement.textContent = '0';
    }
    
    const serviceTotalVolElement = document.getElementById('service_totalVol');
    if (serviceTotalVolElement) {
      serviceTotalVolElement.textContent = '0';
    }
    
    // Reset submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Submit Discharge Request';
    }
  }

  static resetToNewOrder() {
    // Clear editing state
    (window as any).editingOrder = null;
    
    // Reset tab title
    const createTab = document.getElementById('createTab')!;
    createTab.textContent = 'Create Order';
    
    // Reset form title
    const createView = document.getElementById('createView')!;
    const titleElement = createView.querySelector('h2')!;
    titleElement.textContent = 'Create New Discharge Order';
    
    // Hide New Order button
    const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
    if (newOrderButton) {
      newOrderButton.classList.add('hidden');
    }
    
    // Reset submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Submit Discharge Request';
    }
    
    // Clear form
    FormHandler.clearForm();
    
    // Auto-populate current date and time for new orders
    const dateInput = document.getElementById('date') as HTMLInputElement;
    const timeInput = document.getElementById('time') as HTMLInputElement;
    
    if (dateInput) {
      const now = new Date();
      const currentDate = now.toISOString().split('T')[0]; // Format: YYYY-MM-DD
      dateInput.value = currentDate;
    }
    
    if (timeInput) {
      const now = new Date();
      const currentTime = now.toTimeString().split(' ')[0].substring(0, 5); // Format: HH:MM
      timeInput.value = currentTime;
    }
    
    // Trigger checkbox change events to reset input states
    const disposeCheckbox = document.getElementById('dispose_additional_waste') as HTMLInputElement;
    if (disposeCheckbox) {
      disposeCheckbox.dispatchEvent(new Event('change'));
    }
    
    const serviceCheckbox = document.getElementById('service_purchased') as HTMLInputElement;
    if (serviceCheckbox) {
      serviceCheckbox.dispatchEvent(new Event('change'));
    }
  }

  static collectFormData() {
    // Collect vessel form values
    const ship_name = (document.getElementById('ship_name') as HTMLInputElement)?.value || '';
    const berth = (document.getElementById('berth') as HTMLInputElement)?.value || '';
    const date = (document.getElementById('date') as HTMLInputElement)?.value || '';
    const time = (document.getElementById('time') as HTMLInputElement)?.value || '';
    const eta = (document.getElementById('eta') as HTMLInputElement)?.value || '';
    const etb = (document.getElementById('etb') as HTMLInputElement)?.value || '';
    const port = (document.getElementById('port') as HTMLInputElement)?.value || 'Port Hedland';
    const flag = (document.getElementById('flag') as HTMLInputElement)?.value || '';
    const vessel_type = (document.getElementById('type') as HTMLInputElement)?.value || '';
    const imo_no = (document.getElementById('imo') as HTMLInputElement)?.value || '';
    const email = (document.getElementById('email') as HTMLInputElement)?.value || '';
    const dispose_additional_waste = (document.getElementById('dispose_additional_waste') as HTMLInputElement)?.checked || false;
    const service_purchased = (document.getElementById('service_purchased') as HTMLInputElement)?.checked || false;
    const ship_wants_to_discharge_more = (document.getElementById('ship_wants_to_discharge_more') as HTMLInputElement)?.checked || false;

    // Helper function to get numeric value from input
    // For quantity fields, empty means 0, not null
    const getNum = (id: string, allowNull: boolean = false) => {
      const el = document.getElementById(id) as HTMLInputElement;
      if (!el) return null;
      const value = el.value.trim();
      if (value === '') {
        return allowNull ? null : 0;
      }
      const n = parseFloat(value);
      return isNaN(n) ? (allowNull ? null : 0) : n;
    };

    const garbage_remaining_on_board = getNum('garbage_remaining_on_board', true);

    // Collect main table data (free plan) - empty fields are 0
    const main_cat_a_plastic = getNum('main_cat_a');
    const main_cat_c_domestic_waste = getNum('main_cat_c');
    const main_cat_e_incinerator_ashes = getNum('main_cat_e');
    const main_cat_f_operational_waste = getNum('main_cat_f');
    const main_cat_g_cargo_residue = getNum('main_cat_g');
    const main_cat_i_fishing_gear = getNum('main_cat_i');
    const main_cat_j_other_e_waste = getNum('main_cat_j');

    // Collect additional table data - empty fields are 0
    const additional_cat_a_plastic = getNum('additional_cat_a');
    const additional_cat_c_domestic_waste = getNum('additional_cat_c');
    const additional_cat_e_incinerator_ashes = getNum('additional_cat_e');
    const additional_cat_f_operational_waste = getNum('additional_cat_f');
    const additional_cat_g_cargo_residue = getNum('additional_cat_g');
    const additional_cat_i_fishing_gear = getNum('additional_cat_i');
    const additional_cat_j_other_e_waste = getNum('additional_cat_j');

    // Collect service table data - empty fields are 0
    const service_cat_a_plastic = getNum('service_cat_a');
    const service_cat_c_domestic_waste = getNum('service_cat_c');
    const service_cat_e_incinerator_ashes = getNum('service_cat_e');
    const service_cat_f_operational_waste = getNum('service_cat_f');
    const service_cat_g_cargo_residue = getNum('service_cat_g');
    const service_cat_i_fishing_gear = getNum('service_cat_i');
    const service_cat_j_other_e_waste = getNum('service_cat_j');

    return {
      ship_name,
      berth: berth || null,
      date,
      time: time || null,
      eta: eta || null,
      etb: etb || null,
      port,
      flag: flag || null,
      vessel_type: vessel_type || null,
      imo_no: imo_no || null,
      email: email || null,
      dispose_additional_waste,
      service_purchased,
      ship_wants_to_discharge_more,
      garbage_remaining_on_board_m3: garbage_remaining_on_board,
      // Main table (free plan) - keep for backward compatibility
      cat_a_plastic: main_cat_a_plastic,
      cat_c_domestic_waste: main_cat_c_domestic_waste,
      cat_e_incinerator_ashes: main_cat_e_incinerator_ashes,
      cat_f_operational_waste: main_cat_f_operational_waste,
      cat_g_cargo_residue: main_cat_g_cargo_residue,
      cat_i_fishing_gear: main_cat_i_fishing_gear,
      cat_j_other_e_waste: main_cat_j_other_e_waste,
      // Additional table data
      additional_cat_a_plastic,
      additional_cat_c_domestic_waste,
      additional_cat_e_incinerator_ashes,
      additional_cat_f_operational_waste,
      additional_cat_g_cargo_residue,
      additional_cat_i_fishing_gear,
      additional_cat_j_other_e_waste,
      // Service table data
      service_cat_a_plastic,
      service_cat_c_domestic_waste,
      service_cat_e_incinerator_ashes,
      service_cat_f_operational_waste,
      service_cat_g_cargo_residue,
      service_cat_i_fishing_gear,
      service_cat_j_other_e_waste,
    };
  }

  static async submitToAPI(formData: any): Promise<boolean> {
    const res = await fetch(`${apiBase}/discharge-forms/`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json', 
        'Authorization': `Bearer ${localStorage.getItem('access')}` 
      },
      body: JSON.stringify(formData),
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      const msg = (errorData && (errorData.detail || JSON.stringify(errorData))) || `HTTP ${res.status}`;
      throw new Error(msg);
    }

    return true;
  }
}

function openAdditionalDetailsModal() {
  const placeholder = `
    <div class="space-y-4">
      <p class="text-sm text-gray-600">Additional details form will appear here.</p>
      <p class="text-sm text-gray-500">This modal is for future use. The vessel plan table is now available in the collapsible Additional Details section.</p>
    </div>`;

  UIComponents.openModal('Additional Details', placeholder, () => {
    console.log('Additional details modal opened');
  });
}

function render() {
  const access = localStorage.getItem('access');
  console.log('Access token exists:', !!access);
  console.log('Access token value:', access ? access.substring(0, 20) + '...' : 'null');
  if (access) {
    // Add a small delay to ensure tokens are properly stored
    setTimeout(() => {
    // Check if user is admin by trying to fetch user profile
    checkUserRole().then(isAdmin => {
      console.log('User is admin:', isAdmin);
      if (isAdmin) {
        renderAdminDashboard();
      } else {
        renderBoatUserDashboard();
      }
      }).catch(error => {
        console.error('Error in checkUserRole:', error);
        // If checkUserRole fails, show login form
        renderLoginForm();
    });
    }, 100);
  } else {
    console.log('No access token found, showing login form');
    renderLoginForm();
  }
}

async function checkUserRole(): Promise<boolean> {
  try {
    const access = localStorage.getItem('access');
    console.log('checkUserRole: Access token:', access ? access.substring(0, 20) + '...' : 'null');
    
    const res = await fetch(`${apiBase}/auth/me/`, {
      headers: { 'Authorization': `Bearer ${access}` }
    });
    
    console.log('checkUserRole: Response status:', res.status);
    
    if (res.ok) {
      const user = await res.json();
      console.log('User data:', user);
      console.log('Is staff:', user.is_staff, 'Is superuser:', user.is_superuser);
      return user.is_staff || user.is_superuser;
    } else {
      console.log('checkUserRole: Failed with status:', res.status);
      const errorText = await res.text();
      console.log('checkUserRole: Error response:', errorText);
    }
  } catch (error) {
    console.error('Error checking user role:', error);
  }
  return false;
}

function renderAdminDashboard() {
    app.innerHTML = `
    <div class="min-h-dvh bg-gray-50">
      <!-- Enhanced Header -->
      <header class="bg-white shadow-lg border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-20">
            <!-- Logo and Brand -->
            <div class="flex items-center space-x-4">
              <div class="flex items-center space-x-3">
                <div class="relative">
                  <img src="${import.meta.env.BASE_URL}logo.png" alt="Kay Marine" class="h-12 w-12 object-contain rounded-full shadow-md border-2 border-blue-100" />
                  <div class="absolute -top-1 -right-1 h-4 w-4 bg-green-500 rounded-full border-2 border-white"></div>
                </div>
                <div>
                  <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                  <p class="text-sm text-gray-500 font-medium">Admin Dashboard</p>
                </div>
              </div>
            </div>
            
            <!-- User Info and Actions -->
            <div class="flex items-center space-x-4">
              <div class="hidden sm:block text-right">
                <p class="text-sm font-medium text-gray-900">Welcome, Admin</p>
                <p class="text-xs text-gray-500">System Administrator</p>
              </div>
              <div class="flex items-center space-x-2">
                <button id="refreshOrders" class="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors" title="Refresh Orders">
                  <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                  </svg>
                </button>
                <button id="logout" class="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors shadow-sm btn-enhanced">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
                  </svg>
                  <span class="hidden sm:inline">Logout</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Main Content -->
      <div class="max-w-7xl mx-auto p-6">

        <!-- Navigation Tabs -->
        <div class="bg-white rounded-lg shadow mb-6">
          <div class="border-b border-gray-200">
            <nav class="flex space-x-8 px-6">
              <button id="ordersTab" class="py-4 px-1 border-b-2 border-blue-500 font-medium text-blue-600">Orders List</button>
              <button id="createTab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Create Order</button>
              <button id="last24Tab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Last 24 Hours</button>
              <button id="next24Tab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Next 24 Hours</button>
              <button id="kpiTab" class="py-4 px-1 border-b-2 border-transparent font-medium text-gray-500 hover:text-gray-700">Reports</button>
            </nav>
          </div>
        </div>

        <!-- KPI View (Hidden by default) -->
        <div id="kpiView" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Key Performance Indicators</h2>
              <button id="refreshKpi" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
            </div>
          </div>
          <div class="p-6">
            <div id="kpiContainer" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <!-- KPI cards will render here -->
            </div>
          </div>
        </div>

        <!-- Orders List View -->
        <div id="ordersView" class="bg-white rounded-lg shadow">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Discharge Orders</h2>
              <div class="flex items-center space-x-3">
                <button id="downloadBlankForm" class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <span>Download Blank Form</span>
                </button>
                <button id="refreshOrders" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="ordersTable" class="overflow-x-auto">
              <div class="flex justify-center items-center h-32">
                <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <span class="ml-2 text-gray-600">Loading orders...</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Last 24 Hours View (Hidden by default) -->
        <div id="last24View" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Completed in Last 24 Hours</h2>
              <div class="flex items-center space-x-3">
                <button id="refreshLast24" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="last24Table" class="overflow-x-auto"></div>
          </div>
        </div>

        <!-- Next 24 Hours View (Hidden by default) -->
        <div id="next24View" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Scheduled in Next 24 Hours</h2>
              <div class="flex items-center space-x-3">
                <button id="refreshNext24" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh</button>
              </div>
            </div>
          </div>
          <div class="p-6">
            <div id="next24Table" class="overflow-x-auto"></div>
          </div>
        </div>

        <!-- Create Order View (Hidden by default) -->
        <div id="createView" class="bg-white rounded-lg shadow hidden">
          <div class="px-6 py-4 border-b border-gray-200">
            <div class="flex justify-between items-center">
              <h2 class="text-xl font-semibold text-gray-900">Create New Discharge Order</h2>
              <div class="flex items-center space-x-3">
                <button id="downloadBlankFormCreate" class="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                  </svg>
                  <span>Download Blank</span>
                </button>
              </div>
            </div>
          </div>
          <div class="p-6">
            ${getDischargeFormHTML()}
          </div>
        </div>

        <!-- Service Purchase View removed; now part of Create Order collapsible -->
      </div>
    </div>`;

  // Add event listeners
  const logoutBtn = document.getElementById('logout');
  if (logoutBtn) logoutBtn.addEventListener('click', logout);
  
  const ordersTab = document.getElementById('ordersTab');
  if (ordersTab) ordersTab.addEventListener('click', () => switchTab('orders'));
  
  const createTab = document.getElementById('createTab');
  if (createTab) createTab.addEventListener('click', () => switchTab('create'));
  
  const last24Tab = document.getElementById('last24Tab');
  if (last24Tab) last24Tab.addEventListener('click', () => switchTab('last24'));
  
  const next24Tab = document.getElementById('next24Tab');
  if (next24Tab) next24Tab.addEventListener('click', () => switchTab('next24'));
  
  const refreshOrdersBtn = document.getElementById('refreshOrders');
  if (refreshOrdersBtn) refreshOrdersBtn.addEventListener('click', loadOrders);
  
  const refreshLast24Btn = document.getElementById('refreshLast24');
  if (refreshLast24Btn) refreshLast24Btn.addEventListener('click', loadLast24);
  
  const refreshNext24Btn = document.getElementById('refreshNext24');
  if (refreshNext24Btn) refreshNext24Btn.addEventListener('click', loadNext24);
  
  const kpiTab = document.getElementById('kpiTab');
  if (kpiTab) kpiTab.addEventListener('click', () => switchTab('kpi'));
  
  const refreshKpiBtn = document.getElementById('refreshKpi');
  if (refreshKpiBtn) refreshKpiBtn.addEventListener('click', loadKpi);
  
  // PDF download event listeners
  const downloadBlankFormBtn = document.getElementById('downloadBlankForm');
  if (downloadBlankFormBtn) {
    downloadBlankFormBtn.addEventListener('click', async () => {
      await PDFGenerator.downloadBlankForm();
    UIComponents.showAlert('Blank discharge form downloaded successfully!', 'success');
  });
  }
  
  const downloadBlankFormCreateBtn = document.getElementById('downloadBlankFormCreate');
  if (downloadBlankFormCreateBtn) {
    downloadBlankFormCreateBtn.addEventListener('click', async () => {
      await PDFGenerator.downloadBlankForm();
    UIComponents.showAlert('Blank discharge form downloaded successfully!', 'success');
  });
  }
  
  const downloadFilledFormBtn = document.getElementById('downloadFilledForm');
  if (downloadFilledFormBtn) {
    downloadFilledFormBtn.addEventListener('click', async () => {
    const formData = FormHandler.collectFormData();
      await PDFGenerator.downloadFilledForm(formData);
    UIComponents.showAlert('Filled discharge form downloaded successfully!', 'success');
  });
  }

  // Wire up collapsibles in admin create view
  const addToggle = document.getElementById('toggleAdditional');
  const addPanel = document.getElementById('additionalPanel');
  const addChevron = document.getElementById('additionalChevron');
  if (addToggle && addPanel && addChevron) {
    addToggle.addEventListener('click', () => {
      const hidden = addPanel.classList.contains('hidden');
      addPanel.classList.toggle('hidden');
      addChevron!.textContent = hidden ? '▲' : '▼';
    });
  }
  const svcToggle = document.getElementById('toggleService');
  const svcPanel = document.getElementById('servicePanel');
  const svcChevron = document.getElementById('serviceChevron');
  if (svcToggle && svcPanel && svcChevron) {
    svcToggle.addEventListener('click', () => {
      const hidden = svcPanel.classList.contains('hidden');
      svcPanel.classList.toggle('hidden');
      svcChevron!.textContent = hidden ? '▲' : '▼';
    });
  }

  // Load orders initially
  loadOrders();
  // Preload KPI silently
  loadKpi();
}

// deprecated legacy view removed

function renderLoginForm() {
  app.innerHTML = `
    <div class="min-h-dvh bg-gradient-to-br from-blue-50 to-gray-100">
      <!-- Enhanced Header -->
      <header class="bg-white shadow-sm border-b border-gray-200">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-center items-center h-16">
            <div class="flex items-center space-x-3">
              <div class="relative">
                <img src="/logo.png" alt="Kay Marine" class="h-12 w-12 object-contain rounded-full shadow-md border-2 border-blue-100" />
                <div class="absolute -top-1 -right-1 h-4 w-4 bg-blue-500 rounded-full border-2 border-white"></div>
              </div>
              <div>
                <h1 class="text-2xl font-bold text-gray-900">Kay Marine CRM</h1>
                <p class="text-sm text-gray-500 font-medium">Supply and Services</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Login Form -->
      <div class="flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
          <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div class="px-8 py-10">
              <div class="text-center mb-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h2>
                <p class="text-gray-600">Sign in to your account</p>
              </div>
              <form id="loginForm" class="space-y-6">
                <div>
                  <label for="username" class="block text-sm font-medium text-gray-700 mb-2">Username</label>
                  <input id="username" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors" placeholder="Enter your username" required />
                </div>
                <div>
                  <label for="password" class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                  <input id="password" type="password" class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors" placeholder="Enter your password" required />
                </div>
                <button class="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors" type="submit">
                  Sign In
                </button>
                <p id="error" class="text-red-600 text-sm text-center h-4"></p>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>`;
  document.getElementById('loginForm')!.addEventListener('submit', login);
}

function getDischargeFormHTML(): string {
  return `
          <style>
            .frm table{width:100%;border-collapse:collapse;margin-top:15px}
            .frm th,.frm td{border:1px solid #444;padding:8px;text-align:center}
            .frm th{background:#f2f2f2}
            .frm input[type=text],.frm input[type=number],.frm input[type=date],.frm input[type=time],.frm input[type=email],.frm input[type=datetime-local]{width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:6px;box-sizing:border-box}
            .frm .total-cell{font-weight:bold;background:#e8f5e9}
            .frm .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;margin-top:8px}
            .frm .form-field{display:flex;flex-direction:column}
            .frm .form-field label{font-weight:600;color:#334155;margin-bottom:6px}
            .frm h2{margin-bottom:12px}
          </style>
          <div class="frm">
            <h2 class="text-xl font-bold mb-2">Vessel Discharge Form</h2>
            <form id="dischargeForm">
              <div class="form-grid">
                <div class="form-field"><label for="ship_name">Ship Name</label><input type="text" name="ship_name" id="ship_name"></div>
                <div class="form-field"><label for="berth">Berth</label><input type="text" name="berth" id="berth"></div>
                <div class="form-field"><label for="date">Order Created At</label><input type="date" name="date" id="date"></div>
                <div class="form-field"><label for="time">Time</label><input type="time" name="time" id="time"></div>
          <div class="form-field"><label for="eta">ETA (Estimated Time of Arrival)</label><input type="datetime-local" name="eta" id="eta"></div>
          <div class="form-field"><label for="etb">ETB (Estimated Time of Berth)</label><input type="datetime-local" name="etb" id="etb"></div>
                <div class="form-field"><label for="port">Port</label><input type="text" name="port" id="port" value="Port Hedland"></div>
                <div class="form-field"><label for="flag">Flag</label><input type="text" name="flag" id="flag"></div>
                <div class="form-field"><label for="type">Vessel Type</label><input type="text" name="type" id="type"></div>
                <div class="form-field"><label for="imo">IMO no.</label><input type="text" name="imo" id="imo"></div>
                <div class="form-field"><label for="email">Email</label><input type="email" name="email" id="email"></div>
                <div class="form-field"><label for="dispose_additional_waste">Dispose additional waste (beyond free 1 m³)?</label><input type="checkbox" name="dispose_additional_waste" id="dispose_additional_waste"></div>
                <div class="form-field"><label for="service_purchased">Service Purchased?</label><input type="checkbox" name="service_purchased" id="service_purchased"></div>
                <div class="form-field"><label for="garbage_remaining_on_board">How much garbage remaining on board (m³)</label><input type="number" step="0.01" name="garbage_remaining_on_board" id="garbage_remaining_on_board" placeholder="0.00"></div>
                <div class="form-field"><label for="ship_wants_to_discharge_more">Ship wants to discharge more?</label><input type="checkbox" name="ship_wants_to_discharge_more" id="ship_wants_to_discharge_more"></div>
                <div class="form-field">
                  <div class="text-sm text-gray-600 mt-2 p-3 bg-blue-50 border border-blue-200 rounded-md">
                    <strong>Note:</strong> If yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.
                  </div>
                </div>
              </div>
            </form>

            <h3 class="mt-4 font-semibold">Vessel Planned to Discharge</h3>
            <table>
              <thead>
                <tr>
                  <th>No.</th>
                  <th>MARPOL Annex V. Garbage</th>
                  <th>Quantity (m³)</th>
                  <th>Origin</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>1</td><td>Cat A. Plastic</td><td><input type="number" step="0.01" class="qty" id="main_cat_a"></td><td></td></tr>
                <tr><td>2</td><td>Cat B. Food Waste</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>3</td><td>Cat C. Domestic Waste</td><td><input type="number" step="0.01" class="qty" id="main_cat_c"></td><td></td></tr>
                <tr><td>4</td><td>Cat D. Cooking Oil</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>5</td><td>Cat E. Incinerator Ashes</td><td><input type="number" step="0.01" class="qty" id="main_cat_e"></td><td></td></tr>
                <tr><td>6</td><td>Cat F. Operational Waste</td><td><input type="number" step="0.01" class="qty" id="main_cat_f"></td><td></td></tr>
                <tr><td>7</td><td>Cat G. Cargo Residue</td><td><input type="number" step="0.01" class="qty" id="main_cat_g"></td><td></td></tr>
                <tr><td>8</td><td>Cat H. Animal Carcasses</td><td>N/A</td><td>N/A</td></tr>
                <tr><td>9</td><td>Cat I. Fishing Gear</td><td><input type="number" step="0.01" class="qty" id="main_cat_i"></td><td></td></tr>
                <tr><td>10</td><td>Cat J. Other (E-Waste)</td><td><input type="number" step="0.01" class="qty" id="main_cat_j"></td><td></td></tr>
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="2" class="total-cell">Total Vol:</td>
                  <td class="total-cell" id="totalVol">0</td>
                  <td></td>
                </tr>
              </tfoot>
          </table>

            <div class="mt-6 border rounded-lg">
              <button id="toggleAdditional" class="w-full flex justify-between items-center px-4 py-3 bg-gray-50 hover:bg-gray-100">
                <span class="font-medium">Additional Details</span>
                <span id="additionalChevron">▼</span>
              </button>
              <div id="additionalPanel" class="p-4 hidden">
                <h3 class="mt-6 font-semibold">Vessel Planned to Discharge (Additional)</h3>
                <table>
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>MARPOL Annex V. Garbage</th>
                      <th>Quantity (m³)</th>
                      <th>Origin</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td>1</td><td>Cat A. Plastic</td><td><input type="number" step="0.01" class="qty" id="additional_cat_a"></td><td></td></tr>
                    <tr><td>2</td><td>Cat B. Food Waste</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>3</td><td>Cat C. Domestic Waste</td><td><input type="number" step="0.01" class="qty" id="additional_cat_c"></td><td></td></tr>
                    <tr><td>4</td><td>Cat D. Cooking Oil</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>5</td><td>Cat E. Incinerator Ashes</td><td><input type="number" step="0.01" class="qty" id="additional_cat_e"></td><td></td></tr>
                    <tr><td>6</td><td>Cat F. Operational Waste</td><td><input type="number" step="0.01" class="qty" id="additional_cat_f"></td><td></td></tr>
                    <tr><td>7</td><td>Cat G. Cargo Residue</td><td><input type="number" step="0.01" class="qty" id="additional_cat_g"></td><td></td></tr>
                    <tr><td>8</td><td>Cat H. Animal Carcasses</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>9</td><td>Cat I. Fishing Gear</td><td><input type="number" step="0.01" class="qty" id="additional_cat_i"></td><td></td></tr>
                    <tr><td>10</td><td>Cat J. Other (E-Waste)</td><td><input type="number" step="0.01" class="qty" id="additional_cat_j"></td><td></td></tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colspan="2" class="total-cell">Total Vol:</td>
                      <td class="total-cell" id="additional_totalVol">0</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            <div class="mt-4 border rounded-lg">
              <button id="toggleService" class="w-full flex justify-between items-center px-4 py-3 bg-gray-50 hover:bg-gray-100">
                <span class="font-medium">Service Purchase</span>
                <span id="serviceChevron">▼</span>
              </button>
              <div id="servicePanel" class="p-4 hidden">
                <h3 class="mt-6 font-semibold">Vessel Planned to Discharge (Service Purchase)</h3>
                <table>
                  <thead>
                    <tr>
                      <th>No.</th>
                      <th>MARPOL Annex V. Garbage</th>
                      <th>Quantity (m³)</th>
                      <th>Origin</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td>1</td><td>Cat A. Plastic</td><td><input type="number" step="0.01" class="qty" id="service_cat_a"></td><td></td></tr>
                    <tr><td>2</td><td>Cat B. Food Waste</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>3</td><td>Cat C. Domestic Waste</td><td><input type="number" step="0.01" class="qty" id="service_cat_c"></td><td></td></tr>
                    <tr><td>4</td><td>Cat D. Cooking Oil</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>5</td><td>Cat E. Incinerator Ashes</td><td><input type="number" step="0.01" class="qty" id="service_cat_e"></td><td></td></tr>
                    <tr><td>6</td><td>Cat F. Operational Waste</td><td><input type="number" step="0.01" class="qty" id="service_cat_f"></td><td></td></tr>
                    <tr><td>7</td><td>Cat G. Cargo Residue</td><td><input type="number" step="0.01" class="qty" id="service_cat_g"></td><td></td></tr>
                    <tr><td>8</td><td>Cat H. Animal Carcasses</td><td>N/A</td><td>N/A</td></tr>
                    <tr><td>9</td><td>Cat I. Fishing Gear</td><td><input type="number" step="0.01" class="qty" id="service_cat_i"></td><td></td></tr>
                    <tr><td>10</td><td>Cat J. Other (E-Waste)</td><td><input type="number" step="0.01" class="qty" id="service_cat_j"></td><td></td></tr>
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colspan="2" class="total-cell">Total Vol:</td>
                      <td class="total-cell" id="service_totalVol">0</td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

          <div class="mt-4 flex items-center justify-between">
            <button id="newOrderBtn" class="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700 hidden">New Order</button>
            <div class="flex items-center justify-end">
            <button id="submitOrder" class="px-4 py-2 rounded-md bg-green-600 text-white hover:bg-green-700">Submit Discharge Request</button>
            </div>
          </div>
          <p id="msg" class="text-green-700 text-sm h-4 mt-2 text-right"></p>
    </div>`;
}

function switchTab(tab: 'orders' | 'create' | 'last24' | 'next24' | 'kpi') {
  const ordersView = document.getElementById('ordersView')!;
  const createView = document.getElementById('createView')!;
  const kpiView = document.getElementById('kpiView')!;
  const last24View = document.getElementById('last24View')!;
  const next24View = document.getElementById('next24View')!;
  const ordersTab = document.getElementById('ordersTab')!;
  const createTab = document.getElementById('createTab')!;
  const last24Tab = document.getElementById('last24Tab')!;
  const next24Tab = document.getElementById('next24Tab')!;
  const kpiTab = document.getElementById('kpiTab')!;

  // Reset editing state when switching away from create tab
  if (tab !== 'create' && (window as any).editingOrder) {
    (window as any).editingOrder = null;
    createTab.textContent = 'Create Order';
    const titleElement = createView.querySelector('h2')!;
    titleElement.textContent = 'Create New Discharge Order';
    
    // Hide New Order button
    const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
    if (newOrderButton) {
      newOrderButton.classList.add('hidden');
    }
    
    // Reset submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Submit Discharge Request';
    }
  }

  if (tab === 'orders') {
    ordersView.classList.remove('hidden');
    createView.classList.add('hidden');
    last24View.classList.add('hidden');
    next24View.classList.add('hidden');
    kpiView.classList.add('hidden');
    ordersTab.classList.add('border-blue-500', 'text-blue-600');
    ordersTab.classList.remove('border-transparent', 'text-gray-500');
    createTab.classList.add('border-transparent', 'text-gray-500');
    createTab.classList.remove('border-blue-500', 'text-blue-600');
    last24Tab.classList.add('border-transparent', 'text-gray-500');
    last24Tab.classList.remove('border-blue-500', 'text-blue-600');
    next24Tab.classList.add('border-transparent', 'text-gray-500');
    next24Tab.classList.remove('border-blue-500', 'text-blue-600');
    kpiTab.classList.add('border-transparent', 'text-gray-500');
    kpiTab.classList.remove('border-blue-500', 'text-blue-600');
  } else {
    if (tab === 'create') {
      ordersView.classList.add('hidden');
      kpiView.classList.add('hidden');
      last24View.classList.add('hidden');
      next24View.classList.add('hidden');
      createView.classList.remove('hidden');
      createTab.classList.add('border-blue-500', 'text-blue-600');
      createTab.classList.remove('border-transparent', 'text-gray-500');
      ordersTab.classList.add('border-transparent', 'text-gray-500');
      ordersTab.classList.remove('border-blue-500', 'text-blue-600');
      last24Tab.classList.add('border-transparent', 'text-gray-500');
      last24Tab.classList.remove('border-blue-500', 'text-blue-600');
      next24Tab.classList.add('border-transparent', 'text-gray-500');
      next24Tab.classList.remove('border-blue-500', 'text-blue-600');
      kpiTab.classList.add('border-transparent', 'text-gray-500');
      kpiTab.classList.remove('border-blue-500', 'text-blue-600');
      
      // Ensure editing state is cleared when explicitly clicking create tab
      if (!(window as any).editingOrder) {
        // Reset tab title and form title if not in edit mode
        createTab.textContent = 'Create Order';
        const titleElement = createView.querySelector('h2');
        if (titleElement) {
          titleElement.textContent = 'Create New Discharge Order';
        }
        
        // Hide New Order button
        const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
        if (newOrderButton) {
          newOrderButton.classList.add('hidden');
        }
      }
      
      FormHandler.setupFormHandlers();
    } else {
      if (tab === 'last24') {
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        kpiView.classList.add('hidden');
        next24View.classList.add('hidden');
        last24View.classList.remove('hidden');
        last24Tab.classList.add('border-blue-500', 'text-blue-600');
        last24Tab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        next24Tab.classList.add('border-transparent', 'text-gray-500');
        next24Tab.classList.remove('border-blue-500', 'text-blue-600');
        kpiTab.classList.add('border-transparent', 'text-gray-500');
        kpiTab.classList.remove('border-blue-500', 'text-blue-600');
        loadLast24();
      } else if (tab === 'next24') {
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        kpiView.classList.add('hidden');
        last24View.classList.add('hidden');
        next24View.classList.remove('hidden');
        next24Tab.classList.add('border-blue-500', 'text-blue-600');
        next24Tab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        last24Tab.classList.add('border-transparent', 'text-gray-500');
        last24Tab.classList.remove('border-blue-500', 'text-blue-600');
        kpiTab.classList.add('border-transparent', 'text-gray-500');
        kpiTab.classList.remove('border-blue-500', 'text-blue-600');
        loadNext24();
      } else {
        // KPI
        ordersView.classList.add('hidden');
        createView.classList.add('hidden');
        last24View.classList.add('hidden');
        next24View.classList.add('hidden');
        kpiView.classList.remove('hidden');
        kpiTab.classList.add('border-blue-500', 'text-blue-600');
        kpiTab.classList.remove('border-transparent', 'text-gray-500');
        ordersTab.classList.add('border-transparent', 'text-gray-500');
        ordersTab.classList.remove('border-blue-500', 'text-blue-600');
        createTab.classList.add('border-transparent', 'text-gray-500');
        createTab.classList.remove('border-blue-500', 'text-blue-600');
        last24Tab.classList.add('border-transparent', 'text-gray-500');
        last24Tab.classList.remove('border-blue-500', 'text-blue-600');
        next24Tab.classList.add('border-transparent', 'text-gray-500');
        next24Tab.classList.remove('border-blue-500', 'text-blue-600');
        loadKpi();
      }
    }
  }
}

// Token refresh function
async function refreshToken(): Promise<boolean> {
  const refresh = localStorage.getItem('refresh');
  console.log('refreshToken: Refresh token exists:', !!refresh);
  console.log('refreshToken: Refresh token value:', refresh ? refresh.substring(0, 20) + '...' : 'null');
  
  if (!refresh) return false;
  
  try {
    console.log('refreshToken: Attempting token refresh...');
    const res = await fetch(`${apiBase}/auth/refresh/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh })
    });
    
    console.log('refreshToken: Response status:', res.status);
    
    if (res.ok) {
      const data = await res.json();
      localStorage.setItem('access', data.access);
      console.log('refreshToken: Token refreshed successfully');
      return true;
    } else {
      console.log('refreshToken: Token refresh failed with status:', res.status);
    }
  } catch (error) {
    console.error('refreshToken: Token refresh failed with error:', error);
  }
  
  return false;
}

// Enhanced listOrders with token refresh
async function listOrdersWithRefresh() {
  try {
    console.log('listOrdersWithRefresh: Attempting direct API call...');
    return await listOrders();
  } catch (error: any) {
    console.log('listOrdersWithRefresh: API call failed:', error.message);
    if (error.message.includes('401')) {
      console.log('listOrdersWithRefresh: Token expired, attempting refresh...');
      const refreshed = await refreshToken();
      if (refreshed) {
        console.log('listOrdersWithRefresh: Token refreshed, retrying API call...');
        return await listOrders();
      } else {
        console.log('listOrdersWithRefresh: Token refresh failed, redirecting to login...');
        localStorage.removeItem('access');
        localStorage.removeItem('refresh');
        location.reload();
        throw error;
      }
    }
    throw error;
  }
}

async function loadOrders() {
  const ordersTable = document.getElementById('ordersTable')!;
  UIComponents.showLoadingSpinner(ordersTable, 'Loading orders...');

  // Check if user is authenticated
  const access = localStorage.getItem('access');
  console.log('loadOrders: Access token exists:', !!access);
  console.log('loadOrders: Access token value:', access ? access.substring(0, 20) + '...' : 'null');
  
  if (!access) {
    console.log('loadOrders: No access token, showing authentication required message');
    ordersTable.innerHTML = `
      <div class="text-center py-12">
        <div class="text-red-400 text-6xl mb-4">🔒</div>
        <h3 class="text-lg font-medium text-gray-900 mb-2">Authentication Required</h3>
        <p class="text-gray-500">Please log in to view orders.</p>
        <button onclick="location.reload()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Go to Login</button>
      </div>`;
    return;
  }

  try {
    console.log('loadOrders: Attempting to fetch orders...');
    
    // Add timeout to prevent infinite loading
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Request timeout after 10 seconds')), 10000);
    });
    
    const ordersPromise = listOrdersWithRefresh();
    const orders = await Promise.race([ordersPromise, timeoutPromise]) as any[];
    orders.sort(compareOrdersByEtbEta);
    if (orders.length === 0) {
      ordersTable.innerHTML = `
        <div class="text-center py-12">
          <div class="text-gray-400 text-6xl mb-4">📋</div>
          <h3 class="text-lg font-medium text-gray-900 mb-2">No orders found</h3>
          <p class="text-gray-500">No discharge orders have been submitted yet.</p>
        </div>`;
      return;
    }

    // Add filter buttons and table
    ordersTable.innerHTML = `
      <div class="mb-4 flex gap-2">
        <button id="filterAll" onclick="filterOrders('all')" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">All Orders</button>
        <button id="filterCompleted" onclick="filterOrders('completed')" class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Completed Jobs</button>
        <button id="filterIncomplete" onclick="filterOrders('incomplete')" class="px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700">Incomplete Jobs</button>
      </div>
      <div id="filteredOrdersTable">
        ${renderAdminOrdersTable(orders)}
      </div>
    `;
    
    // Store orders globally for filtering
    (window as any).allOrders = orders;
  } catch (error: any) {
    console.error('Error loading orders:', error);
    
    // Check if it's a timeout error
    if (error.message.includes('timeout')) {
      ordersTable.innerHTML = `
        <div class="text-center py-12">
          <div class="text-red-400 text-6xl mb-4">⏱️</div>
          <h3 class="text-lg font-medium text-gray-900 mb-2">Request Timeout</h3>
          <p class="text-gray-500">The request took too long to complete. Please try again.</p>
          <button onclick="loadOrders()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Retry</button>
        </div>`;
      return;
    }
    
    // Check if it's an authentication error
    const isAuthError = error.message.includes('401') || error.message.includes('403');
    const errorMessage = isAuthError 
      ? 'Authentication failed. Please log in again.'
      : 'Failed to load discharge orders. Please try again.';
    
    ordersTable.innerHTML = `
      <div class="text-center py-12">
        <div class="text-red-400 text-6xl mb-4">⚠️</div>
        <h3 class="text-lg font-medium text-gray-900 mb-2">Error loading orders</h3>
        <p class="text-gray-500">${errorMessage}</p>
        ${isAuthError ? '<button onclick="location.reload()" class="mt-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Refresh Page</button>' : ''}
      </div>`;
  }
}

// Filter orders by job status
(window as any).filterOrders = function(status: string) {
  const allOrders = (window as any).allOrders;
  if (!allOrders) return;
  
  let filteredOrders = allOrders;
  if (status === 'completed') {
    filteredOrders = allOrders.filter((order: any) => order.job_status === 'completed');
  } else if (status === 'incomplete') {
    filteredOrders = allOrders.filter((order: any) => order.job_status === 'incomplete');
  }
  
  const filteredTable = document.getElementById('filteredOrdersTable');
  if (filteredTable) {
    filteredTable.innerHTML = renderAdminOrdersTable(filteredOrders);
  }
  
  // Update button styles
  const buttons = ['filterAll', 'filterCompleted', 'filterIncomplete'];
  buttons.forEach(buttonId => {
    const button = document.getElementById(buttonId);
    if (button) {
      button.classList.remove('bg-blue-600', 'bg-green-600', 'bg-orange-600');
      button.classList.add('bg-gray-400');
    }
  });
  
  // Highlight active button
  const activeButton = document.getElementById(`filter${status.charAt(0).toUpperCase() + status.slice(1)}`);
  if (activeButton) {
    activeButton.classList.remove('bg-gray-400');
    if (status === 'all') {
      activeButton.classList.add('bg-blue-600');
    } else if (status === 'completed') {
      activeButton.classList.add('bg-green-600');
    } else if (status === 'incomplete') {
      activeButton.classList.add('bg-orange-600');
    }
  }
};

async function loadLast24() {
  const table = document.getElementById('last24Table')!;
  UIComponents.showLoadingSpinner(table, 'Loading last 24 hours...');
  try {
    const orders = await listOrders();
    const now = new Date();
    const dayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    const completed = orders.filter((o: any) => o.actual_offload_at && new Date(o.actual_offload_at) >= dayAgo && new Date(o.actual_offload_at) <= now);
    completed.sort((a: any, b: any) => new Date(b.actual_offload_at).getTime() - new Date(a.actual_offload_at).getTime());
    table.innerHTML = renderAdminOrdersTable(completed);
  } catch (e: any) {
    table.innerHTML = '<div class="text-center text-red-600">Failed to load</div>';
  }
}

async function loadNext24() {
  const table = document.getElementById('next24Table')!;
  UIComponents.showLoadingSpinner(table, 'Loading next 24 hours...');
  try {
    const orders = await listOrders();
    const now = new Date();
    const next = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const upcoming = orders.filter((o: any) => o.scheduled_offload_at && new Date(o.scheduled_offload_at) >= now && new Date(o.scheduled_offload_at) <= next);
    upcoming.sort((a: any, b: any) => new Date(a.scheduled_offload_at).getTime() - new Date(b.scheduled_offload_at).getTime());
    table.innerHTML = renderAdminOrdersTable(upcoming);
  } catch (e: any) {
    table.innerHTML = '<div class="text-center text-red-600">Failed to load</div>';
  }
}
async function loadKpi() {
  const container = document.getElementById('kpiContainer');
  if (!container) return;
  container.innerHTML = `
    <div class="col-span-full flex justify-center items-center h-24">
      <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      <span class="ml-2 text-gray-600">Calculating KPIs...</span>
    </div>`;

  try {
    const orders = await listOrders();

    const total = orders.length;
    const ms30 = 30 * 60 * 1000;
    const onTime = orders.filter((o: any) => {
      if (!o.scheduled_offload_at || !o.actual_offload_at) return false;
      const diff = Math.abs(new Date(o.actual_offload_at).getTime() - new Date(o.scheduled_offload_at).getTime());
      return diff <= ms30;
    }).length;
    const timelinessPct = total ? Math.round((onTime / total) * 100) : 0;

    const sum = (arr: any[], key: string) => arr.reduce((acc, x) => acc + (parseFloat(x[key] || 0) || 0), 0);
    const supplied = sum(orders, 'ppa_supplied_volume_m3');
    const used = sum(orders, 'used_volume_m3');
    const volumeAllocationPct = supplied > 0 ? Math.round((used / supplied) * 100) : 0;

    const noIncident = orders.filter((o: any) => !o.incident_occurred).length;
    const incidentFreePct = total ? Math.round((noIncident / total) * 100) : 0;

    const docsComplete = orders.filter((o: any) => !!o.docs_complete).length;
    const docsPct = total ? Math.round((docsComplete / total) * 100) : 0;

    const rated = orders.filter((o: any) => typeof o.customer_rating === 'number');
    const avgRating = rated.length ? (rated.reduce((a: number, o: any) => a + (o.customer_rating || 0), 0) / rated.length).toFixed(2) : '0.00';

    const recent = [...orders].sort((a: any,b: any) => (new Date(b.created_at).getTime()-new Date(a.created_at).getTime())).slice(0,5);

    const card = (title: string, value: string, color: string) => `
      <div class="p-5 rounded-xl border shadow-sm bg-white">
        <p class="text-sm text-gray-500">${title}</p>
        <p class="mt-1 text-2xl font-bold ${color}">${value}</p>
      </div>`;

    container.innerHTML = `
      ${card('Timeliness Compliance', timelinessPct + '%', 'text-green-600')}
      ${card('Volume Allocation Used', volumeAllocationPct + '%', 'text-blue-600')}
      ${card('Incident Free', incidentFreePct + '%', 'text-emerald-600')}
      ${card('Documentation Complete', docsPct + '%', 'text-indigo-600')}
      ${card('Customer Rating (avg /5)', String(avgRating), 'text-yellow-600')}
      <div class="col-span-full p-5 rounded-xl border shadow-sm bg-white">
        <p class="text-sm text-gray-500 mb-3">Recent Orders</p>
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
              <tr>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Job ID</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ship Name</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Allocated</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Additional</th>
                <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Service purchase</th>
              </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200 text-sm">
              ${recent.map((o: any) => {
                const allocated = typeof o.total_volume === 'number' ? o.total_volume : parseFloat(o.total_volume || 0) || 0;
                const additional = typeof o.additional_total === 'number' ? o.additional_total : parseFloat(o.additional_total || 0) || 0;
                const service = typeof o.service_purchase_total === 'number' ? o.service_purchase_total : parseFloat(o.service_purchase_total || 0) || 0;
                return `
                  <tr>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-900">${o.id}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${o.ship_name}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${allocated.toFixed(2)}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${additional.toFixed(2)}</td>
                    <td class="px-4 py-2 whitespace-nowrap text-gray-700">${service.toFixed(2)}</td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </div>
    `;
  } catch (e: any) {
    console.error(e);
    container.innerHTML = `<div class="col-span-full text-center text-red-600">Failed to load KPIs</div>`;
  }
}

// Global functions for order actions
(window as any).viewOrderDetails = (orderId: number) => {
  openOrderDetailsModal(orderId);
};

(window as any).sendDischargeCertificate = async (orderId: number) => {
  try {
    // Check if certificate is marked as created
    const checkbox = document.getElementById('discharge_certificate_created') as HTMLInputElement;
    if (!checkbox || !checkbox.checked) {
      UIComponents.showAlert('Please mark the certificate as "Created" before sending', 'error');
      return;
    }
    
    // Fetch the order data
    const order = await getOrder(orderId);
    
    // Generate the discharge certificate
    generateDischargeCertificate(order);
    
    UIComponents.showAlert('Discharge certificate generated successfully!', 'success');
  } catch (error) {
    console.error('Failed to generate discharge certificate:', error);
    UIComponents.showAlert('Failed to generate discharge certificate', 'error');
  }
};

(window as any).toggleSendButton = (orderId: number) => {
  const checkbox = document.getElementById('discharge_certificate_created') as HTMLInputElement;
  const sendButton = document.getElementById(`sendBtn_${orderId}`) as HTMLButtonElement;
  
  if (checkbox && sendButton) {
    if (checkbox.checked) {
      // Enable the button
      sendButton.disabled = false;
      sendButton.className = 'px-3 py-1 bg-green-600 text-white text-sm rounded-md hover:bg-green-700 transition-colors';
    } else {
      // Disable the button
      sendButton.disabled = true;
      sendButton.className = 'px-3 py-1 bg-gray-400 text-white text-sm rounded-md cursor-not-allowed transition-colors';
    }
  }
};

function generateDischargeCertificate(order: any) {
  // Calculate total quantities from all vessel plans
  const totals = calculateTotalQuantities(order);
  
  // Create certificate HTML
  const certificateHTML = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Garbage Discharge Certificate - ${order.ship_name}</title>
      <style>
        @page {
          size: A4;
          margin: 10mm;
        }
        
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: white;
          font-size: 14px;
          line-height: 1.4;
          height: 100vh;
          display: flex;
          flex-direction: column;
        }
        
        .certificate {
          width: 100%;
          height: 100%;
          margin: 0 auto;
          border: 2px solid #333;
          padding: 20px;
          box-sizing: border-box;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }
        
        .header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 25px;
        }
        
        .logo {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        
        .logo-icon {
          width: 45px;
          height: 45px;
          background-image: url('${import.meta.env.BASE_URL}logo.png');
          background-size: contain;
          background-repeat: no-repeat;
          background-position: center;
        }
        
        .logo-text {
          font-weight: bold;
          font-size: 16px;
        }
        
        .logo-subtitle {
          font-size: 12px;
          color: #666;
        }
        
        .title {
          text-align: center;
          font-size: 18px;
          font-weight: bold;
          margin: 20px 0;
        }
        
        .company-info {
          text-align: right;
          font-size: 13px;
        }
        
        .vessel-info {
          display: grid;
          grid-template-columns: repeat(4, 1fr);
          gap: 15px;
          margin-bottom: 25px;
        }
        
        .info-field {
          display: flex;
          flex-direction: column;
        }
        
        .info-label {
          font-size: 11px;
          color: #666;
          margin-bottom: 5px;
        }
        
        .info-value {
          font-weight: bold;
          border-bottom: 1px solid #333;
          padding-bottom: 5px;
          min-height: 20px;
          font-size: 12px;
        }
        
        .table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 25px;
          font-size: 12px;
          flex-grow: 1;
        }
        
        .table th, .table td {
          border: 1px solid #333;
          padding: 8px;
          text-align: center;
        }
        
        .table th {
          background-color: #f0f0f0;
          font-weight: bold;
          font-size: 11px;
          padding: 10px 8px;
        }
        
        .table td {
          padding: 10px 8px;
        }
        
        .quantity-cell {
          background-color: #e8f5e9;
          font-weight: bold;
        }
        
        .total-row {
          background-color: #e8f5e9;
          font-weight: bold;
          font-size: 13px;
        }
        
        .footer {
          text-align: center;
          margin-top: auto;
          font-size: 13px;
        }
        
        .footer-title {
          font-weight: bold;
          margin-bottom: 10px;
          font-size: 14px;
        }
        
        .footer-contact {
          color: #666;
          font-size: 12px;
        }
        
        /* Print-specific styles */
        @media print {
          body {
            margin: 0;
            padding: 0;
            height: auto;
          }
          
          .certificate {
            border: 2px solid #333;
            padding: 20px;
            margin: 0;
            height: auto;
            min-height: 100vh;
          }
          
          .table {
            page-break-inside: avoid;
          }
        }
      </style>
    </head>
    <body>
      <div class="certificate">
        <div class="header">
          <div class="logo">
            <div class="logo-icon"></div>
            <div>
              <div class="logo-text">Kay Marine</div>
              <div class="logo-subtitle">Ship Survey and Services</div>
            </div>
          </div>
          <div class="company-info">
            <div><strong>KAY MARINE PTY LTD</strong></div>
            <div>A.B.N 44 643 899 414</div>
          </div>
        </div>
        
        <div class="title">Garbage Discharge Certificate as per MARPOL Annex V</div>
        
        <div class="vessel-info">
          <div class="info-field">
            <div class="info-label">Ship Name</div>
            <div class="info-value">${order.ship_name || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Berth</div>
            <div class="info-value">${order.berth || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Date</div>
            <div class="info-value">${order.date ? new Date(order.date).toLocaleDateString() : ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Flag</div>
            <div class="info-value">${order.flag || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Port</div>
            <div class="info-value">${order.port || 'Port Hedland'}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Time</div>
            <div class="info-value">${order.time || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">IMO no.</div>
            <div class="info-value">${order.imo_no || ''}</div>
          </div>
          <div class="info-field">
            <div class="info-label">Type</div>
            <div class="info-value">${order.vessel_type || ''}</div>
          </div>
        </div>
        
        <table class="table">
          <thead>
            <tr>
              <th>No.</th>
              <th>MARPOL Annex V. Garbage</th>
              <th>Quantity in Meter cubes</th>
              <th>Origin</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Cat A. Plastic</td>
              <td class="quantity-cell">${totals.cat_a_plastic || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Cat B. Food Waste</td>
              <td>N/A</td>
              <td>N/A</td>
            </tr>
            <tr>
              <td>3</td>
              <td>Cat C. Domestic Waste</td>
              <td class="quantity-cell">${totals.cat_c_domestic_waste || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>4</td>
              <td>Cat D. Cooking Oil (N/A)</td>
              <td>N/A</td>
              <td>N/A</td>
            </tr>
            <tr>
              <td>5</td>
              <td>Cat E. Incinerator Ashes</td>
              <td class="quantity-cell">${totals.cat_e_incinerator_ashes || '0'}</td>
              <td>ER</td>
            </tr>
            <tr>
              <td>6</td>
              <td>Cat F. Operational Waste</td>
              <td class="quantity-cell">${totals.cat_f_operational_waste || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>7</td>
              <td>Cat G. Cargo residue</td>
              <td class="quantity-cell">${totals.cat_g_cargo_residue || '0'}</td>
              <td>Cargo Holds</td>
            </tr>
            <tr>
              <td>8</td>
              <td>Cat H. Animal Carcasses</td>
              <td>N/A</td>
              <td>N/A</td>
            </tr>
            <tr>
              <td>9</td>
              <td>Cat I. Fishing Gear</td>
              <td class="quantity-cell">${totals.cat_i_fishing_gear || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
            <tr>
              <td>10</td>
              <td>Cat J. Other (E-Waste)</td>
              <td class="quantity-cell">${totals.cat_j_other_e_waste || '0'}</td>
              <td>Accommodation /Galley/ Deck</td>
            </tr>
          </tbody>
          <tfoot>
            <tr class="total-row">
              <td colspan="2"><strong>Total Vol:</strong></td>
              <td><strong>${totals.total_volume || '0'} CUBIC</strong></td>
              <td></td>
            </tr>
          </tfoot>
        </table>
        
        <div class="footer">
          <div class="footer-title">**** RECEIVED AT PORT HEDLAND</div>
          <div class="footer-contact">
            <div><strong>Kay Marine</strong></div>
            <div>Ship Survey, Supplies and Services</div>
            <div>info@kaymarine.com.au</div>
          </div>
        </div>
      </div>
    </body>
    </html>
  `;
  
  // Open certificate in new window
  const newWindow = window.open('', '_blank');
  if (newWindow) {
    newWindow.document.write(certificateHTML);
    newWindow.document.close();
    
    // Wait for content to load, then print
    newWindow.onload = () => {
      newWindow.print();
    };
  }
}

function calculateTotalQuantities(order: any) {
  const totals = {
    cat_a_plastic: 0,
    cat_c_domestic_waste: 0,
    cat_e_incinerator_ashes: 0,
    cat_f_operational_waste: 0,
    cat_g_cargo_residue: 0,
    cat_i_fishing_gear: 0,
    cat_j_other_e_waste: 0,
    total_volume: 0
  };
  
  if (order.vessel_plans && order.vessel_plans.length > 0) {
    order.vessel_plans.forEach((plan: any) => {
      totals.cat_a_plastic += parseFloat(plan.cat_a_plastic || 0);
      totals.cat_c_domestic_waste += parseFloat(plan.cat_c_domestic_waste || 0);
      totals.cat_e_incinerator_ashes += parseFloat(plan.cat_e_incinerator_ashes || 0);
      totals.cat_f_operational_waste += parseFloat(plan.cat_f_operational_waste || 0);
      totals.cat_g_cargo_residue += parseFloat(plan.cat_g_cargo_residue || 0);
      totals.cat_i_fishing_gear += parseFloat(plan.cat_i_fishing_gear || 0);
      totals.cat_j_other_e_waste += parseFloat(plan.cat_j_other_e_waste || 0);
    });
    
    // Calculate total volume
    totals.total_volume = totals.cat_a_plastic + totals.cat_c_domestic_waste + 
                          totals.cat_e_incinerator_ashes + totals.cat_f_operational_waste + 
                          totals.cat_g_cargo_residue + totals.cat_i_fishing_gear + 
                          totals.cat_j_other_e_waste;
  }
  
  // Round to 2 decimal places
  Object.keys(totals).forEach(key => {
    if (key !== 'total_volume') {
      (totals as any)[key] = Math.round((totals as any)[key] * 100) / 100;
    }
  });
  totals.total_volume = Math.round(totals.total_volume * 100) / 100;
  
  return totals;
}

function openOrderDetailsModal(orderId: number) {
  // Create modal container
  const overlay = document.createElement('div');
  overlay.id = 'orderModalOverlay';
  overlay.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/50';

  const modal = document.createElement('div');
  modal.className = 'bg-white w-full max-w-3xl max-h-[90vh] rounded-2xl shadow-xl overflow-hidden flex flex-col';
  modal.innerHTML = `
    <div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
      <h3 class="text-lg font-semibold">Operations & Details</h3>
      <button id="closeOrderModal" class="text-gray-500 hover:text-gray-700">✕</button>
    </div>
    <div id="orderModalBody" class="p-6 overflow-y-auto">
      <div class="flex justify-center items-center h-32">
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        <span class="ml-2 text-gray-600">Loading order...</span>
      </div>
    </div>
    <div class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
      <button id="saveOrderStages" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save</button>
      <button id="cancelOrderStages" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Close</button>
    </div>
  `;

  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  const close = () => {
    overlay.remove();
  };
  (document.getElementById('closeOrderModal') as HTMLButtonElement).onclick = close;
  (document.getElementById('cancelOrderStages') as HTMLButtonElement).onclick = close;

  // Load order details
  fetch(`${apiBase}/discharge-forms/${orderId}/`, {
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
  }).then(async (res) => {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const order = await res.json();
    // Preserve current order state for merging partial updates from the modal
    (window as any).currentOrderForStages = order;
    renderOrderStages(order);
    
    // Add event listeners to update job status dropdown when operations change
    setupOperationChangeListeners();
  }).catch((err) => {
    console.error(err);
    const body = document.getElementById('orderModalBody')!;
    body.innerHTML = `<p class="text-red-600">Failed to load order.</p>`;
  });

  (document.getElementById('saveOrderStages') as HTMLButtonElement).onclick = async () => {
    try {
      const payload = collectStageForm();
      // Allow saving regardless of completion status
      await patchOrder(orderId, payload);
      UIComponents.showAlert('Order stages updated', 'success');
      close();
      // Refresh list to reflect color later if needed
      loadOrders();
    } catch (e: any) {
      console.error(e);
      UIComponents.showAlert('Failed to update order stages', 'error');
    }
  };
}

function renderOrderStages(order: any) {
  const color = computeStageColor(order);
  const badgeClass = colorToBadge(color);

  const body = document.getElementById('orderModalBody')!;
  body.innerHTML = `
    <div class="space-y-6">
      <div class="flex items-center justify-between">
  <div>
          <h4 class="text-base font-semibold">${order.ship_name} <span class="text-sm text-gray-500">(IMO: ${order.imo_no || '-'}, ${order.port})</span></h4>
          <p class="text-sm text-gray-500">${new Date(order.date).toLocaleDateString()} • Berth: ${order.berth || '-'}</p>
              </div>
        <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${badgeClass}">
          ${color.toUpperCase()} STATUS
        </span>
            </div>

      <!-- Details section -->
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg border">
        ${detailRow('Vessel Type', order.vessel_type)}
        ${detailRow('Flag', order.flag)}
        ${detailRow('Port', order.port)}
        ${detailRow('Date', new Date(order.date).toLocaleDateString())}
        ${detailRow('Time', order.time || '-')}
        ${detailRow('ETA', order.eta ? new Date(order.eta).toLocaleString() : '-')}
        ${detailRow('ETB', order.etb ? new Date(order.etb).toLocaleString() : '-')}
        ${detailRow('Total Volume (m³)', order.total_volume != null ? String(order.total_volume) : '-')}
        ${detailRow('Scheduled Offload', order.scheduled_offload_at ? new Date(order.scheduled_offload_at).toLocaleString() : '-')}
        ${detailRow('Actual Offload', order.actual_offload_at ? new Date(order.actual_offload_at).toLocaleString() : '-')}
        ${detailRow('PPA Supplied Vol (m³)', order.ppa_supplied_volume_m3 != null ? String(order.ppa_supplied_volume_m3) : '-')}
        ${detailRow('Used Vol (m³)', order.used_volume_m3 != null ? String(order.used_volume_m3) : '-')}
        ${detailRow('Documentation', order.documentation_complete ? 'Complete' : 'Incomplete')}
        ${detailRow('Incident', order.incident_occurred ? 'Occurred' : 'None')}
        ${detailRow('Customer Rating', order.customer_rating != null ? `${order.customer_rating}/5` : '-')}
        ${detailRow('Created', new Date(order.created_at).toLocaleString())}
        ${detailRow('Updated', new Date(order.updated_at).toLocaleString())}
    </div>

      <div class="grid gap-4">
        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot('blue')}
            <div>
              <p class="font-medium">1) Order created</p>
              <p class="text-xs text-gray-500">Order has been created in the system</p>
  </div>
  </div>
          <span class="text-xs text-green-700 bg-green-100 px-2 py-1 rounded">Done</span>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.form44_submitted ? 'green' : 'gray')}
            <div>
              <p class="font-medium">2) Form 44 submitted</p>
              <p class="text-xs text-gray-500">Permission request for ship waste disposal (AUS)</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="form44_submitted" type="checkbox" ${order.form44_submitted ? 'checked' : ''} class="h-4 w-4">
            <span>${order.form44_submitted ? 'Submitted' : 'submitted'}</span>
          </label>
        </div>

        <!-- Verbal clearance taken on phone for Form 44 -->
        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(((order.collecting_checklist && order.collecting_checklist.verbal_clearance) === 'yes') ? 'green' : 'gray')}
            <div>
              <p class="font-medium">Verbal clearance taken on phone for Form 44</p>
              <p class="text-xs text-gray-500">Select Yes/No (defaults to No)</p>
            </div>
          </div>
          <div class="flex items-center gap-4 text-sm">
            ${(() => {
              const saved = order.collecting_checklist?.verbal_clearance || 'no';
              const yesChecked = saved === 'yes' ? 'checked' : '';
              const noChecked = saved !== 'yes' ? 'checked' : '';
              return `
                <label class=\"inline-flex items-center gap-2\"> 
                  <input type=\"radio\" name=\"op_verbal_clearance\" value=\"yes\" ${yesChecked} /> Yes
                </label>
                <label class=\"inline-flex items-center gap-2\"> 
                  <input type=\"radio\" name=\"op_verbal_clearance\" value=\"no\" ${noChecked} /> No
                </label>`;
            })()}
          </div>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.biosecurity_status === 'approved' ? 'orange' : order.biosecurity_status === 'rejected' ? 'red' : 'gray')}
            <div>
              <p class="font-medium">3) Biosecurity permission</p>
              <p class="text-xs text-gray-500">Set to Approved/Rejected/Pending</p>
            </div>
          </div>
          <select id="biosecurity_status" class="border rounded px-2 py-1 text-sm">
            ${selectOption('pending', order.biosecurity_status)}
            ${selectOption('approved', order.biosecurity_status)}
            ${selectOption('rejected', order.biosecurity_status)}
          </select>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.govt_status === 'approved' ? 'green' : order.govt_status === 'rejected' ? 'red' : 'gray')}
            <div>
              <p class="font-medium">4) Custom permission</p>
              <p class="text-xs text-gray-500">Set to Approved/Rejected/Pending</p>
            </div>
          </div>
          <select id="govt_status" class="border rounded px-2 py-1 text-sm">
            ${selectOption('pending', order.govt_status)}
            ${selectOption('approved', order.govt_status)}
            ${selectOption('rejected', order.govt_status)}
          </select>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.bio_witness ? 'green' : 'gray')}
            <div>
              <p class="font-medium">5) Bio security inspector booked to witness disposal</p>
              <p class="text-xs text-gray-500">Set by operations</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="bio_witness" type="checkbox" ${order.bio_witness ? 'checked' : ''} class="h-4 w-4">
            <span>${order.bio_witness ? 'Booked' : 'booked'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.landfill_booked ? 'green' : 'gray')}
            <div>
              <p class="font-medium">6) Landfill booked for disposal</p>
              <p class="text-xs text-gray-500">Set by operations</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="landfill_booked" type="checkbox" ${order.landfill_booked ? 'checked' : ''} class="h-4 w-4">
            <span>${order.landfill_booked ? 'Booked' : 'booked'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.docs_complete ? 'green' : 'gray')}
            <div>
              <p class="font-medium">7) Docs Complete</p>
              <p class="text-xs text-gray-500">All documentation completed</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="docs_complete" type="checkbox" ${order.docs_complete ? 'checked' : ''} class="h-4 w-4">
            <span>${order.docs_complete ? 'Complete' : 'Complete'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.discharge_certificate_created ? 'green' : 'gray')}
            <div>
              <p class="font-medium">8) Create discharge certificate</p>
              <p class="text-xs text-gray-500">Must be created before completion</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
          <label class="inline-flex items-center gap-2 text-sm">
              <input id="discharge_certificate_created" type="checkbox" ${order.discharge_certificate_created ? 'checked' : ''} class="h-4 w-4" onchange="toggleSendButton(${order.id})">
            <span>${order.discharge_certificate_created ? 'Created' : 'Created'}</span>
          </label>
            <button id="sendBtn_${order.id}" onclick="sendDischargeCertificate(${order.id})" class="px-3 py-1 text-white text-sm rounded-md transition-colors ${order.discharge_certificate_created ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'}" ${order.discharge_certificate_created ? '' : 'disabled'}>
              Send
            </button>
          </div>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border">
          <div class="flex items-center gap-3">
            ${dot(order.invoice_created ? 'green' : 'gray')}
            <div>
              <p class="font-medium">9) Invoice</p>
              <p class="text-xs text-gray-500">Invoice generated for the discharge order</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="invoice_created" type="checkbox" ${order.invoice_created ? 'checked' : ''} class="h-4 w-4">
            <span>${order.invoice_created ? 'Created' : 'Created'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border bg-purple-50">
          <div class="flex items-center gap-3">
            ${dot(order.along_side ? 'blue' : 'gray')}
            <div>
              <p class="font-medium">10) Along Side</p>
              <p class="text-xs text-gray-500">Mark as priority order (shows at top of list)</p>
            </div>
          </div>
          <label class="inline-flex items-center gap-2 text-sm">
            <input id="along_side" type="checkbox" ${order.along_side ? 'checked' : ''} onchange="updateAlongSideText()" class="h-4 w-4">
            <span id="along_side_text">${order.along_side ? 'Yes' : 'No'}</span>
          </label>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border bg-yellow-50">
          <div class="flex items-center gap-3">
            ${dot(order.customer_rating ? 'green' : 'gray')}
            <div>
              <p class="font-medium">11) Customer Rating</p>
              <p class="text-xs text-gray-500">Rate the job quality (Admin only)</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
            <select id="customer_rating" class="border rounded px-3 py-1 text-sm">
              <option value="">Not Rated</option>
              <option value="1" ${order.customer_rating === 1 ? 'selected' : ''}>⭐ 1 Star</option>
              <option value="2" ${order.customer_rating === 2 ? 'selected' : ''}>⭐⭐ 2 Stars</option>
              <option value="3" ${order.customer_rating === 3 ? 'selected' : ''}>⭐⭐⭐ 3 Stars</option>
              <option value="4" ${order.customer_rating === 4 ? 'selected' : ''}>⭐⭐⭐⭐ 4 Stars</option>
              <option value="5" ${order.customer_rating === 5 ? 'selected' : ''}>⭐⭐⭐⭐⭐ 5 Stars</option>
            </select>
          </div>
        </div>

        <div class="flex items-center justify-between p-3 rounded-lg border bg-blue-50">
          <div class="flex items-center gap-3">
            ${dot(order.job_status === 'completed' ? 'green' : 'orange')}
            <div>
              <p class="font-medium">12) Job Done</p>
              <p class="text-xs text-gray-500">Mark job as completed when all operations are done</p>
              <p class="text-xs text-red-500 mt-1" id="jobStatusWarning" style="display: none;">⚠️ All operations must be completed before marking job as done</p>
            </div>
          </div>
          <div class="flex items-center gap-3">
            <button id="jobDoneBtn" onclick="markJobDone(${order.id})" class="px-4 py-2 text-sm font-medium rounded-md transition-colors ${areAllOperationsComplete(order) ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-gray-300 text-gray-600 cursor-not-allowed'}" ${areAllOperationsComplete(order) ? '' : 'disabled'}>
              ${order.job_status === 'completed' ? '✓ Job Done' : 'Mark Job Done'}
            </button>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // Setup listeners to update Job Done button when operations change
  setTimeout(() => {
    setupOperationChangeListeners();
  }, 100);
}

// Check if all 9 operations are completed (excluding the automatic "Order created" as point 1)
function areAllOperationsComplete(order: any): boolean {
  return (
    order.form44_submitted === true &&
    order.biosecurity_status === 'approved' &&
    order.govt_status === 'approved' &&
    order.bio_witness === true &&
    order.landfill_booked === true &&
    order.docs_complete === true &&
    order.discharge_certificate_created === true &&
    order.invoice_created === true
  );
}

// Update Along Side text when checkbox changes
(window as any).updateAlongSideText = function() {
  const checkbox = document.getElementById('along_side') as HTMLInputElement;
  const textSpan = document.getElementById('along_side_text');
  if (checkbox && textSpan) {
    textSpan.textContent = checkbox.checked ? 'Yes' : 'No';
  }
};

// Mark job as done - replaces the dropdown
(window as any).markJobDone = async function(orderId: number) {
  // Check if all operations are complete
  const form44 = (document.getElementById('form44_submitted') as HTMLInputElement)?.checked || false;
  const bio = (document.getElementById('biosecurity_status') as HTMLSelectElement)?.value || 'pending';
  const govt = (document.getElementById('govt_status') as HTMLSelectElement)?.value || 'pending';
  const bio_witness = (document.getElementById('bio_witness') as HTMLInputElement)?.checked || false;
  const landfill_booked = (document.getElementById('landfill_booked') as HTMLInputElement)?.checked || false;
  const docs_complete = (document.getElementById('docs_complete') as HTMLInputElement)?.checked || false;
  const discharge_certificate_created = (document.getElementById('discharge_certificate_created') as HTMLInputElement)?.checked || false;
  const invoice_created = (document.getElementById('invoice_created') as HTMLInputElement)?.checked || false;
  
  const allComplete = (
    form44 === true &&
    bio === 'approved' &&
    govt === 'approved' &&
    bio_witness === true &&
    landfill_booked === true &&
    docs_complete === true &&
    discharge_certificate_created === true &&
    invoice_created === true
  );
  
  if (!allComplete) {
    const warningElement = document.getElementById('jobStatusWarning');
    if (warningElement) {
      warningElement.style.display = 'block';
      setTimeout(() => {
        warningElement.style.display = 'none';
      }, 5000);
    }
    UIComponents.showAlert('Cannot mark job as completed. All 9 operations must be finished first.', 'error');
    return;
  }
  
  // Mark as completed
  const payload: any = collectStageForm();
  payload.job_status = 'completed';
  
  try {
    const res = await fetch(`${apiBase}/orders/${orderId}/`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      UIComponents.showAlert('Job marked as completed!', 'success');
      // Update button state
      const jobDoneBtn = document.getElementById('jobDoneBtn') as HTMLButtonElement;
      if (jobDoneBtn) {
        jobDoneBtn.textContent = '✓ Job Done';
        jobDoneBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
        jobDoneBtn.classList.add('bg-green-700');
      }
    } else {
      UIComponents.showAlert('Failed to update job status', 'error');
    }
  } catch (error) {
    UIComponents.showAlert('Error marking job as done', 'error');
  }
};

// Setup event listeners for operation changes to update Job Done button
function setupOperationChangeListeners() {
  const operationElements = [
    'form44_submitted',
    'biosecurity_status', 
    'govt_status',
    'bio_witness',
    'landfill_booked',
    'docs_complete',
    'discharge_certificate_created',
    'invoice_created'
  ];
  
  operationElements.forEach(elementId => {
    const element = document.getElementById(elementId);
    if (element) {
      element.addEventListener('change', () => {
        updateJobDoneButton();
      });
    }
  });
}

// Update Job Done button based on current operation states
function updateJobDoneButton() {
  const jobDoneBtn = document.getElementById('jobDoneBtn') as HTMLButtonElement;
  if (!jobDoneBtn) return;
  
  // Check if all operations are complete
  const form44 = (document.getElementById('form44_submitted') as HTMLInputElement)?.checked || false;
  const bio = (document.getElementById('biosecurity_status') as HTMLSelectElement)?.value || 'pending';
  const govt = (document.getElementById('govt_status') as HTMLSelectElement)?.value || 'pending';
  const bio_witness = (document.getElementById('bio_witness') as HTMLInputElement)?.checked || false;
  const landfill_booked = (document.getElementById('landfill_booked') as HTMLInputElement)?.checked || false;
  const docs_complete = (document.getElementById('docs_complete') as HTMLInputElement)?.checked || false;
  const discharge_certificate_created = (document.getElementById('discharge_certificate_created') as HTMLInputElement)?.checked || false;
  const invoice_created = (document.getElementById('invoice_created') as HTMLInputElement)?.checked || false;
  
  const allComplete = (
    form44 === true &&
    bio === 'approved' &&
    govt === 'approved' &&
    bio_witness === true &&
    landfill_booked === true &&
    docs_complete === true &&
    discharge_certificate_created === true &&
    invoice_created === true
  );
  
  // Update button state
  if (allComplete) {
    jobDoneBtn.disabled = false;
    jobDoneBtn.classList.remove('bg-gray-300', 'text-gray-600', 'cursor-not-allowed');
    jobDoneBtn.classList.add('bg-green-600', 'text-white', 'hover:bg-green-700');
  } else {
    jobDoneBtn.disabled = true;
    jobDoneBtn.classList.remove('bg-green-600', 'text-white', 'hover:bg-green-700');
    jobDoneBtn.classList.add('bg-gray-300', 'text-gray-600', 'cursor-not-allowed');
  }
}

function collectStageForm() {
  const form44 = (document.getElementById('form44_submitted') as HTMLInputElement)?.checked || false;
  const bio = (document.getElementById('biosecurity_status') as HTMLSelectElement)?.value || 'pending';
  const govt = (document.getElementById('govt_status') as HTMLSelectElement)?.value || 'pending';
  const bio_witness = (document.getElementById('bio_witness') as HTMLInputElement)?.checked || false;
  const landfill_booked = (document.getElementById('landfill_booked') as HTMLInputElement)?.checked || false;
  const docs_complete = (document.getElementById('docs_complete') as HTMLInputElement)?.checked || false;
  const discharge_certificate_created = (document.getElementById('discharge_certificate_created') as HTMLInputElement)?.checked || false;
  const invoice_created = (document.getElementById('invoice_created') as HTMLInputElement)?.checked || false;
  const along_side = (document.getElementById('along_side') as HTMLInputElement)?.checked || false;
  const customer_rating = (document.getElementById('customer_rating') as HTMLSelectElement)?.value || null;
  const verbal_clearance = ((document.querySelector('input[name="op_verbal_clearance"]:checked') as HTMLInputElement) || { value: 'no' }).value;
  const existingChecklist = ((window as any).currentOrderForStages?.collecting_checklist) || {};
  const collecting_checklist = { ...existingChecklist, verbal_clearance } as Record<string, string>;
  return {
    form44_submitted: form44,
    biosecurity_status: bio,
    govt_status: govt,
    bio_witness,
    landfill_booked,
    docs_complete,
    discharge_certificate_created,
    invoice_created,
    along_side,
    customer_rating: customer_rating ? parseInt(customer_rating) : null,
    collecting_checklist,
  };
}

// moved to services/orders.ts

function computeStageColor(order: any): 'green' | 'orange' | 'red' | 'gray' {
  if (order.govt_status === 'approved') return 'green';
  if (order.govt_status === 'rejected' || order.biosecurity_status === 'rejected') return 'red';
  if (order.biosecurity_status === 'approved') return 'orange';
  return 'gray';
}

function colorToBadge(color: string) {
  switch (color) {
    case 'green': return 'bg-green-100 text-green-800';
    case 'orange': return 'bg-orange-100 text-orange-800';
    case 'red': return 'bg-red-100 text-red-800';
    default: return 'bg-gray-100 text-gray-800';
  }
}

function dot(color: 'green' | 'orange' | 'red' | 'gray' | 'blue') {
  const map: Record<string,string> = {
    green: 'bg-green-500',
    orange: 'bg-orange-500',
    red: 'bg-red-500',
    gray: 'bg-gray-400',
    blue: 'bg-blue-500',
  };
  return `<span class="h-3 w-3 rounded-full ${map[color]}"></span>`;
}

// Moved to utils/dates.ts

// Moved to utils/sort.ts and utils/dates.ts

function selectOption(value: string, current: string) {
  const selected = value === current ? 'selected' : '';
  const label = value.charAt(0).toUpperCase() + value.slice(1);
  return `<option value="${value}" ${selected}>${label}</option>`;
}

function detailRow(label: string, value: any) {
  const safe = (v: any) => (v === null || v === undefined || v === '' ? '-' : String(v));
  return `
    <div class="flex items-center justify-between gap-4">
      <span class="text-sm text-gray-500">${label}</span>
      <span class="text-sm font-medium text-gray-900">${safe(value)}</span>
    </div>
  `;
}

(window as any).deleteOrder = async (orderId: number) => {
  if (confirm('Are you sure you want to delete this order?')) {
    try {
      await deleteOrderReq(orderId);
        UIComponents.showAlert('Order deleted successfully!', 'success');
      loadOrders();
    } catch (error) {
      console.error('Error deleting order:', error);
      UIComponents.showAlert('Failed to delete order', 'error');
    }
  }
};

(window as any).setSchedule = async (orderId: number) => {
  try {
    const dEl = document.getElementById(`sched_date_${orderId}`) as HTMLInputElement | null;
    const tEl = document.getElementById(`sched_time_${orderId}`) as HTMLInputElement | null;
    const date = dEl?.value || '';
    const time = tEl?.value || '';
    if (!date || !time) {
      UIComponents.showAlert('Please select both date and time for schedule.', 'error');
      return;
    }
    const iso = new Date(`${date}T${time}`);
    if (isNaN(iso.getTime())) {
      UIComponents.showAlert('Invalid schedule date/time.', 'error');
      return;
    }
    await patchOrder(orderId, { scheduled_offload_at: iso.toISOString() });
    UIComponents.showAlert('Schedule updated', 'success');
    // Refresh boat orders table if present; otherwise try admin list
    if (document.getElementById('boatOrdersTable')) {
      loadBoatOrders();
    } else if (document.getElementById('ordersTable')) {
      loadOrders();
    }
    } catch (e: any) {
    console.error(e);
    UIComponents.showAlert('Failed to update schedule', 'error');
  }
};

(window as any).editOrder = async (orderId: number) => {
  try {
    // Fetch the order data
    const order = await getOrder(orderId);
    
    // Store the order data for editing
    (window as any).editingOrder = order;
    
    // Switch to create tab
    switchTab('create');
    
    // Update the tab title to indicate editing mode
    const createTab = document.getElementById('createTab')!;
    createTab.textContent = 'Edit Order';
    
    // Update the form title
    const createView = document.getElementById('createView')!;
    const titleElement = createView.querySelector('h2')!;
    titleElement.textContent = `Edit Discharge Order - ${order.ship_name}`;
    
    // Show New Order button
    const newOrderButton = document.getElementById('newOrderBtn') as HTMLButtonElement;
    if (newOrderButton) {
      newOrderButton.classList.remove('hidden');
    }
    
    // Update submit button text
    const submitButton = document.getElementById('submitOrder') as HTMLButtonElement;
    if (submitButton) {
      submitButton.textContent = 'Update Discharge Order';
    }
    
  } catch (e: any) {
    console.error('Failed to load order for editing:', e);
    UIComponents.showAlert('Failed to load order for editing', 'error');
  }
};

// moved to components/EditOrderModal.ts

async function login(ev: Event) {
  ev.preventDefault();
  const username = (document.getElementById('username') as HTMLInputElement).value;
  const password = (document.getElementById('password') as HTMLInputElement).value;
  const res = await fetch(`${apiBase}/auth/login/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) {
    (document.getElementById('error') as HTMLParagraphElement).textContent = 'Invalid credentials';
    return;
  }
  const data = await res.json();
  localStorage.setItem('access', data.access);
  localStorage.setItem('refresh', data.refresh);
  render();
}

async function logout() {
  const refresh = localStorage.getItem('refresh');
  try {
    await fetch(`${apiBase}/auth/logout/`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('access')}` },
      body: JSON.stringify({ refresh })
    });
  } finally {
    localStorage.removeItem('access');
    localStorage.removeItem('refresh');
    render();
  }
}

render();

// legacy constants removed

// deprecated legacy helpers removed

// deprecated legacy helpers removed

// legacy helpers removed

// legacy helpers removed

// deprecated legacy submission removed

render();
