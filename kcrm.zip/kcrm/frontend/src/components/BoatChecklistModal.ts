import { UIComponents } from '../utils/ui';
import { formatDateInput, formatTimeInput } from '../utils/dates';
import { apiBase } from '../config';

export function openBoatChecklistModal(order: any) {
	const content = `
		<div class="space-y-6 text-sm">
			<h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Vessel Checklist</h2>
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
				<label>Ship Name: <input type="text" id="v_ship_name" value="${order.ship_name || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Flag: <input type="text" id="v_flag" value="${order.flag || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>IMO No: <input type="text" id="v_imo" value="${order.imo_no || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Berth: <input type="text" id="v_berth" value="${order.berth || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Port: <input type="text" id="v_port" value="${order.port || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>Order Created At: <input type="date" id="v_date" value="${formatDateInput(order.date)}" class="border rounded px-2 py-1 w-full"></label>
				<label>Time: <input type="time" id="v_time" value="${formatTimeInput(order.time)}" class="border rounded px-2 py-1 w-full"></label>
			</div>
			<label>Total Volume: <input type="number" step="0.01" id="v_total" value="${order.total_volume || ''}" class="border rounded px-2 py-1 w-32"></label>
			<label>Master's Name & Signature: <input type="text" id="v_master" value="${order.vessel_checklist_meta?.master_signature || ''}" class="border rounded px-2 py-1 w-full"></label>

			<h2 class="text-base font-semibold bg-gray-100 px-3 py-2 rounded">Collecting Boat Checklist</h2>
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
				<label>AA Accredited Person Name & Sign: <input type="text" id="c_aa_person" value="${order.collecting_boat?.accredited_person_1 || ''}" class="border rounded px-2 py-1 w-full" placeholder="Name & signature"></label>
				<label>Collecting Boat Name: <input type="text" id="c_boat" value="${order.collecting_boat?.boat_name || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label>AA Accredited Person Name & Sign (2): <input type="text" id="c_aa_person2" value="${order.collecting_boat?.accredited_person_2 || ''}" class="border rounded px-2 py-1 w-full" placeholder="If second required"></label>
				<label>Truck Reg No: <input type="text" id="c_truck" value="${order.collecting_boat?.truck_reg || ''}" class="border rounded px-2 py-1 w-full"></label>
				<label class="sm:col-span-2">Disposal Date & Time at Landfill: <input type="datetime-local" id="c_disposal" value="${order.collecting_boat?.disposal_time || ''}" class="border rounded px-2 py-1 w-full"></label>
			</div>
			<div class="overflow-x-auto">
				<table class="min-w-full border border-gray-200">
					<thead class="bg-gray-50">
						<tr>
							<th class="px-2 py-1 text-left">No.</th>
							<th class="px-2 py-1 text-left">Checklist Item</th>
							<th class="px-2 py-1 text-left">Yes</th>
							<th class="px-2 py-1 text-left">No</th>
						</tr>
					</thead>
					<tbody>
						${(() => {
							const items = [
								{ label: 'Form 44 submitted', key: 'form44_submitted', isBoolean: true, value: order.form44_submitted },
								{ label: 'Clearance taken from Bio Security (Form 44)', key: 'bio_security_clearance' },
								{ label: 'Clearance taken from Customs (Form 44)', key: 'customs_clearance' },
								{ label: 'Verbal clearance taken on phone for Form 44', key: 'verbal_clearance' },
								{ label: 'Checklist for Accredited Person Completed', key: 'accredited_person_checklist' },
								{ label: 'Checklist for Driver Completed', key: 'driver_checklist' },
								{ label: 'Bio security inspector booked to witness disposal', key: 'bio_witness', isBoolean: true, value: order.bio_witness },
								{ label: 'Landfill booked for disposal', key: 'landfill_booked', isBoolean: true, value: order.landfill_booked }
							];
							return items.map((item, i) => {
								let checkedYes = false;
								let checkedNo = true;
								
								if (item.isBoolean) {
									checkedYes = item.value === true;
									checkedNo = item.value === false || item.value === null || item.value === undefined;
								} else {
									const savedValue = order.collecting_checklist?.[item.key] || '';
									checkedYes = savedValue === 'yes';
									checkedNo = savedValue === 'no' || (!savedValue);
								}
								
								return `
								<tr>
									<td class="px-2 py-1">${i + 1}</td>
									<td class="px-2 py-1">${item.label}</td>
									<td class="px-2 py-1"><input type="radio" name="chk_${item.key}" value="yes" ${checkedYes ? 'checked' : ''}></td>
									<td class="px-2 py-1"><input type="radio" name="chk_${item.key}" value="no" ${checkedNo ? 'checked' : ''}></td>
								</tr>`;
							}).join('');
						})()}
					</tbody>
				</table>
			</div>
			<div class="space-y-3">
				<h3 class="font-semibold">Send to Landfill within 48hrs</h3>
				<table class="min-w-full border border-gray-200">
					<thead class="bg-gray-50">
						<tr>
							<th class="px-2 py-1 text-left">No.</th>
							<th class="px-2 py-1 text-left">Item</th>
							<th class="px-2 py-1 text-left">Yes</th>
							<th class="px-2 py-1 text-left">No</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td class="px-2 py-1">1</td>
							<td class="px-2 py-1">Garbage staying in AA storage</td>
							<td class="px-2 py-1"><input type="radio" name="aa_storage" value="yes" ${order.aa_storage ? 'checked' : ''}></td>
							<td class="px-2 py-1"><input type="radio" name="aa_storage" value="no" ${order.aa_storage ? '' : 'checked'}></td>
						</tr>
						<tr id="aa_storage_times" class="${order.aa_storage ? '' : 'hidden'}">
							<td></td>
							<td class="px-2 py-1 text-right">In/Out Date & Time</td>
							<td colspan="2" class="px-2 py-1">
								<div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
									<input id="aa_in" type="datetime-local" value="${order.aa_storage_in_at ? new Date(order.aa_storage_in_at).toISOString().slice(0, 16) : ''}" class="border rounded px-2 py-1 w-full" placeholder="In at" />
									<input id="aa_out" type="datetime-local" value="${order.aa_storage_out_at ? new Date(order.aa_storage_out_at).toISOString().slice(0, 16) : ''}" class="border rounded px-2 py-1 w-full" placeholder="Out at" />
								</div>
							</td>
						</tr>
						<tr>
							<td class="px-2 py-1">2</td>
							<td class="px-2 py-1">If garbage staying at storage for more than 48hrs, Permission taken from Bio security.</td>
							<td class="px-2 py-1"><input type="radio" name="perm_48" value="yes" disabled></td>
							<td class="px-2 py-1"><input type="radio" name="perm_48" value="no" checked disabled></td>
						</tr>
						<tr>
							<td class="px-2 py-1">3</td>
							<td class="px-2 py-1">Garbage staying onboard truck for 48hr</td>
							<td class="px-2 py-1"><input type="radio" name="truck_48" value="yes" disabled></td>
							<td class="px-2 py-1"><input type="radio" name="truck_48" value="no" checked disabled></td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="p-3 rounded border bg-gray-50">
				<p class="font-medium mb-2">Contingency Plan</p>
				<ol class="list-decimal pl-5 space-y-1 text-gray-700">
					<li>Any spillages subject to biosecurity control from the vehicle must be reported immediately to 1800 020 504 and Supervisor.</li>
					<li>Any spillage inside the vehicle must be reported and cleaned under direction of an Accredited Person at the receiving AA site.</li>
					<li>Clean with recommended disinfectants and enter the name of the AA accredited person.</li>
				</ol>
			</div>
		</div>
	`;

	UIComponents.openModal(`Checklist - ${order.ship_name || ''}`, content, async () => {
		const checklist: Record<string, string> = {};
		const checklistKeys = ['bio_security_clearance', 'customs_clearance', 'verbal_clearance', 'accredited_person_checklist', 'driver_checklist'];
		for (const key of checklistKeys) {
			const sel = document.querySelector(`input[name="chk_${key}"]:checked`) as HTMLInputElement | null;
			checklist[key] = sel?.value || '';
		}
		// Additional section values
		const aaYes = (document.querySelector('input[name="aa_storage"][value="yes"]') as HTMLInputElement | null)?.checked || false;
		const aaIn = (document.getElementById('aa_in') as HTMLInputElement | null)?.value || '';
		const aaOut = (document.getElementById('aa_out') as HTMLInputElement | null)?.value || '';
		
		// Boolean fields that are stored directly on the model, not in collecting_checklist
		const form44Submitted = (document.querySelector('input[name="chk_form44_submitted"]:checked') as HTMLInputElement | null)?.value === 'yes';
		const bioWitness = (document.querySelector('input[name="chk_bio_witness"]:checked') as HTMLInputElement | null)?.value === 'yes';
		const landfillBooked = (document.querySelector('input[name="chk_landfill_booked"]:checked') as HTMLInputElement | null)?.value === 'yes';
		
		const payload = {
			vessel_checklist_meta: {
				ship_name: (document.getElementById('v_ship_name') as HTMLInputElement | null)?.value || '',
				flag: (document.getElementById('v_flag') as HTMLInputElement | null)?.value || '',
				imo_no: (document.getElementById('v_imo') as HTMLInputElement | null)?.value || '',
				berth: (document.getElementById('v_berth') as HTMLInputElement | null)?.value || '',
				port: (document.getElementById('v_port') as HTMLInputElement | null)?.value || '',
				date: (document.getElementById('v_date') as HTMLInputElement | null)?.value || '',
				time: (document.getElementById('v_time') as HTMLInputElement | null)?.value || '',
				total_volume: parseFloat((document.getElementById('v_total') as HTMLInputElement | null)?.value || '0') || 0,
				master_signature: (document.getElementById('v_master') as HTMLInputElement | null)?.value || ''
			},
			collecting_boat: {
				accredited_person_1: (document.getElementById('c_aa_person') as HTMLInputElement | null)?.value || '',
				boat_name: (document.getElementById('c_boat') as HTMLInputElement | null)?.value || '',
				accredited_person_2: (document.getElementById('c_aa_person2') as HTMLInputElement | null)?.value || '',
				truck_reg: (document.getElementById('c_truck') as HTMLInputElement | null)?.value || '',
				disposal_time: (document.getElementById('c_disposal') as HTMLInputElement | null)?.value || ''
			},
			collecting_checklist: checklist,
			aa_storage: aaYes,
			aa_storage_in_at: aaIn || null,
			aa_storage_out_at: aaOut || null,
			form44_submitted: form44Submitted,
			bio_witness: bioWitness,
			landfill_booked: landfillBooked,
			contingency_plan: (document.getElementById('c_contingency') as HTMLTextAreaElement | null)?.value || ''
		};
		
		try {
			const res = await fetch(`${apiBase}/discharge-forms/${order.id}/`, {
				method: 'PATCH',
				headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('access')}` },
				body: JSON.stringify(payload)
			});
			
			if (!res.ok) {
				throw new Error(`HTTP ${res.status}`);
			}
			
			UIComponents.showAlert('Checklist updated successfully!', 'success');
		} catch (error) {
			console.error('Failed to save checklist:', error);
			UIComponents.showAlert('Failed to update checklist', 'error');
			throw error; // Re-throw to prevent auto-close
		}
	});

	// After modal render: wire AA storage toggle to show/hide times row
	const aaYesEl = document.querySelector('input[name="aa_storage"][value="yes"]') as HTMLInputElement | null;
	const aaNoEl = document.querySelector('input[name="aa_storage"][value="no"]') as HTMLInputElement | null;
	const timesRow = document.getElementById('aa_storage_times');
	const updateTimesVisibility = () => {
		if (!timesRow) return;
		const yes = !!aaYesEl?.checked;
		timesRow.classList.toggle('hidden', !yes);
	};
	aaYesEl?.addEventListener('change', updateTimesVisibility);
	aaNoEl?.addEventListener('change', updateTimesVisibility);
	updateTimesVisibility();
}



