import { UIComponents } from '../utils/ui';
import { getOrder, patchOrder } from '../services/orders';

export function openEditOrderModal(orderId: number) {
	const overlay = document.createElement('div');
	overlay.className = 'fixed inset-0 z-50 flex items-center justify-center bg-black/50';
	const modal = document.createElement('div');
	modal.className = 'bg-white w-full max-w-3xl max-h-[90vh] rounded-2xl shadow-xl overflow-hidden flex flex-col';
	modal.innerHTML = `
		<div class="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
			<h3 class="text-lg font-semibold">Edit Order</h3>
			<button id="closeEditModal" class="text-gray-500 hover:text-gray-700">✕</button>
		</div>
		<div id="editModalBody" class="p-6 overflow-y-auto"></div>
		<div class="px-6 py-4 border-t border-gray-100 bg-gray-50 flex justify-end gap-3">
			<button id="saveEditOrder" class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">Save</button>
			<button id="cancelEditOrder" class="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300">Close</button>
		</div>
	`;
	overlay.appendChild(modal);
	document.body.appendChild(overlay);

	const close = () => overlay.remove();
	(document.getElementById('closeEditModal') as HTMLButtonElement).onclick = close;
	(document.getElementById('cancelEditOrder') as HTMLButtonElement).onclick = close;

	const body = document.getElementById('editModalBody')!;
	body.innerHTML = `<div class="flex justify-center items-center h-32"><div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div><span class=\"ml-2 text-gray-600\">Loading order...</span></div>`;

	getOrder(orderId).then((order) => {
		renderEditForm(order);
	}).catch(() => {
		body.innerHTML = `<p class="text-red-600">Failed to load order.</p>`;
	});

	(document.getElementById('saveEditOrder') as HTMLButtonElement).onclick = async () => {
		const payload = collectEditForm();
		try {
			await patchOrder(orderId, payload);
			UIComponents.showAlert('Order updated', 'success');
			close();
			(window as any).loadOrders?.();
		} catch (e) {
			UIComponents.showAlert('Failed to update order', 'error');
		}
	};
}

function renderEditForm(order: any) {
	const body = document.getElementById('editModalBody')!;
	const val = (v: any) => (v ?? '');
	const dtVal = (v: any) => v ? new Date(v).toISOString().slice(0,16) : '';
	body.innerHTML = `
		<div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
			${editField('Ship Name','ship_name', val(order.ship_name))}
			${editField('Berth','berth', val(order.berth))}
			${editField('Date','date', val(order.date), 'date')}
			${editField('Time','time', val(order.time), 'time')}
			${editField('ETA','eta', dtVal(order.eta), 'datetime-local')}
			${editField('ETB','etb', dtVal(order.etb), 'datetime-local')}
			${editField('Port','port', val(order.port))}
			${editField('Flag','flag', val(order.flag))}
			${editField('Vessel Type','vessel_type', val(order.vessel_type))}
			${editField('IMO No.','imo_no', val(order.imo_no))}
			${editField('Scheduled Offload','scheduled_offload_at', dtVal(order.scheduled_offload_at), 'datetime-local')}
			${editField('Actual Offload','actual_offload_at', dtVal(order.actual_offload_at), 'datetime-local')}
			${editField('PPA Supplied Vol (m³)','ppa_supplied_volume_m3', val(order.ppa_supplied_volume_m3), 'number', '0.01')}
			${editField('Used Vol (m³)','used_volume_m3', val(order.used_volume_m3), 'number', '0.01')}
			${selectBool('Documentation Complete','documentation_complete', !!order.documentation_complete)}
			${selectBool('Incident Occurred','incident_occurred', !!order.incident_occurred)}
			${selectBool('Dispose Additional Waste (beyond free 1 m³)','dispose_additional_waste', !!order.dispose_additional_waste)}
			${selectBool('Service Purchased','service_purchased', !!order.service_purchased)}
			${selectBool('Along Side','along_side', !!order.along_side)}
			${editField('Customer Rating (0-10)','customer_rating', val(order.customer_rating), 'number')}
		</div>
		${(() => {
			const isKayAdmin = (() => {
				try {
					const userStr = localStorage.getItem('currentUser');
					if (userStr) {
						const user = JSON.parse(userStr);
						return user.username === 'kayadmin';
					}
				} catch (e) {
					return false;
				}
				return false;
			})();
			
			const defaultNote = 'If yes, we will send you additional bins if another vessel cancels its garbage collection. In that case, we will request you to resubmit the updated discharge form.';
			const noteValue = order.note || defaultNote;
			
			if (isKayAdmin) {
				return `
					<div class="mt-4">
						<label class="text-sm">
							<span class="block text-gray-600 mb-1">Note:</span>
							<textarea id="edit_note" rows="3" class="w-full border rounded px-3 py-2">${noteValue}</textarea>
						</label>
					</div>
				`;
			} else {
				return `
					<div class="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-md">
						<strong class="text-sm">Note:</strong>
						<p class="text-sm text-gray-600 mt-1">${noteValue}</p>
					</div>
				`;
			}
		})()}
	`;
}

function editField(label: string, id: string, value: any, type: string = 'text', step?: string) {
	return `
		<label class="text-sm">
			<span class="block text-gray-600 mb-1">${label}</span>
			<input id="edit_${id}" type="${type}" ${step ? `step=\"${step}\"` : ''} value="${value ?? ''}" class="w-full border rounded px-3 py-2" />
		</label>
	`;
}

function selectBool(label: string, id: string, value: boolean) {
	return `
		<label class="text-sm">
			<span class="block text-gray-600 mb-1">${label}</span>
			<select id="edit_${id}" class="w-full border rounded px-3 py-2">
				<option value="true" ${value ? 'selected' : ''}>Yes</option>
				<option value="false" ${!value ? 'selected' : ''}>No</option>
			</select>
		</label>
	`;
}

function collectEditForm() {
	const g = (id: string) => (document.getElementById(`edit_${id}`) as HTMLInputElement | HTMLSelectElement | null)?.value;
	const num = (v: any) => v === '' || v === null || v === undefined ? null : parseFloat(v);
	const maybe = (v: any) => v === '' ? null : v;
	return {
		ship_name: g('ship_name') || '',
		berth: maybe(g('berth')),
		date: maybe(g('date')),
		time: maybe(g('time')),
		eta: maybe(g('eta')),
		etb: maybe(g('etb')),
		port: g('port') || '',
		flag: maybe(g('flag')),
		vessel_type: maybe(g('vessel_type')),
		imo_no: maybe(g('imo_no')),
		scheduled_offload_at: maybe(g('scheduled_offload_at')),
		actual_offload_at: maybe(g('actual_offload_at')),
		ppa_supplied_volume_m3: num(g('ppa_supplied_volume_m3')),
		used_volume_m3: num(g('used_volume_m3')),
		documentation_complete: (g('documentation_complete') === 'true'),
		incident_occurred: (g('incident_occurred') === 'true'),
		dispose_additional_waste: (g('dispose_additional_waste') === 'true'),
		service_purchased: (g('service_purchased') === 'true'),
		along_side: (g('along_side') === 'true'),
		customer_rating: g('customer_rating') === '' ? null : parseInt(g('customer_rating') as string, 10),
		note: maybe(g('note')),
	};
}

