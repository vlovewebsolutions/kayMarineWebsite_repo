import { formatDateInput, formatTimeInput, formatDateTimeNoTZ } from '../utils/dates';

// Column visibility state
let columnVisibility: Record<string, boolean> = {
	along_side: true,
	ship_name: true,
	date: true,
	berth: true,
	port: false,
	flag: true,
	etb: true,
	total_volume: true,
	scheduled_offload: true,
	job_status: true,
	actions: true
};

export function getColumnVisibility() {
	return columnVisibility;
}

export function setColumnVisibility(col: string, visible: boolean) {
	columnVisibility[col] = visible;
}

export function renderAdminOrdersTable(orders: any[]): string {
	const cols = columnVisibility;
	
	return `
		<div class="overflow-x-auto">
			<table class="min-w-full divide-y divide-gray-200">
				<thead class="bg-gray-50">
					<tr>
						${cols.along_side ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Along Side</th>' : ''}
						${cols.ship_name ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ship Name</th>' : ''}
						${cols.date ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>' : ''}
						${cols.berth ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Berth</th>' : ''}
						${cols.port ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Port</th>' : ''}
						${cols.flag ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Flag</th>' : ''}
						${cols.etb ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ETB</th>' : ''}
						${cols.total_volume ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Volume</th>' : ''}
						${cols.scheduled_offload ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Scheduled Offload</th>' : ''}
						${cols.job_status ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Job Status</th>' : ''}
						${cols.actions ? '<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>' : ''}
					</tr>
				</thead>
				<tbody class="bg-white divide-y divide-gray-200">
					${orders.map((order: any) => {
						// Determine row color based on priority
						let rowClasses = 'hover:bg-gray-50';
						
						// Priority 1: Completed orders - Green
						if (order.job_status === 'completed') {
							rowClasses += ' bg-green-50';
						}
						// Priority 2: Along Side orders - Yellow
						else if (order.along_side) {
							rowClasses += ' bg-yellow-50 border-l-4 border-yellow-400';
						}
						// Priority 3: Collection date is near current date/time (within 24 hours) - Orange
						else if (order.collecting_boat?.collection_time) {
							const collectionTime = new Date(order.collecting_boat.collection_time);
							const now = new Date();
							const hoursUntilCollection = (collectionTime.getTime() - now.getTime()) / (1000 * 60 * 60);
							
							// If collection is within next 24 hours and not in the past
							if (hoursUntilCollection >= 0 && hoursUntilCollection <= 24) {
								rowClasses += ' bg-orange-50 border-l-4 border-orange-400';
							}
						}
						// Priority 4: Newly booked orders (created within last 2 hours) - Light blue/cyan
						else if (order.created_at) {
							const createdAt = new Date(order.created_at);
							const now = new Date();
							const hoursSinceCreation = (now.getTime() - createdAt.getTime()) / (1000 * 60 * 60);
							
							if (hoursSinceCreation <= 2) {
								rowClasses += ' bg-cyan-50 border-l-4 border-cyan-300';
							}
						}
						
						return `
						<tr class="${rowClasses}">
							${cols.along_side ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-center">
								${order.along_side ? '<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">✓</span>' : '-'}
							</td>` : ''}
							${cols.ship_name ? `<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${order.ship_name}</td>` : ''}
							${cols.date ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${new Date(order.date).toLocaleDateString()}</td>` : ''}
							${cols.berth ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.berth || '-'}</td>` : ''}
							${cols.port ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.port || 'Port Hedland'}</td>` : ''}
							${cols.flag ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.flag || '-'}</td>` : ''}
							${cols.etb ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${formatDateTimeNoTZ(order.etb)}</td>` : ''}
							${cols.total_volume ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.total_volume ? order.total_volume + ' m³' : '-'}</td>` : ''}
							${cols.scheduled_offload ? `<td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${order.scheduled_offload_at ? new Date(order.scheduled_offload_at).toLocaleString() : '-'}</td>` : ''}
							${cols.job_status ? `<td class="px-6 py-4 whitespace-nowrap text-sm">
								<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${order.job_status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}">
									${order.job_status === 'completed' ? 'Completed' : 'Incomplete'}
								</span>
							</td>` : ''}
							${cols.actions ? `<td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
								<button onclick="viewOrderDetails(${order.id})" class="text-blue-600 hover:text-blue-900 mr-3">Operations</button>
								<button onclick="editOrder(${order.id})" class="text-green-600 hover:text-green-900 mr-3">Edit</button>
								<button onclick="deleteOrder(${order.id})" class="text-red-600 hover:text-red-900">Delete</button>
							</td>` : ''}
						</tr>
					`;
					}).join('')}
				</tbody>
			</table>
		</div>`;
}

export function renderBoatOrdersTable(orders: any[]): string {
	return `
		<table class="min-w-full divide-y divide-gray-200">
			<thead class="bg-gray-50">
				<tr>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ship Name</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">IMO No</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Berth</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ETB</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Flag</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Volume</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Schedule</th>
					<th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
				</tr>
			</thead>
			<tbody class="bg-white divide-y divide-gray-200">
				${orders.map((o: any) => `
					<tr>
						<td class="px-6 py-4 text-sm text-gray-900">${o.ship_name}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.imo_no || '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.berth || '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${formatDateTimeNoTZ(o.etb)}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.flag || '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-500">${o.total_volume ? o.total_volume + ' m³' : '-'}</td>
						<td class="px-6 py-4 text-sm text-gray-700">
							<div class="flex items-center gap-2">
								<input id="sched_date_${o.id}" type="date" value="${formatDateInput(o.scheduled_offload_at)}" class="border rounded px-2 py-1" />
								<input id="sched_time_${o.id}" type="time" value="${formatTimeInput(o.scheduled_offload_at)}" class="border rounded px-2 py-1" />
								<button class="text-blue-600 hover:text-blue-900" onclick="setSchedule(${o.id})">Set</button>
							</div>
						</td>
						<td class="px-6 py-4 text-sm">
							<button class="text-blue-600 hover:text-blue-900" onclick="boatOrderView(${o.id})">View</button>
						</td>
					</tr>
				`).join('')}
			</tbody>
		</table>`;
}



