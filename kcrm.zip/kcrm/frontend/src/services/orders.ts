import { apiBase } from '../config';

export async function listOrders() {
	console.log('listOrders: Starting API call...');
	console.log('listOrders: API Base URL:', `${apiBase}/discharge-forms/`);
	const token = localStorage.getItem('access');
	console.log('listOrders: Token exists:', !!token);
	console.log('listOrders: Token value:', token ? token.substring(0, 20) + '...' : 'null');
	
	const res = await fetch(`${apiBase}/discharge-forms/`, {
		headers: { 'Authorization': `Bearer ${token}` }
	});
	
	console.log('listOrders: Response status:', res.status);
	console.log('listOrders: Response headers:', Object.fromEntries(res.headers.entries()));
	
	if (!res.ok) {
		console.error('listOrders: API call failed with status:', res.status);
		const errorText = await res.text();
		console.error('listOrders: Error response:', errorText);
		throw new Error(`HTTP ${res.status}`);
	}
	
	const data = await res.json();
	console.log('listOrders: Successfully fetched orders:', data.length);
	return data;
}

export async function getOrder(orderId: number) {
	const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
		headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
	});
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
	return await res.json();
}

export async function patchOrder(orderId: number, payload: any) {
	const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
		method: 'PATCH',
		headers: {
			'Content-Type': 'application/json',
			'Authorization': `Bearer ${localStorage.getItem('access')}`
		},
		body: JSON.stringify(payload)
	});
	if (!res.ok) {
		const data = await res.json().catch(() => ({}));
		throw new Error(data.detail || `HTTP ${res.status}`);
	}
}

export async function deleteOrderReq(orderId: number) {
	const res = await fetch(`${apiBase}/discharge-forms/${orderId}/`, {
		method: 'DELETE',
		headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
	});
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

export async function uploadIndependentReceipt(date: string, file: File) {
  const form = new FormData();
  form.append('file', file);
  form.append('date', date);
  const res = await fetch(`${apiBase}/independent-receipts/upload/`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` },
    body: form,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

export async function getIndependentReceipts(date: string) {
  const res = await fetch(`${apiBase}/independent-receipts/?date=${date}`, {
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

export async function uploadIncidentDocument(orderId: number, file: File) {
  const form = new FormData();
  form.append('file', file);
  const res = await fetch(`${apiBase}/discharge-forms/${orderId}/upload-incident-document/`, {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` },
    body: form,
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

export async function deleteIncidentDocument(documentId: number) {
  const res = await fetch(`${apiBase}/incident-documents/${documentId}/`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${localStorage.getItem('access')}` }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
}

