Kay Marine CRM - Backend/Frontend Monorepo

Backend
- Django REST API with JWT (SimpleJWT) and token blacklist for logout
- Postgres-ready via environment variables; falls back to SQLite for local dev

## Quick Start (Windows)

### Option 1: Use Batch Scripts (Recommended)
1. Double-click `start_both.bat` to start both backend and frontend
2. Or use individual scripts:
   - `start_backend.bat` - Start Django server only
   - `start_frontend.bat` - Start frontend dev server only

### Option 2: Manual Setup
1) Create venv and install requirements: `python -m venv .venv && .venv/Scripts/python -m pip install -r requirements.txt`
2) Create a `.env` file based on the variables below.
3) Run migrations and start server: `.venv/Scripts/python manage.py migrate && .venv/Scripts\python manage.py runserver`

### Option 3: VS Code/Cursor Integration
- Open project in VS Code/Cursor
- Use `Ctrl+Shift+P` → "Python: Select Interpreter" → Choose `.venv/Scripts/python.exe`
- Use F5 to debug Django server (configured in `.vscode/launch.json`)

Environment variables
- DJANGO_SECRET_KEY
- DJANGO_ALLOWED_HOSTS
- POSTGRES_DB, POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_HOST, POSTGRES_PORT (optional)
- CORS_ALLOW_ALL, CORS_ALLOWED_ORIGINS
- JWT_ACCESS_MINUTES, JWT_REFRESH_DAYS

Auth endpoints
- POST `/api/auth/login/` → username, password → returns access/refresh
- POST `/api/auth/refresh/` → refresh → returns new access
- POST `/api/auth/logout/` → refresh → blacklists token
- GET `/api/auth/me/` → current user profile (Bearer access token)

Frontend
- React (Vite) with Tailwind planned; login page with provided brand colors and logo


