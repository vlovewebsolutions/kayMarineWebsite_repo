# Kay Marine CRM

A Customer Relationship Management system for Kay Marine, built with Django (backend) and React/TypeScript (frontend).

## 🚀 Quick Start

### For Development (Windows)

1. **Install Dependencies:**
   ```bash
   # Python
   pip install -r requirements.txt
   
   # Node.js
   cd frontend
   npm install
   cd ..
   ```

2. **Start the Application:**
   - Double-click `start_both.bat` (recommended)
   - Or manually:
     - Backend: `python manage.py runserver 127.0.0.1:8004`
     - Frontend: `cd frontend && npm run dev`

3. **Access:**
   - Frontend: http://localhost:5173/crm/
   - Backend API: http://localhost:8004/api/
   - Admin: http://localhost:8004/admin/

### Default Users:
- **Admin**: `kayadmin` / `kayadmin@123`
- **Boat User**: `boatadmin` / `BoatAdmin@marine`

---

## 📦 Deployment to Production

### Step 1: Prepare Zip File (Windows)

**Exclude from zip:**
- `node_modules/`
- `.venv/`
- `__pycache__/`
- `frontend/dist/`

**Keep in zip:**
- ✅ `db.sqlite3` (your database!)
- ✅ `media/` folder (uploaded receipts!)
- ✅ All source code
- ✅ `requirements.txt`
- ✅ `package.json` and `package-lock.json`

### Step 2: Upload to Server

Upload zip file to `/home/vinit/` on your VPS.

### Step 3: Deploy (SSH to Server)

```bash
# SSH to server
ssh vinit@your-server-ip

# Extract
cd /home/vinit
unzip -o kaymarine_crm.zip

# Navigate to project
cd kaymarine_crm

# Run deployment
chmod +x deploy_prod.sh
./deploy_prod.sh
```

### Production URL:
https://kaymarine.com.au/crm/

---

## 📁 Project Structure

```
kaymarine_crm/
├── accounts/          # User authentication app
├── crm_app/           # Main CRM application
├── frontend/          # React/Vite frontend
├── server/            # Django project settings
├── db.sqlite3         # SQLite database
├── media/             # Uploaded files (receipts)
├── manage.py          # Django management script
├── requirements.txt   # Python dependencies
├── deploy_prod.sh     # Production deployment script
└── start_*.bat        # Windows start scripts
```

---

## 🔧 Configuration

### Development Settings (`server/settings.py`)
- DEBUG = True
- Runs on port 8000
- Uses SQLite database

### Production Settings (`server/settings_production.py`)
- DEBUG = False
- Runs on port 8004 via Gunicorn
- Served under `/crm/` subdirectory
- Uses SQLite database

### Frontend Config (`frontend/src/config.ts`)
- Development: `http://localhost:8004/api`
- Production: `/crm/api` (relative path)

---

## 📚 Documentation

- **Quick Start**: See `QUICK_START.md`
- **Deployment Guide**: See `DEPLOYMENT_SUMMARY.md`
- **Detailed Instructions**: See `DEPLOY_INSTRUCTIONS.md`

---

## 🛠️ Management Commands

### Django Management:
```bash
# Create superuser
python manage.py createsuperuser

# Run migrations
python manage.py migrate

# Collect static files
python manage.py collectstatic --noinput

# Open Django shell
python manage.py shell
```

### Production Service:
```bash
# Check status
sudo supervisorctl status kaymarine_crm

# Restart
sudo supervisorctl restart kaymarine_crm

# View logs
tail -f /home/vinit/kaymarine_crm/logs/app.log
```

---

## 🔄 Update Workflow

1. Make changes on Windows
2. Test locally
3. Create zip (excluding node_modules, .venv, etc.)
4. Upload to server
5. SSH and run: `./deploy_prod.sh`

---

## ⚠️ Important Notes

1. **Always include `db.sqlite3`** in deployment to preserve data
2. **Always include `media/` folder** to preserve uploaded receipts
3. **Environment auto-detects**: No manual configuration needed
4. **Port 8004** is used in production to avoid conflicts
5. **Nginx handles routing** at `/crm/` path

---

## 🐛 Troubleshooting

**Frontend not loading?**
```bash
cd frontend
npm install
npm run build
```

**Backend not starting?**
```bash
pip install -r requirements.txt
python manage.py runserver
```

**Production issues?**
```bash
sudo supervisorctl restart kaymarine_crm
sudo systemctl reload nginx
tail -f /home/vinit/kaymarine_crm/logs/app.log
```

---

## 📞 Support

For detailed deployment instructions, see:
- `DEPLOYMENT_SUMMARY.md` - Quick reference
- `DEPLOY_INSTRUCTIONS.md` - Detailed guide
- `QUICK_START.md` - Development setup
