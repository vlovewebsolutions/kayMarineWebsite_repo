#!/bin/bash
# Deployment script for Kay Marine CRM
# Run this after uploading the project to the server

set -e

echo "========================================="
echo "Kay Marine CRM - Production Deployment"
echo "========================================="

# Get project directory
PROJECT_DIR="/home/vinit/kaymarine_crm"
cd "$PROJECT_DIR"

echo ""
echo "Step 1: Setting up Python virtual environment..."
if [ ! -d ".venv" ]; then
    python3 -m venv .venv
fi
source .venv/bin/activate

echo ""
echo "Step 2: Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "Step 3: Building frontend for production..."
cd frontend
npm install
npm run build
cd ..

echo ""
echo "Step 4: Collecting static files..."
python manage.py collectstatic --noinput

echo ""
echo "Step 5: Running database migrations..."
python manage.py migrate

echo ""
echo "Step 6: Restarting Supervisor..."
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl restart kaymarine_crm

echo ""
echo "Step 7: Reloading Nginx..."
sudo nginx -t
sudo systemctl reload nginx

echo ""
echo "========================================="
echo "Deployment completed successfully!"
echo "Visit: https://kaymarine.com.au/crm/"
echo "========================================="

