import os
from .settings import *

# Security settings
DEBUG = False
ALLOWED_HOSTS = ['kaymarine.com.au', 'www.kaymarine.com.au', '127.0.0.1', 'localhost']

# Database - SQLite (default)
DATABASES = {
            'default': {
                        'ENGINE': 'django.db.backends.sqlite3',
                                'NAME': BASE_DIR / 'db.sqlite3',
                                    }
            }

# Static files
STATIC_URL = '/crm/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Media files
MEDIA_URL = '/crm/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# Security
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'

# CORS settings
CORS_ALLOWED_ORIGINS = [
            "https://kaymarine.com.au",
                "http://kaymarine.com.au",
                ]

# URL prefix for subdirectory deployment
FORCE_SCRIPT_NAME = '/crm'