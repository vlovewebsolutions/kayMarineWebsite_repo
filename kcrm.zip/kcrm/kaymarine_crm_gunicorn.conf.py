import multiprocessing

# Server socket
bind = "127.0.0.1:8004"  # Changed from 8003 to 8004
backlog = 2048

# Worker processes
workers = 3
worker_class = 'sync'
worker_connections = 1000
timeout = 30
keepalive = 2

# Restart workers
max_requests = 1000
max_requests_jitter = 50

# Logging
accesslog = '/var/log/kaymarine_crm/gunicorn_access.log'
errorlog = '/var/log/kaymarine_crm/gunicorn_error.log'
loglevel = 'info'

# Process naming
proc_name = 'kaymarine_crm'

# Server mechanics
daemon = False  # Changed to False for supervisor
user = 'vinit'
group = 'vinit'

# Django settings
env = 'DJANGO_SETTINGS_MODULE=server.settings_production'