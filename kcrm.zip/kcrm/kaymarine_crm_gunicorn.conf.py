# Gunicorn Configuration for Kay Marine CRM

# kaymarine_crm_gunicorn.conf.py
import multiprocessing

# Server socket
bind = "127.0.0.1:8003"  # Use port 8003 for third app
backlog = 2048

# Worker processes
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = 'sync'
worker_connections = 1000
timeout = 30
keepalive = 2

# Restart workers after this many requests, to prevent memory leaks
max_requests = 1000
max_requests_jitter = 50

# Logging
accesslog = '/var/log/kaymarine_crm/gunicorn_access.log'
errorlog = '/var/log/kaymarine_crm/gunicorn_error.log'
loglevel = 'info'
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# Process naming
proc_name = 'kaymarine_crm'

# Server mechanics
daemon = False
pidfile = '/var/run/kaymarine_crm.pid'
user = 'www-data'
group = 'www-data'
tmp_upload_dir = None

# SSL (if needed)
# keyfile = '/path/to/keyfile'
# certfile = '/path/to/certfile'
