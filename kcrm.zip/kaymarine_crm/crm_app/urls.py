from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ShipDetailsViewSet, DischargeFormViewSet, VesselPlanViewSet, LandfillReceiptViewSet, IncidentDocumentViewSet, BoatCompanyViewSet

router = DefaultRouter()
router.register(r'ship-details', ShipDetailsViewSet, basename='ship-details')
router.register(r'discharge-forms', DischargeFormViewSet, basename='discharge-form')
router.register(r'vessel-plans', VesselPlanViewSet, basename='vessel-plan')
router.register(r'landfill-receipts', LandfillReceiptViewSet, basename='landfill-receipt')
router.register(r'incident-documents', IncidentDocumentViewSet, basename='incident-document')
router.register(r'boat-companies', BoatCompanyViewSet, basename='boat-company')

urlpatterns = [
    path('', include(router.urls)),
]


