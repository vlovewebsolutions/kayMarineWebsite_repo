from rest_framework import viewsets, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework import status
from .models import ShipDetails, DischargeForm, VesselPlan, LandfillReceipt, IncidentDocument, BoatCompany
from .serializers import ShipDetailsSerializer, DischargeFormSerializer, VesselPlanSerializer, LandfillReceiptSerializer, IncidentDocumentSerializer, BoatCompanySerializer


class IsAdminOrReadOnly(permissions.BasePermission):
    def has_permission(self, request, view):
        if request.method in ('GET', 'HEAD', 'OPTIONS'):
            return request.user and request.user.is_authenticated
        return request.user and request.user.is_staff


class BoatCompanyViewSet(viewsets.ModelViewSet):
    queryset = BoatCompany.objects.all()
    serializer_class = BoatCompanySerializer
    permission_classes = [permissions.IsAuthenticated]

class BoatUserSchedulePermission(permissions.BasePermission):
    """
    Custom permission for boat users to update scheduling and checklist fields.
    Allows boat users to update scheduled_offload_at and checklist-related fields.
    """
    
    # Fields that boat users are allowed to update
    ALLOWED_FIELDS = {
        'scheduled_offload_at',
        'vessel_checklist_meta',
        'collecting_boat',
        'collecting_checklist',
        'aa_storage',
        'aa_storage_in_at',
        'aa_storage_out_at',
        'form44_submitted',
        'bio_witness',
        'landfill_booked',
        'contingency_plan',
        'reason_storage',
        'staying_less_than_48',
        'staying_more_than_48',
        'perm_48',
    }
    
    def has_permission(self, request, view):
        # Allow GET requests for authenticated users
        if request.method in ('GET', 'HEAD', 'OPTIONS'):
            return request.user and request.user.is_authenticated
        
        # Allow POST/PATCH/PUT/DELETE for authenticated users (we'll check permissions in has_object_permission)
        if request.method in ('POST', 'PATCH', 'PUT', 'DELETE'):
            return request.user and request.user.is_authenticated
        
        return False
    
    def has_object_permission(self, request, view, obj):
        # Allow GET requests for authenticated users
        if request.method in ('GET', 'HEAD', 'OPTIONS'):
            return request.user and request.user.is_authenticated
        
        # Admin users can do anything
        if request.user and request.user.is_staff:
            return True
        
        # For boat users, only allow updates to specific fields
        if request.method in ('PATCH', 'PUT'):
            # Check if the request only contains allowed fields
            if hasattr(request, 'data'):
                request_fields = set(request.data.keys())
                # Only allow requests that only contain allowed fields
                return request_fields.issubset(self.ALLOWED_FIELDS)
        
        # For POST requests, boat users cannot create new orders
        if request.method == 'POST':
            return request.user and request.user.is_staff
        
        # For DELETE requests, only admin users can delete orders
        if request.method == 'DELETE':
            return request.user and request.user.is_staff
        
        return False


class DischargeFormViewSet(viewsets.ModelViewSet):
    queryset = DischargeForm.objects.all()
    serializer_class = DischargeFormSerializer
    permission_classes = [BoatUserSchedulePermission]

    def get_queryset(self):

        qs = DischargeForm.objects.all().order_by('-created_at')

        user = self.request.user

        # Check if admin selected a boat-company preview mode
        selected_company = self.request.headers.get("X-Boat-Company")

        # Admin user
        if user.is_staff:

            # If admin switched to boat-company interface
            if selected_company:
                return qs.filter(
                    assigned_boat_company__name__iexact=selected_company
                )

            # Normal admin interface
            return qs

        # Boat users see only their assigned jobs
        return qs.filter(
            assigned_boat_company__name__iexact=user.username
        )

    def create(self, request, *args, **kwargs):
        """Handle creation with ship details and vessel plans"""
        data = request.data.copy()
        
        # Extract ship details from the main data
        ship_data = {
            'ship_name': data.pop('ship_name', ''),
            'berth': data.pop('berth', None) or None,  # Convert empty string to None
            'port': data.pop('port', 'Port Hedland'),
            'flag': data.pop('flag', None) or None,  # Convert empty string to None
            'vessel_type': data.pop('vessel_type', None) or None,  # Convert empty string to None
            'imo_no': data.pop('imo_no', None) or None,  # Convert empty string to None
            'voyage_number': data.pop('voyage_number', None) or None,  # Convert empty string to None
            'eta': data.pop('eta', None),
            'etb': data.pop('etb', None),
        }
        
        # Create ShipDetails first
        ship_details = ShipDetails.objects.create(**ship_data)
        
        # Add ship_details to the main data
        data['ship_details'] = ship_details.id
        
        # Extract vessel plan data for all three tables
        free_plan_data = {
            'plan_type': 'free',
            'cat_a_plastic': data.pop('cat_a_plastic', None),
            'cat_c_domestic_waste': data.pop('cat_c_domestic_waste', None),
            'cat_e_incinerator_ashes': data.pop('cat_e_incinerator_ashes', None),
            'cat_f_operational_waste': data.pop('cat_f_operational_waste', None),
            'cat_g_cargo_residue': data.pop('cat_g_cargo_residue', None),
            'cat_i_fishing_gear': data.pop('cat_i_fishing_gear', None),
            'cat_j_other_e_waste': data.pop('cat_j_other_e_waste', None),
            'cat_a_plastic_origin': data.pop('cat_a_plastic_origin', []),
            'cat_c_domestic_waste_origin': data.pop('cat_c_domestic_waste_origin', []),
            'cat_e_incinerator_ashes_origin': data.pop('cat_e_incinerator_ashes_origin', []),
            'cat_f_operational_waste_origin': data.pop('cat_f_operational_waste_origin', []),
            'cat_g_cargo_residue_origin': data.pop('cat_g_cargo_residue_origin', []),
            'cat_i_fishing_gear_origin': data.pop('cat_i_fishing_gear_origin', []),
            'cat_j_other_e_waste_origin': data.pop('cat_j_other_e_waste_origin', []),
        }
        
        additional_plan_data = {
            'plan_type': 'additional',
            'cat_a_plastic': data.pop('additional_cat_a_plastic', None),
            'cat_c_domestic_waste': data.pop('additional_cat_c_domestic_waste', None),
            'cat_e_incinerator_ashes': data.pop('additional_cat_e_incinerator_ashes', None),
            'cat_f_operational_waste': data.pop('additional_cat_f_operational_waste', None),
            'cat_g_cargo_residue': data.pop('additional_cat_g_cargo_residue', None),
            'cat_i_fishing_gear': data.pop('additional_cat_i_fishing_gear', None),
            'cat_j_other_e_waste': data.pop('additional_cat_j_other_e_waste', None),
            'cat_a_plastic_origin': data.pop('additional_cat_a_plastic_origin', []),
            'cat_c_domestic_waste_origin': data.pop('additional_cat_c_domestic_waste_origin', []),
            'cat_e_incinerator_ashes_origin': data.pop('additional_cat_e_incinerator_ashes_origin', []),
            'cat_f_operational_waste_origin': data.pop('additional_cat_f_operational_waste_origin', []),
            'cat_g_cargo_residue_origin': data.pop('additional_cat_g_cargo_residue_origin', []),
            'cat_i_fishing_gear_origin': data.pop('additional_cat_i_fishing_gear_origin', []),
            'cat_j_other_e_waste_origin': data.pop('additional_cat_j_other_e_waste_origin', []),
        }
        
        service_plan_data = {
            'plan_type': 'service_purchase',
            'cat_a_plastic': data.pop('service_cat_a_plastic', None),
            'cat_c_domestic_waste': data.pop('service_cat_c_domestic_waste', None),
            'cat_e_incinerator_ashes': data.pop('service_cat_e_incinerator_ashes', None),
            'cat_f_operational_waste': data.pop('service_cat_f_operational_waste', None),
            'cat_g_cargo_residue': data.pop('service_cat_g_cargo_residue', None),
            'cat_i_fishing_gear': data.pop('service_cat_i_fishing_gear', None),
            'cat_j_other_e_waste': data.pop('service_cat_j_other_e_waste', None),
            'cat_a_plastic_origin': data.pop('service_cat_a_plastic_origin', []),
            'cat_c_domestic_waste_origin': data.pop('service_cat_c_domestic_waste_origin', []),
            'cat_e_incinerator_ashes_origin': data.pop('service_cat_e_incinerator_ashes_origin', []),
            'cat_f_operational_waste_origin': data.pop('service_cat_f_operational_waste_origin', []),
            'cat_g_cargo_residue_origin': data.pop('service_cat_g_cargo_residue_origin', []),
            'cat_i_fishing_gear_origin': data.pop('service_cat_i_fishing_gear_origin', []),
            'cat_j_other_e_waste_origin': data.pop('service_cat_j_other_e_waste_origin', []),
        }
        
        # Create serializer with updated data
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        discharge_form = serializer.save()
        
        # Ensure the ship_details relationship is properly set
        discharge_form.ship_details = ship_details
        discharge_form.save()
        
        # Create vessel plans for all three tables
        free_plan_data['discharge_form'] = discharge_form
        VesselPlan.objects.create(**free_plan_data)
        
        # Only create additional plan if dispose_additional_waste is True AND there's data
        if discharge_form.dispose_additional_waste and any(additional_plan_data[key] for key in additional_plan_data if key != 'plan_type'):
            additional_plan_data['discharge_form'] = discharge_form
            VesselPlan.objects.create(**additional_plan_data)
        
        # Only create service plan if service_purchased is True AND there's data
        if discharge_form.service_purchased and any(service_plan_data[key] for key in service_plan_data if key != 'plan_type'):
            service_plan_data['discharge_form'] = discharge_form
            VesselPlan.objects.create(**service_plan_data)
        
        headers = self.get_success_headers(serializer.data)
        return Response(serializer.data, status=status.HTTP_201_CREATED, headers=headers)

    def update(self, request, *args, **kwargs):
        """Handle updates with ship details and vessel plans"""
        instance = self.get_object()
        data = request.data.copy()
        
        # Extract ship details from the main data
        ship_data = {
            'ship_name': data.pop('ship_name', None),
            'berth': data.pop('berth', None),
            'port': data.pop('port', None),
            'flag': data.pop('flag', None),
            'vessel_type': data.pop('vessel_type', None),
            'imo_no': data.pop('imo_no', None),
            'voyage_number': data.pop('voyage_number', None),
            'eta': data.pop('eta', None),
            'etb': data.pop('etb', None),
        }
        
        # Update ship details if provided
        if instance.ship_details and any(ship_data.values()):
            ship_serializer = ShipDetailsSerializer(instance.ship_details, data=ship_data, partial=True)
            if ship_serializer.is_valid():
                ship_serializer.save()
        
        # Extract vessel plan data for all three tables
        # Use a special marker to distinguish between "not sent" and "sent as None"
        free_plan_data = {}
        if 'cat_a_plastic' in data:
            free_plan_data['cat_a_plastic'] = data.pop('cat_a_plastic', None)
        if 'cat_c_domestic_waste' in data:
            free_plan_data['cat_c_domestic_waste'] = data.pop('cat_c_domestic_waste', None)
        if 'cat_e_incinerator_ashes' in data:
            free_plan_data['cat_e_incinerator_ashes'] = data.pop('cat_e_incinerator_ashes', None)
        if 'cat_f_operational_waste' in data:
            free_plan_data['cat_f_operational_waste'] = data.pop('cat_f_operational_waste', None)
        if 'cat_g_cargo_residue' in data:
            free_plan_data['cat_g_cargo_residue'] = data.pop('cat_g_cargo_residue', None)
        if 'cat_i_fishing_gear' in data:
            free_plan_data['cat_i_fishing_gear'] = data.pop('cat_i_fishing_gear', None)
        if 'cat_j_other_e_waste' in data:
            free_plan_data['cat_j_other_e_waste'] = data.pop('cat_j_other_e_waste', None)
        if 'cat_a_plastic_origin' in data:
            free_plan_data['cat_a_plastic_origin'] = data.pop('cat_a_plastic_origin', [])
        if 'cat_c_domestic_waste_origin' in data:
            free_plan_data['cat_c_domestic_waste_origin'] = data.pop('cat_c_domestic_waste_origin', [])
        if 'cat_e_incinerator_ashes_origin' in data:
            free_plan_data['cat_e_incinerator_ashes_origin'] = data.pop('cat_e_incinerator_ashes_origin', [])
        if 'cat_f_operational_waste_origin' in data:
            free_plan_data['cat_f_operational_waste_origin'] = data.pop('cat_f_operational_waste_origin', [])
        if 'cat_g_cargo_residue_origin' in data:
            free_plan_data['cat_g_cargo_residue_origin'] = data.pop('cat_g_cargo_residue_origin', [])
        if 'cat_i_fishing_gear_origin' in data:
            free_plan_data['cat_i_fishing_gear_origin'] = data.pop('cat_i_fishing_gear_origin', [])
        if 'cat_j_other_e_waste_origin' in data:
            free_plan_data['cat_j_other_e_waste_origin'] = data.pop('cat_j_other_e_waste_origin', [])
        
        additional_plan_data = {}
        if 'additional_cat_a_plastic' in data:
            additional_plan_data['cat_a_plastic'] = data.pop('additional_cat_a_plastic', None)
        if 'additional_cat_c_domestic_waste' in data:
            additional_plan_data['cat_c_domestic_waste'] = data.pop('additional_cat_c_domestic_waste', None)
        if 'additional_cat_e_incinerator_ashes' in data:
            additional_plan_data['cat_e_incinerator_ashes'] = data.pop('additional_cat_e_incinerator_ashes', None)
        if 'additional_cat_f_operational_waste' in data:
            additional_plan_data['cat_f_operational_waste'] = data.pop('additional_cat_f_operational_waste', None)
        if 'additional_cat_g_cargo_residue' in data:
            additional_plan_data['cat_g_cargo_residue'] = data.pop('additional_cat_g_cargo_residue', None)
        if 'additional_cat_i_fishing_gear' in data:
            additional_plan_data['cat_i_fishing_gear'] = data.pop('additional_cat_i_fishing_gear', None)
        if 'additional_cat_j_other_e_waste' in data:
            additional_plan_data['cat_j_other_e_waste'] = data.pop('additional_cat_j_other_e_waste', None)
        if 'additional_cat_a_plastic_origin' in data:
            additional_plan_data['cat_a_plastic_origin'] = data.pop('additional_cat_a_plastic_origin', [])
        if 'additional_cat_c_domestic_waste_origin' in data:
            additional_plan_data['cat_c_domestic_waste_origin'] = data.pop('additional_cat_c_domestic_waste_origin', [])
        if 'additional_cat_e_incinerator_ashes_origin' in data:
            additional_plan_data['cat_e_incinerator_ashes_origin'] = data.pop('additional_cat_e_incinerator_ashes_origin', [])
        if 'additional_cat_f_operational_waste_origin' in data:
            additional_plan_data['cat_f_operational_waste_origin'] = data.pop('additional_cat_f_operational_waste_origin', [])
        if 'additional_cat_g_cargo_residue_origin' in data:
            additional_plan_data['cat_g_cargo_residue_origin'] = data.pop('additional_cat_g_cargo_residue_origin', [])
        if 'additional_cat_i_fishing_gear_origin' in data:
            additional_plan_data['cat_i_fishing_gear_origin'] = data.pop('additional_cat_i_fishing_gear_origin', [])
        if 'additional_cat_j_other_e_waste_origin' in data:
            additional_plan_data['cat_j_other_e_waste_origin'] = data.pop('additional_cat_j_other_e_waste_origin', [])
        
        service_plan_data = {}
        if 'service_cat_a_plastic' in data:
            service_plan_data['cat_a_plastic'] = data.pop('service_cat_a_plastic', None)
        if 'service_cat_c_domestic_waste' in data:
            service_plan_data['cat_c_domestic_waste'] = data.pop('service_cat_c_domestic_waste', None)
        if 'service_cat_e_incinerator_ashes' in data:
            service_plan_data['cat_e_incinerator_ashes'] = data.pop('service_cat_e_incinerator_ashes', None)
        if 'service_cat_f_operational_waste' in data:
            service_plan_data['cat_f_operational_waste'] = data.pop('service_cat_f_operational_waste', None)
        if 'service_cat_g_cargo_residue' in data:
            service_plan_data['cat_g_cargo_residue'] = data.pop('service_cat_g_cargo_residue', None)
        if 'service_cat_i_fishing_gear' in data:
            service_plan_data['cat_i_fishing_gear'] = data.pop('service_cat_i_fishing_gear', None)
        if 'service_cat_j_other_e_waste' in data:
            service_plan_data['cat_j_other_e_waste'] = data.pop('service_cat_j_other_e_waste', None)
        if 'service_cat_a_plastic_origin' in data:
            service_plan_data['cat_a_plastic_origin'] = data.pop('service_cat_a_plastic_origin', [])
        if 'service_cat_c_domestic_waste_origin' in data:
            service_plan_data['cat_c_domestic_waste_origin'] = data.pop('service_cat_c_domestic_waste_origin', [])
        if 'service_cat_e_incinerator_ashes_origin' in data:
            service_plan_data['cat_e_incinerator_ashes_origin'] = data.pop('service_cat_e_incinerator_ashes_origin', [])
        if 'service_cat_f_operational_waste_origin' in data:
            service_plan_data['cat_f_operational_waste_origin'] = data.pop('service_cat_f_operational_waste_origin', [])
        if 'service_cat_g_cargo_residue_origin' in data:
            service_plan_data['cat_g_cargo_residue_origin'] = data.pop('service_cat_g_cargo_residue_origin', [])
        if 'service_cat_i_fishing_gear_origin' in data:
            service_plan_data['cat_i_fishing_gear_origin'] = data.pop('service_cat_i_fishing_gear_origin', [])
        if 'service_cat_j_other_e_waste_origin' in data:
            service_plan_data['cat_j_other_e_waste_origin'] = data.pop('service_cat_j_other_e_waste_origin', [])
        
        # Update the main instance
        serializer = self.get_serializer(instance, data=data, partial=True)
        serializer.is_valid(raise_exception=True)
        
        # Validate job completion - check if trying to mark as completed
        if 'job_status' in data and data['job_status'] == 'completed':
            # Check if all 9 operations are complete
            current_instance = serializer.validated_data
            all_operations_complete = (
                current_instance.get('form44_submitted', instance.form44_submitted) == True and
                current_instance.get('biosecurity_status', instance.biosecurity_status) == 'approved' and
                current_instance.get('govt_status', instance.govt_status) == 'approved' and
                current_instance.get('bio_witness', instance.bio_witness) == True and
                current_instance.get('landfill_booked', instance.landfill_booked) == True and
                current_instance.get('docs_complete', instance.docs_complete) == True and
                current_instance.get('discharge_certificate_created', instance.discharge_certificate_created) == True and
                current_instance.get('invoice_created', instance.invoice_created) == True
            )
            
            if not all_operations_complete:
                return Response(
                    {'error': 'Cannot mark job as completed. All 9 operations must be finished first.'},
                    status=status.HTTP_400_BAD_REQUEST
                )
        
        self.perform_update(serializer)
        
        # Update or create vessel plans
        # Free plan (always exists)
        free_plan = instance.vessel_plans.filter(plan_type='free').first()
        if free_plan:
            # Update existing free plan - update all fields that were sent in request
            for key, value in free_plan_data.items():
                setattr(free_plan, key, value)  # Allow None to clear fields
            free_plan.save()
        else:
            # Create new free plan - only if there's data
            if free_plan_data:
                free_plan_data['discharge_form'] = instance
                free_plan_data['plan_type'] = 'free'
                VesselPlan.objects.create(**free_plan_data)
        
        # Additional plan
        additional_plan = instance.vessel_plans.filter(plan_type='additional').first()
        if additional_plan_data or instance.dispose_additional_waste:
            if additional_plan:
                # Update existing additional plan - update all fields that were sent
                for key, value in additional_plan_data.items():
                    setattr(additional_plan, key, value)  # Allow None to clear fields
                additional_plan.save()
            elif instance.dispose_additional_waste and any(v for v in additional_plan_data.values() if v is not None):
                # Create new additional plan only if there's actual data
                additional_plan_data['discharge_form'] = instance
                additional_plan_data['plan_type'] = 'additional'
                VesselPlan.objects.create(**additional_plan_data)
        elif additional_plan and not instance.dispose_additional_waste:
            # Delete additional plan if dispose_additional_waste is False
            additional_plan.delete()
        
        # Service plan
        service_plan = instance.vessel_plans.filter(plan_type='service_purchase').first()
        if service_plan_data or instance.service_purchased:
            if service_plan:
                # Update existing service plan - update all fields that were sent
                for key, value in service_plan_data.items():
                    setattr(service_plan, key, value)  # Allow None to clear fields
                service_plan.save()
            elif instance.service_purchased and any(v for v in service_plan_data.values() if v is not None):
                # Create new service plan only if there's actual data
                service_plan_data['discharge_form'] = instance
                service_plan_data['plan_type'] = 'service_purchase'
                VesselPlan.objects.create(**service_plan_data)
        elif service_plan and not instance.service_purchased:
            # Delete service plan if service_purchased is False
            service_plan.delete()
        
        return Response(serializer.data)

    @action(detail=True, methods=['post'], url_path='upload-receipt')
    def upload_receipt(self, request, pk=None):
        form = self.get_object()
        file = request.FILES.get('file')
        if not file:
            return Response({'detail': 'No file uploaded'}, status=status.HTTP_400_BAD_REQUEST)
        # Use order date if not provided, otherwise use provided date
        date = request.data.get('date', form.date)
        receipt = LandfillReceipt.objects.create(
            discharge_form=form,
            file=file,
            date=date,
            uploaded_by=request.user
        )
        return Response(LandfillReceiptSerializer(receipt, context={'request': request}).data, status=status.HTTP_201_CREATED)
    
    @action(detail=True, methods=['post'], url_path='upload-incident-document')
    def upload_incident_document(self, request, pk=None):
        from .models import IncidentDocument
        from .serializers import IncidentDocumentSerializer
        form = self.get_object()
        file = request.FILES.get('file')
        if not file:
            return Response({'detail': 'No file uploaded'}, status=status.HTTP_400_BAD_REQUEST)
        incident_doc = IncidentDocument.objects.create(
            discharge_form=form,
            file=file,
            uploaded_by=request.user
        )
        return Response(IncidentDocumentSerializer(incident_doc, context={'request': request}).data, status=status.HTTP_201_CREATED)


class ShipDetailsViewSet(viewsets.ModelViewSet):
    queryset = ShipDetails.objects.all()
    serializer_class = ShipDetailsSerializer
    permission_classes = [IsAdminOrReadOnly]

    def get_queryset(self):
        qs = super().get_queryset().order_by('-created_at')
        return qs


class VesselPlanViewSet(viewsets.ModelViewSet):
    queryset = VesselPlan.objects.all()
    serializer_class = VesselPlanSerializer
    permission_classes = [IsAdminOrReadOnly]

    def get_queryset(self):
        qs = super().get_queryset().order_by('-created_at')
        return qs


class LandfillReceiptViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing landfill receipts.
    Can be linked to an order (discharge_form) or independent (no order).
    """
    queryset = LandfillReceipt.objects.all()
    serializer_class = LandfillReceiptSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        """Filter receipts by date if provided"""
        queryset = super().get_queryset().order_by('-uploaded_at')
        date = self.request.query_params.get('date', None)
        if date:
            queryset = queryset.filter(date=date)
        return queryset

    def perform_create(self, serializer):
        """Set the uploaded_by field to the current user if not provided"""
        if not serializer.validated_data.get('uploaded_by'):
            serializer.save(uploaded_by=self.request.user)
        else:
            serializer.save()

    @action(detail=False, methods=['post'], url_path='upload')
    def upload_receipt(self, request):
        """Custom action for uploading landfill receipts (independent, no order)"""
        try:
            file = request.FILES.get('file')
            date = request.data.get('date')
            
            if not file:
                return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)
            
            if not date:
                return Response({'error': 'No date provided'}, status=status.HTTP_400_BAD_REQUEST)
            
            # Create the receipt (independent, no order)
            receipt = LandfillReceipt.objects.create(
                file=file,
                date=date,
                uploaded_by=request.user,
                discharge_form=None
            )
            
            serializer = self.get_serializer(receipt)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
            
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class IncidentDocumentViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing incident documents uploaded by admin users.
    """
    queryset = IncidentDocument.objects.all()
    serializer_class = IncidentDocumentSerializer
    permission_classes = [IsAdminOrReadOnly]

    def get_queryset(self):
        """Order by most recent first"""
        return super().get_queryset().order_by('-uploaded_at')

# Create your views here.
