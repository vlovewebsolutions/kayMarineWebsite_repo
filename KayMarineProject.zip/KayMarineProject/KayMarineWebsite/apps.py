from django.apps import AppConfig


class KaymarinewebsiteConfig(AppConfig):
    name = 'KayMarineWebsite'
